// src/worker-entry.ts
var KEY = "overrides";
var MAX_BYTES = 512 * 1024;
async function published(env) {
  if (!env.SITE)
    return {};
  try {
    const raw = await env.SITE.get(KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}
var entries = (p) => Object.values(p.networks ?? {});
function metaTags(p) {
  return entries(p).map((n) => (n.verifyMeta ?? "").trim()).filter((t) => /^<meta\s[^>]*>$/i.test(t)).join(`
`);
}
function verifyFile(p, pathname) {
  for (const n of entries(p)) {
    const name = (n.verifyFileName ?? "").trim();
    if (!name || !/^[A-Za-z0-9._-]+$/.test(name))
      continue;
    if (pathname === `/${name}`)
      return n.verifyFileBody ?? "";
  }
  return null;
}
var json = (body, status = 200, extra = {}) => new Response(JSON.stringify(body), {
  status,
  headers: { "content-type": "application/json; charset=utf-8", ...extra }
});
function timingSafeEqual(a, b) {
  if (a.length !== b.length)
    return false;
  let diff = 0;
  for (let i = 0;i < a.length; i++)
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function authorised(req, env) {
  const expected = env.ADMIN_PASS;
  if (!expected)
    return false;
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token)
    return false;
  return timingSafeEqual(token, expected);
}
async function handleApi(req, env) {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET, PUT, OPTIONS",
        "access-control-allow-headers": "authorization, content-type",
        "access-control-max-age": "86400"
      }
    });
  }
  if (req.method === "GET") {
    if (!env.SITE)
      return json(null, 200, { "cache-control": "no-store" });
    const raw = await env.SITE.get(KEY);
    return new Response(raw ?? "null", {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "public, max-age=60",
        "access-control-allow-origin": "*"
      }
    });
  }
  if (req.method === "PUT") {
    if (!env.SITE) {
      return json({ error: "no-kv", hint: "Bind a KV namespace named SITE." }, 503);
    }
    if (!env.ADMIN_PASS) {
      return json({ error: "no-secret", hint: "Set the ADMIN_PASS secret." }, 503);
    }
    if (!authorised(req, env)) {
      return json({ error: "unauthorised" }, 401);
    }
    const body = await req.text();
    if (body.length > MAX_BYTES) {
      return json({ error: "too-large", max: MAX_BYTES }, 413);
    }
    try {
      JSON.parse(body);
    } catch {
      return json({ error: "not-json" }, 400);
    }
    await env.SITE.put(KEY, body);
    return json({ ok: true, bytes: body.length });
  }
  return json({ error: "method-not-allowed" }, 405);
}
var worker_entry_default = {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (url.pathname === "/api/site") {
      return handleApi(req, env);
    }
    const pub = await published(env);
    const vf = verifyFile(pub, url.pathname);
    if (vf !== null) {
      return new Response(vf, {
        headers: {
          "content-type": "text/plain; charset=utf-8",
          "cache-control": "no-store"
        }
      });
    }
    if (url.pathname === "/ads.txt") {
      const lines = entries(pub).map((n) => (n.adsTxtLine ?? "").trim()).filter(Boolean);
      if (lines.length) {
        return new Response(`${lines.join(`
`)}
`, {
          headers: {
            "content-type": "text/plain; charset=utf-8",
            "cache-control": "public, max-age=300"
          }
        });
      }
    }
    const res = await env.ASSETS.fetch(req);
    const tags = metaTags(pub);
    if (!tags)
      return res;
    const type = res.headers.get("content-type") ?? "";
    if (!type.includes("text/html"))
      return res;
    return new HTMLRewriter().on("head", {
      element(el) {
        el.append(tags, { html: true });
      }
    }).transform(res);
  }
};
export {
  worker_entry_default as default
};
