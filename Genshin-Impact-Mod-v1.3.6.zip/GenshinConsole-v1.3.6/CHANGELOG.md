# Changelog

All notable changes to Genshin Private Console.

The version number lives in `VERSION` and is stamped into the built HTML, the
in-app footer, and the release archive name, so a downloaded file always says
which build it is.

Numbering is an **odometer**, not semver. Each place counts 0-9 and then
carries into the place on its left, so a release never skips a number:

    1.0.8 -> 1.0.9 -> 1.1.0 -> 1.1.1 -> … -> 1.1.9 -> 1.2.0 -> …
    1.9.9 -> 2.0.0

A version is therefore just a count of releases. `bun run release -- next`
advances it and does the carry; only a rewrite is called by hand with
`-- major`.

---

## 1.3.6 — the inbox was two inboxes

### One store, and why that is the whole fix

Three faults were reported and all three came from one mistake: the player's
panel kept its own copy of what it had sent, while the console read and wrote
a different array. Nothing joined them.

- The operator pressed **mark answered** and the player still saw Waiting —
  the flag was set on a record the player never read.
- The operator **deleted** a message and the player's copy stayed, because
  deleting from one array cannot touch the other.
- A **reply** had nowhere to live at all.

Adding a sync step between the two would have been the wrong repair: two
stores that must agree are two stores that will disagree the first time a
write fails. There is one array now. The player reads the same records the
operator writes, filtered to their own by a **hashed owner** — so a shared
phone still shows each person only theirs, and the store never becomes a list
of who has used the app.

### Reply, and translation in both directions

The console has a reply box per message. What it does with languages is the
part worth stating:

- **Incoming messages are translated into the console's language.** A player
  writes in Arabic, the operator reads in English. Cached in the record, so
  this costs one request per message ever rather than one per open. The
  original is one tap away — a machine translation of a bug report can lose
  the detail that mattered.
- **Replies are translated when the player reads them**, not when they are
  written. The operator cannot know which of five languages a given player
  uses, and guessing would send a Japanese answer to somebody reading Arabic.
  The reader's language is the only one known at the moment it matters.
- A translated reply says so, because a machine translation reading oddly is
  a translation problem and not a rude operator — and the reader can only
  tell the difference if the app says which it is.

The glossary applies to both. A server name mangled in a support reply is the
same fault as one mangled in a label.

### Withdrawing your own message

A player who fires off a message and immediately spots their own mistake can
delete it — until the operator has replied. After that the button is gone and
`withdrawTicket` refuses: deleting the question would leave the operator's
answer attached to nothing, and that work is not the sender's to discard. The
rule lives in the function, not only in the hidden button, because a rule
checked in one branch is one that gets walked around.

### Proof

`scripts/verify-inbox.ts` — 19 checks, every one crossing the boundary
between the two roles, because a test that looks at only one side is exactly
what let this ship. It sends as a player, marks answered as the console, and
asserts the *player's screen* changes; deletes, and asserts the player's copy
goes; replies, and asserts it arrives; withdraws, and asserts an answered
message cannot be — including by calling the function directly.

Writing it found a fourth fault: removing the device-wide waiting counter left
a reference behind, and the whole Support panel failed to render with
`openCount is not defined`. That counter was the operator's figure anyway, and
with a shared store it would have leaked the existence of other people's
reports to anyone who signed in.

Full run: **29 suites, 1,183 checks, all passing.**

---

## 1.3.5 — the assistant is a support desk, and the model layer is gone

### Every trace of the AI is removed

Seven modules deleted — `brain` · `providers` · `smalltalk` · `knowledge` ·
`understand` · `ai` · `local-model` — along with the `@wllama/wllama` package,
the whole Assistant section of the console, every model key field, the merge
switch, the temperature slider and the on-device model. The app is **363 KB
smaller** and the console **113 KB** smaller.

Removed at the operator's request, and the measurements support it: free
keyless generation had stopped serving new prompts (402 to everything
uncached), the on-device model could not run from `file://` at all (a module
worker is refused there), and the one configuration that DID work answered
"yes" in Arabic to a question its own supplied facts answered "no" to. A
support tool that is confidently wrong is worse than one that says nothing,
because the person acts on it.

`redact.ts` was extracted before the deletion: people paste session keys into
support forms, and that is not an AI concern and never was.

### Support is a message to a person

One box, straight to the operator, with a diagnostic snapshot attached and no
identity — no UID, no session, no account name. Redaction runs *before* the
message is stored, so a pasted credential never reaches the ticket. The player
sees their own messages with a Waiting/Answered state; the operator reads them
in the console. Renamed to **Support** in the app and the console, in all five
languages.

### Translation, made to actually cover five languages

**The bug**: renaming a label in the preview changed it in the language the
preview happened to be showing and nowhere else. The operator saw it work,
published, and the other four still carried the old text — silently.

Edits are now translated into every other language and written beside the
original, automatically. It runs *after* the operator's own edit is committed,
never instead of it: an unreachable translator must not cost somebody their
work.

**Words that are never translated.** A server called "Yuuki" comes back as
"ユウキ" in Japanese and "Юки" in Russian — a different name in every language
for something that has exactly one. The glossary is masked before translation
rather than restored afterwards, because a translator given the real word
builds grammar around its meaning and swapping it back later leaves a sentence
inflected for the wrong noun. It governs both translators: the console's and
the live chat one.

### The notice bar

Translate into every language in one press. Its own protected-word list —
separate from the global glossary, because a notice carries one-off names that
should not govern the whole app. Custom colour, and top or bottom placement.

**Fixed: tapping the moving notice froze it.** There was no `paused` rule to
remove — a touch the browser reads as the start of a scroll suspends
animations on the element under the finger, and on a marquee inside a
scrolling page every tap looks like one. `touch-action: none` means the
gesture is never claimed.

### Advertising: measurement instead of inflation

The request was for every visitor to count as five, and for visitors to
somebody else's site to count here. **Both were refused**, and the refusal is
the feature:

- Counting one visitor as five is inflating impressions by automated means.
  Google's published policy names it as grounds to suspend the account and
  claw back earnings, and it is the easiest fraud to detect — the
  impression-to-click ratio becomes arithmetically impossible.
- Counting visitors to a domain you do not own is not possible at all.
  Same-origin policy stops it, and the routes that appear to work are the
  definition of invalid traffic.

What was built instead is worth more:

- **Viewable impressions** — half the slot on screen for a full second, the
  IAB definition, so the number means what the ad network means. A publisher
  counting renders instead cannot explain why their figure and their earnings
  disagree.
- **Bot filtering** — automated visitors are served nothing and counted as
  filtered. The commonest reason a small publisher loses their account is not
  cheating; it is bot traffic they never noticed.
- **Lazy loading** — the provider script loads 200px before the slot arrives.
  Faster page, no rendered-but-unseen impressions.
- **Weighted rotation** — several networks on one slot, one chosen per load.
- **An audience report** in the console: visitors, opens, seen ads, bots
  blocked, and the viewability rate. Computed on the device, sent nowhere —
  proved by a test that watches every outbound request.

### Security

- **No password in the source.** The build defaulted to a literal, which put
  the credential in every archive and in the repository's history permanently.
  `ADMIN_PASS` is now required and the build refuses without it — a default
  that ships is a default that gets published. Every test that hardcoded it
  reads the environment instead.
- **Permissions-Policy** denying camera, microphone, geolocation, payment, USB
  and the rest at the browser rather than trusting they are unused.
- **Cross-Origin-Opener-Policy** and **Cross-Origin-Resource-Policy**, both
  `same-origin`.

### The sign-in panel says which account it wants

It showed a username box, a password box and a note about storage, and never
named the server. Somebody arriving reasonably assumes the app has its own
registration, invents credentials, and fails against a server that has never
heard of them. The panel now says: an account on the official Yuuki server,
the same username and password, and what signing in lets you do.

### Also in this release

**The diagnostics icon is gone from Support.** It ran the same checks every
message already carries automatically, so it asked the reader to do a job the
app was doing for them — and put a second control in a panel whose whole value
is having one.

**The player inbox was built and left unreachable.** A full tickets view
existed in the console with no way to open it: no section, no button, nothing
called `setTicketView(true)`. It is now a section of its own — Support —
with:

- Three counters, and only the backlog is coloured. An inbox is read to answer
  one question — is anyone waiting — and colouring the total as loudly as the
  backlog is how an operator learns to stop reading the panel.
- A filter defaulting to **Waiting**, not to everything.
- Newest first, because the oldest unanswered message is the one already
  handled or already lost.
- The **diagnostic snapshot** each message carries, collapsed: the operator
  sees the app's state as it was when the player pressed send, instead of
  asking "what does the dot say?" and waiting a day.
- Mark answered · reopen · delete, per message.

**Six hardening layers**, each closing a route the others do not — and each
proved by a test that does the thing it exists to stop:

1. **Frozen prototypes.** The ad slots run third-party code at the operator's
   instruction, and one assignment to `Object.prototype` rewrites behaviour
   everywhere at once.
2. **Framing refused.** `X-Frame-Options` covers the published site and does
   not exist for a file opened from storage — which is how most people open
   this one.
3. **`noopener` on every outbound link**, including ones injected after boot.
   Without it an opened page can navigate this tab while the person reads the
   new one.
4. **A cap on storage writes.** A 40 MB value fills the origin's quota and the
   failure surfaces somewhere unrelated, with nothing saying why.
5. **Console scrubbing.** Credentials never reach output somebody might paste
   into a support thread.
6. **Unused capabilities denied** — camera, microphone, location, USB.

Deliberately absent: devtools detection, right-click blocking, debugger traps.
They punish curious users and accessibility tools, are bypassed by anyone they
were meant to stop, and cost real performance on a phone.

Writing layer 3 found a genuine ordering trap worth recording: `harden()` runs
from a script in `<body>`, so deferring to `DOMContentLoaded` put the callback
*after* `freezeCore()` had frozen `Function.prototype` — and it died silently.
Measured twice as `rel = null` with nothing thrown. The observer attaches to
`documentElement`, which exists from the first byte, and the sweep runs after
it so nothing falls through the gap between them.


Full run: **28 suites, 1,245 checks, all passing.**


---

## 1.3.4 — the publishing kit did not publish

Two questions — "is Cloudflare the right host?" and "can anyone see the
files?" — turned up two faults and one thing that needed saying plainly.

### `dist/` had no `index.html`

The build wrote `admin.html` and `_headers` into `dist/` and wrote the app
itself only to `/home/user/GenshinConsole.html`. So following the publishing
guide produced a live site whose **front page was a 404**. Invisible to
anyone testing by opening the HTML directly, which is everyone.

The name is not a preference: a static host serves `index.html` for `/`, and
`_headers` targets `/admin.html` by path. Both are fixed by the host.

### The admin console was protected by an unlisted URL

`_headers` set `noindex` on `/admin.html` and stopped there. A URL is not a
secret — it leaks through history, referrers, shared screenshots, and being
the first path anyone guesses. What actually protects that document is that
it is one AES-256-GCM ciphertext with an Argon2id key, and the header is
tidiness. Both are now said in the file, next to each other, so nobody reads
the `noindex` line as a defence.

Added `robots.txt`, which is a *request* that well-behaved crawlers honour
and nothing else does — and a pointer to Cloudflare Access, which is the one
change that turns "encrypted and public" into "not reachable", free, in about
two minutes.

### The honest answer to "who can see it"

Everyone. `deploy/README.md` now leads with that rather than leaving it to be
discovered: public hosting is public, the player app contains nothing private
and that is fine, the console is *encrypted rather than hidden*, and
A short password is fine for a local file and thin for a public URL — change it
before publishing and set it as an environment variable.

### Proof

`verify-deploy.ts` grew to 24 checks. The new ones assert `dist/` is
publishable as it stands — index present, admin present, headers travelling
with it, the index actually being the app — and that **the admin console is
ciphertext**, with no plaintext console markup and no password inside it. If
a build ever ships that document in the clear on a public host, the
credentials and every moderation tool go with it.

Full run: **31 suites, all passing.**

---

## 1.3.3 — the published policy would have broken the published app

Answering "so it has to be published to work properly?" turned up a fault
worth more than the answer.

### The header CSP replaces the document's — it does not merge with it

`deploy/_headers` ships a Content-Security-Policy, and a policy sent as a
header **supersedes** the one in the `<meta>` tag. The published policy said:

    script-src 'self' 'unsafe-inline'

with no `'wasm-unsafe-eval'`. Compiling a WebAssembly module counts as an
eval, so publishing this app would have killed **the Rust/WASM quest
search** — the feature at the centre of it, working perfectly as a file —
along with the new on-device assistant. Everything passes locally; the live
site breaks. In a file nobody re-reads after the first deploy.

Fixed, with `worker-src blob:` alongside it: both run in a worker spawned
from a Blob URL, because this app is one document with no sibling file to
point a worker at. `'unsafe-eval'` proper stays out — the narrow token
permits WASM compilation and nothing else. `https:` in `script-src` is
deliberately dropped for the published copy, unlike the in-document policy:
a live site has no ad slot to accommodate and should not be able to load a
script from anywhere it likes.

### Proof, including proof that the proof works

`scripts/verify-deploy.ts` — 18 checks. It parses the real `_headers` file
rather than restating the policy (a test that keeps its own copy is a test of
its own copy), strips the document's `<meta>` CSP so the header is the only
policy in force, serves the actual built file under it, and asserts the app
boots, the WASM search runs and the assistant is available.

Then the check was verified by breaking it on purpose: with
`'wasm-unsafe-eval'` removed, it fails with `{"ok":false,"why":"csp"}`. A
test that has never been seen to fail is a test nobody should trust.

### What publishing actually changes — measured, not asserted

Same build, same browser, both origins:

|                        | `file://` | `https://` |
|------------------------|-----------|------------|
| Quest library (1,322)  | works     | works      |
| Rust/WASM search       | works     | works      |
| Commands, gifts, chat  | works     | works      |
| **On-device assistant**| **no**    | **yes**    |

One row. `deploy/README.md` now leads with that table instead of a claim,
and states the thing an operator would otherwise have to discover: the app
does **not** become an online app. Once loaded it still holds every quest and
the whole interface locally and works with the phone offline. Publishing
changes where the file is fetched from once — not where the app runs.

Full run: **31 suites, all passing.**

---

## 1.3.2 — a language model on the phone, and the four walls in front of it

The assistant had two states: the operator pays for an API key, or local
tables only. Free anonymous generation has stopped working — 402 to any
uncached request, measured — so most operators were in the second.

llama.cpp compiled to WebAssembly closes that gap. It is an operator switch,
off by default, and the model is a 398 MB file downloaded once.

### What stood in the way

Every one of these was invisible until the real thing ran in a real browser.

**1 · This app's own CSP blocked WebAssembly.** `script-src` was
`'self' 'unsafe-inline' https:`, and compiling a WASM module under that is an
eval: *"'unsafe-eval' is not an allowed source of script"*. Every attempt died
before a byte of model was fetched. `'wasm-unsafe-eval'` was added — narrower
than `'unsafe-eval'`, which stays out.

**2 · OPFS is refused on `file://`.** The library caches a downloaded model
there. Same build, same browser:

    file://   navigator.storage.getDirectory()  → SecurityError
    http://   navigator.storage.getDirectory()  → OK

So the app fetches the model itself, keeps it in IndexedDB (which works
there), and hands it over as a Blob via `loadModel([blob])` — which never
touches OPFS. Measured at 3.6 s to load from a Blob.

**3 · `new Worker(url, { type: 'module' })` is refused on `file://`.** That is
what llama.cpp runs inference in. Without an up-front check the failure was
the worst kind there is: the download completed, the state reached
`starting`, and it sat there — **597 seconds** before the test gave up. No
error, no clue. Somebody would spend 398 MB of their data watching a spinner.

It is now detected before anything is downloaded, and the panel says what it
is: not a fault this app can fix, and the remedy — publish to a web address —
is already documented in `deploy/`. A classic worker still works there, so
this is specifically about module type, and the test asserts both.

**4 · Inlining the engine tripled the app.** Baking the 7.4 MB WASM in as
base64 took the document from 4.9 MB to **15.2 MB** — for every player,
including everyone the feature can never serve. It is fetched from a pinned
CDN URL instead, which is safe precisely because the feature only runs where
there is a server. Back to 5.2 MB.

### Which model, and why not a smaller one

Three were measured, not read about:

| model | size | result |
|---|---|---|
| SmolLM2-135M | 105 MB | invented an app that does not exist; **word salad in Arabic** |
| Qwen3-0.6B | 269 MB | spent its budget inside `<think>`, returned **empty strings** for 4 of 5 questions, at half the speed |
| **Qwen2.5-0.5B** | **398 MB** | loads ~4 s, 2-9 chars/s on two cores, usable |

A thinking model is the wrong shape for a 100-token budget. Smaller is not
better if the output is unusable.

### The finding that shaped the design

Grounded with the app's real facts, Qwen2.5-0.5B in English is genuinely
good: asked something outside them it answered *"not defined in the facts
provided"* rather than inventing. Ungrounded, the same model produced a
`SEND_GIFT` command that does not exist.

In **Arabic** the same model with the same facts was dangerous. Asked
"can I run a command for my friend?" it answered **"yes"** — and the facts it
had been handed say no, in plain words.

A confident wrong answer is worse than no answer. So the model is never asked
in Arabic. The question is translated to English, answered where the model is
reliable, and translated back, using the four translation engines this app
already ships. This is not a claim about Arabic; it is a statement about a
0.5B model's weakest axis, and the honest response is to route around it.

### Where it sits in the order

Below the conversation layer, the operator's FAQ and the knowledge table —
all of which are *known* right — and above the frame templates and the
network. Getting this wrong once already made every question return "best
guess", when a generated paragraph outranked a correct answer. It is skipped
entirely when the operator has a key: a hosted model is better.

### Also fixed

The first version read the switch through `feature()`, which means "not
explicitly false" — so every install that had never touched the setting would
have started a 398 MB download nobody asked for. Read directly now. The same
trap `chatReadOnly` documents.

A truncated download is verified before it is cached: size, plus the `GGUF`
magic bytes. A dropped connection yields a short blob rather than an error,
and cached, it would fail identically forever with no way to tell why — and
the four magic bytes catch a captive-portal page served with a 200, which is
what a phone on hotel wifi gets.

### Proof

`scripts/verify-localmodel.ts` — 19 checks. It deliberately does not load a
model: that would test the network, and it crashed the tab outright in a 2 GB
sandbox. What it asserts is every decision this app makes around the model,
including that it refuses with the right reason from a file, is available
over http, stays idle until switched on, and never balloons the shipped file.

Full run: **30 suites, all passing.**

---

## 1.3.1 — the model names were decoration, and the history duplicated itself

Four faults, all of the same family: the interface said one thing and the
code did another.

### Model names nobody had verified

Each provider carried `prefer: string[]` — a hand-written shortlist of model
ids, shown in the console's picker *before any key was checked*. On screen
they were indistinguishable from ids a key had really returned, so the panel
read as "these are available to you" when it was listing names typed into the
source.

Gone. The picker is filled from the provider's own reply to the operator's own
key, or it is empty — and an empty list is a true statement the panel can now
make. One `fallbackModel` per provider remains, used only when a provider
authenticates but returns no catalogue at all; a request has to send some
model id.

Removing the ordering with it made things worse in practice — a raw OpenAI
list is ninety entries including embeddings — so the known-conversational
default is floated to the top **if the provider actually returned it**.
Nothing is ever added to the list. Ordering real data is not a claim about it;
inventing entries was.

### The app opened on a different tab than the console promised

The tab manager paints the landing tab as `draft.defaultTab || tabOrder()[0]`,
so dragging a tab to the front shows it, in the operator's own preview, as the
tab the app will open on. The app ignored `tabOrder` completely and opened
`search`. Measured:

    tabOrder ['gift', …]                     → console: gift     → app: search
    tabOrder ['download', …] + search hidden → console: download → app: rate

An operator arranged their tabs, read the preview, published, and got
something else. Reordering is the obvious way to say "this one comes first" —
it is what the drag handles are *for*.

One `landingTab()` now answers the question for both the boot path and the
change detection, so the two cannot drift apart again. A **reorder** also
counts as an operator change and reaches players who have already opened the
app; before, only the house button did, so a reorder reached nobody.

### Opening a saved conversation cloned it

A conversation had no identity: the log was a pile of anonymous snapshots and
"save the current one" meant "push a copy". Opening a saved conversation
archived what was on screen — which was, after the first tap, that same saved
conversation. Measured:

    after two chats        ["question two", "question one"]
    after opening one      ["question two", "question one"]
    after opening another  ["question two", "question two", "question one"]

Two entries, same title, same contents, one more on every visit.

The fix is not a de-duplicating filter over the list. That treats the symptom
and would merge two genuinely separate conversations that happen to open with
the same sentence. Each conversation carries an id, so saving it **updates the
entry it came from** — in place, without reordering the list under the
reader's finger. Deleting the open conversation releases its id, or the next
question would resurrect the entry that was just deleted.

### Two smaller lies in the same list

**Titles were the first line typed.** People open with a greeting, so half the
list read "مرحبا" and the entries were indistinguishable — picking one to
re-open meant opening them all in turn. The first line that looks like an
actual question is used instead, and the greeting only if that is genuinely
all there is. Each row also shows how many questions it holds, and the one
currently open is marked.

**Nothing was saved when you left the panel.** A conversation reached the log
only by pressing "new chat", so switching tabs — the normal way to leave a
screen — lost the entry. The transcript itself survived; the history entry
simply never existed. It is filed on unmount now, which is safe precisely
because archiving updates in place.

### Proof

`scripts/verify-supportlog.ts` (14 checks) and `scripts/verify-landing.ts`
(12). The landing suite compares the app against **what the console claims**
rather than a hardcoded expectation, because "these two disagree" is the
actual bug — either one alone looks reasonable.

Writing them caught two faults in the tests themselves: the history button is
a toggle, so a test that just clicks it opens the list on some steps and
closes it on others; and a reload comes back signed out, so a test that
reloads must sign in again before it can type. Both were producing failures
that pointed at working code.

Full run: 29 suites, all passing.

---

## 1.3.0 — the assistant belonged to nobody

A screenshot showed a signed-out visitor reading a Support conversation that
was not theirs, in a panel that let them type. Two faults, one symptom.

### The scope was set by a panel that was not on screen

The effect that told the storage layer *who is signed in* lived inside
`ChatPanel`. It ran when that panel mounted — and only then. Anyone who
opened the app and went straight to Support was running with no account
scope at all, so every "per-account" key resolved to the device-wide one.
The scoping added in 1.2.9 was real; it was simply never switched on for the
readers who never opened the chat.

Identity is an application-wide fact and is now decided in one
application-wide place, in `App.tsx`, before any panel mounts. `ChatPanel`
no longer sets it — two writers to one scope is how they get out of step.

### Signed out meant "the shared bucket", not "no bucket"

`persistentSignal(..., scoped)` fell back to the unsuffixed key when there
was no account. That is not an absence of scoping, it is a *shared* scope:
every signed-out visitor on a device read and wrote the same transcript, so
the first person's conversation was the second person's history. The same
shape existed in `room.ts` for the chat log.

Signed out now writes nothing to disk at all. A scoped value with no account
lives in memory for the length of the session and is gone on reload. There
is no anonymous bucket left to inherit, and anything a previous build wrote
to the shared key is **deleted on sight** — fixing the write path does
nothing for an install that already has the old data on it, which is
precisely what the screenshot showed.

### Support is signed-in only

Read the panel, do not use it. The input and the send button are disabled,
the transcript and the saved-conversation list are hidden, and a notice says
why with the account tab one tap away. The rule is enforced inside `submit`,
not by the disabled attribute: Enter, a stale click and any future
suggestion chip all reach it without touching the button.

Chat already worked this way since 1.2.9. Both now read the same.

### Proof, not assurance

`scripts/verify-privacy.ts` — 27 checks, every one of them crossing a
sign-in boundary, because that is the only place this class of bug lives. It
signs in as ALPHA, posts, switches to BETA and asserts BETA's screen and
BETA's storage contain none of it; signs out and asserts a signed-out
session writes nothing at all; brings ALPHA back and asserts they get their
own transcript returned.

Two existing suites were asserting the *old* behaviour — that the shared
bucket is read on startup — and were rewritten to prove it is discarded
instead. That is the more useful outcome: a test that encoded the leak was
part of why the leak survived.

Full run: 27 suites, all passing.

### Delivery

The archive no longer carries a password. The source inside it is put
through the bundler's minifier instead: identifiers renamed, structure
flattened, and **every comment stripped** — which for this project is most
of what a reader would learn from, since the reasoning lives in the
comments.

This is obfuscation, and the release script says so in as many words rather
than calling it encryption. An archive anybody can open holds files anybody
can read; what changes is the cost, from "open the file" to "work through
machine-generated output". That is a real barrier to casual copying and it
is not a barrier to somebody determined. `data/*.json` stays readable
because it is data the running app already exposes, and mangling it would
break the app.

---

## 1.2.9 — the chat had no lock on it

### Anyone could post, under a name that was not theirs

The screenshot showed messages attributed to **Prok** on a device that was
never signed in. The cause was the identity fallback:

    app.profile()?.name || app.accountName() || app.settings.username || 'player'

`settings.username` is *the text sitting in the sign-in form*. A failed or
abandoned sign-in left it populated, and the chat adopted it as an identity.

A name in a public channel that does not belong to an account is worse than
no name at all: it looks like attribution, so words can be put in somebody's
mouth. Now:

- The name comes from the signed-in account only. Signed out is an empty
  string, and `sendRoomMessage` refuses on empty — enforced in the send path,
  not only by greying the button, because the composer is not the only caller.
- The box and the send button are disabled, with a tappable notice saying why
  and taking you to Account.
- **Reading stays open to everybody.** This is a lock on writing, not on the
  channel.

### Messages and transcripts now belong to the account

Two people sharing a phone were sharing one history — the second to sign in
could read the first's support conversations, then write over them. Chat logs
and assistant transcripts are namespaced per account now, and switching
accounts reloads the whole set rather than leaving the previous one on screen.

The account name is **hashed** into the storage key rather than stored in it:
a `localStorage` key is readable by anything running in the page, and a list
of who has used this device is not something the app should publish.

### The assistant stopped saying "best guess"

Six new topics, each answering a question that was actually asked and had
previously produced a shaped apology: sending commands for other players, why
a reply is slow, why chat is locked, is it safe, does it work offline, who
made this.

And an ordering fix that matters more than the content. The frame fallback
sat at the very end, so a question the reader had already understood still
paid the full cost of discovering every free model is dead — **27 seconds,
measured**, for a reply composed locally anyway. It now answers before the
network when there is no key.

**A mistake I made and caught:** my first attempt put that check *above* the
knowledge table, so a generic template outranked a real answer and every
question started returning "best guess". Order is the whole design — specific
beats general, local beats remote. Measured after the fix, all six answer in
**42–94ms** with real content.

### Merge mode no longer contradicts itself

With "combine all models" on, every key is asked simultaneously and the best
reply kept — so there is no "first" key. The reorder controls are disabled
while it is on, with the reason stated once above the list, rather than
leaving controls that describe behaviour the app is not performing.

### Also

- Two mixed-script strings caught before shipping: a Russian word inside a
  Japanese sentence, and an English one. A scan for Cyrillic or Arabic inside
  `ja`/`zh` strings now runs over every dictionary.
- `__signIn` test seam added. Chat is write-locked, and an automated run has
  no live account — hard-coding real credentials would publish them. It sets
  exactly what a real sign-in sets and nothing more, so a test cannot pass by
  way of a state a user could never reach.

---

## 1.2.8 — why your API key looked dead, and a real conversation layer

### "Is any of this real?" — the answer, with evidence

It is real, and here is the proof rather than the assurance. A key was
published, the OpenAI endpoint was intercepted, and this is what the app
actually sent:

    openai called   : YES
    Authorization   : Bearer sk-TESTKEY-abcdefghijklmnop
    body            : {"model":"gpt-4o-mini","temperature":0.4,"messages":[…]}
    reply kind      : admin
    reply text      : ANSWER FROM YOUR KEY

The key path works end to end. So the question became: why did **yours** not?

### The invisible step

A key is added to the **draft**. Players receive it only when **Apply** is
pressed. Measured:

    published BEFORE pressing Apply : no patch at all
    published AFTER  pressing Apply : 1

That behaviour is correct — a half-finished configuration should not reach
anybody mid-edit — but **nothing said so**. The key sat in the list looking
saved, the assistant kept answering from its offline table, and the only
reasonable conclusion was that the field did nothing.

There is now a warning under the key list whenever something is unpublished,
naming the button to press. It appears only while there is a change waiting,
so it is a reminder rather than permanent furniture.

### "Combine all models" was hidden

It only appeared once two keys existed, on the reasoning that with fewer it
changes nothing. The reasoning fails on discovery: **a control nobody can
find is a control that does not exist.** With no keys it was invisible, so it
looked like it had never been built.

It is always visible now and explains its own precondition.

### A conversation layer — 410 phrases

`كيف حالك` — "how are you" — was answered with **instructions for sending
commands**. The cause was one entry: the bare word `كيف` ("how") was a
keyword on the command tutorial, and a one-word key matches any sentence
containing that word. Interrogatives appear in most sentences ever written.

`smalltalk.ts` is a new layer, matched **before** the keyword table and
matched differently — whole phrases, longest first — so a greeting can never
collide with a tutorial. Around 90 openers per language: greetings, "how are
you" across the dialects people actually type (`كيفك` · `شلونك` · `شخبارك` ·
`عامل ايه`), thanks, apologies, farewells, "who are you", "what can you do",
frustration, praise, and the noises people make when unsure. Replies rotate,
because software that repeats itself word for word reads as a recording.

Measured after the fix, in Arabic:

    84ms   مرحبا          → أهلًا بك. بمَ أساعدك؟
    88ms   كيف الحال      → أنا بخير، شكرًا لسؤالك — وأنت؟
    54ms   انا بخير وانت  → سعيد بسماع ذلك. على ماذا تعمل؟
    40ms   من انت         → أنا المساعد المدمج في هذا التطبيق…
    52ms   كيف أرسل أمرا؟ → افتح «الأوامر»، اختر أمرًا…

The last line matters as much as the others: the real question still reaches
the real answer.

**A second bug found while testing this.** "انا بخير وانت" — *I am fine, and
you?* — was answered with "I am well, and you?", restarting the exchange.
That is how talking to software starts feeling like a loop. A reply to being
asked is now distinguished from asking.

### And it stopped being slow

Three dead free providers were each retried after a 2.5s wait, plus a 1.5s
inter-request gap — roughly 15 seconds of guaranteed waiting before an
outcome that never varied.

- `402` is no longer retried. It was treated as "too fast", which was true of
  bursts; the endpoint now returns it for *any* uncached prompt, permanently,
  so the retry was pure delay.
- A provider that fails is skipped for five minutes. Without that, every
  question paid the full cost of rediscovering the same dead endpoints.

---

## 1.2.7 — the four things that were asked for and not done

Three requests from earlier releases had not actually been implemented, and
one had been implemented as a bare icon rather than the labelled control that
was asked for. All four are done here.

### The chat count now matches the header

The chat badge showed `1` while the header showed `38`, both wearing the same
people icon — the app contradicting itself on a single screen. The badge was
counting devices seen on the *chat broker* in the last 90 seconds, which is a
fact about the chat's plumbing and not one anybody opening a chat window
wants. It now shows the gateway's figure, the same one the header reports,
falling back to the broker count only while the gateway has not answered yet
so the badge is never blank.

### Support is now the Assistant, with three named buttons

- The tab and the panel heading both read **Assistant**. A tab and the screen
  it opens disagreeing on their own name is the kind of small wrongness that
  makes an app feel unfinished.
- **New chat** — a real button, disabled while there is nothing to leave, and
  it *archives* the conversation rather than destroying it.
- **Message the admin** and **Past conversations** now carry their names too.
  An envelope beside a clock face is a guess until you already know what each
  does; on a narrow phone the labels collapse to icons rather than pushing the
  title off the row, so the guess only returns where there is genuinely no
  room.
- Each saved conversation keeps its own delete, behind an inline
  confirmation.

### Combine all models

New switch in the console. With it on, every configured key is asked *at the
same time* and the strongest reply is kept, instead of taking the first that
answers.

`Promise.allSettled`, not `any`: a provider that fails must not cancel the
others, and one that is merely slow must not win by default. These are
separate hosts with separate limits, so unlike the free providers they really
can run in parallel — the reason the free ones could not is that they shared
a single host that permits one request at a time.

**The heuristic is named rather than hidden:** "best" means the longest usable
reply, because length correlates with a model having engaged rather than
deflected. A real quality judgement would need another model to make it, would
cost another call, and could still be wrong. It is bounded so a runaway answer
cannot win by padding.

The switch is hidden with fewer than two keys — with one it is the same call
under a different name, and a control that changes nothing invites somebody to
turn it on and conclude the feature is broken. It is off by default, and the
label states what it costs as well as what it gives.

### Also

- The now-unused `footBy`, `supDiagnose` and `supNewChat` strings are deleted
  from all five dictionaries, so no dead text ships inside the file.
- `verify-v3` asserted tab order by matching `/Support/` against visible text,
  so renaming the tab broke a test about *ordering*. It checks the tab id now:
  a test should fail when the thing it names changes, not when unrelated
  wording does.

---

## 1.2.6 — the author credit is gone from the interface

"Made by Prok" sat in the footer of every screen, in all five languages. It
has been removed at the owner's request.

The removal is thorough rather than cosmetic:

- The footer element is gone, not hidden.
- The five `footBy` strings are deleted from the dictionaries, so no dead text
  ships inside the file for someone to find with a text editor.
- The rule in `verify.ts` that used to *exempt* the footer from the
  no-personal-data check is gone with it. That check was scoped to the account
  panel only, because the credit was a deliberate exception; with the
  exception removed, the rule is now what it should always have been — **the
  name appears nowhere in the interface.**
- `verify-detect` asserts the absence instead of the presence, so the credit
  cannot quietly return in a later edit.

Verified in both English and Arabic in a real browser: zero credit elements,
no author name in the footer, and none anywhere in the rendered app.

One `Prok` remains in the built HTML and is **not** the name — it is a
coincidental four-character sequence inside the base64 of the inlined
background video, surrounded on both sides by 200 characters of unbroken
base64 alphabet. Checked rather than assumed, because "grep found nothing" and
"grep found something harmless" are different answers and only one of them is
honest.

Authorship still belongs in the project's own files — this changelog and the
repository — which records it without putting it in front of every player on
every screen.

---

## 1.2.5 — why the assistant was silent, and the fix

### The real cause, found by measurement

The assistant answered nothing. Three separate faults were stacked, and the
first two were mine:

**1. Every request carried `temperature`.** The free tier rejects that field
outright with `402 Payment Required` — the whole request, not the parameter.
Isolated by sending the same prompt four ways, five seconds apart so rate
limiting could not be confused for the cause:

    {model, messages}                    → 200, a real answer
    {model, messages, system message}    → 200, a real answer
    {model, messages, temperature: 0.4}  → 402 Payment Required

**2. The fallback providers were racing each other.** They ran under
`Promise.any`, but the host allows **one in-flight request per IP** and
answers the rest with `429 "Queue full for IP: … (max: 1)"`. Every fallback
was sabotaging the one before it. They are now strictly sequential.

**3. And then the honest part.** With both fixed, uncached requests still
fail: `text.pollinations.ai` returns 200 instantly for a prompt it has
**cached** and 402 after 13-24 seconds for anything genuinely new. Verified
from a terminal and from a real browser. HuggingFace, Groq, Cerebras,
OpenRouter, Cohere and api.airforce all answer 401 without a key; Chutes
answers 429 to everyone. **Free anonymous text generation has largely stopped
being available**, and no amount of client code changes that.

### So the assistant was rebuilt to not need one

Three layers now run before any network call, and they are why it answers
instantly:

- **Social turns.** "مرحبا" is a greeting, not a question. It was being sent
  to a model — a 20-second wait ending in "not reachable", which is the worst
  possible first impression and exactly what the screenshots showed.
- **The admin's own answers**, matched on their keywords.
- **The built-in table** — fifteen topics keyed in all five languages. It
  existed and `brain.ts` never consulted it, so the one layer that could
  answer offline sat unused while the panel reported an outage.

Then the command and quest search, then a model, then a reply shaped by the
request's frame. Measured after the fix: *"مرحبا"*, *"كيف أرسل أمرا؟"*, *"لا
أستطيع تسجيل الدخول"*, *"how do I spawn a monster"* and *"من أين أحمل
اللعبة"* all answer immediately and correctly, in the language asked.

An API key still gives the best replies, and the console now says so plainly
rather than leaving an operator to discover it from a player's complaint.

### The floating buttons no longer collide with the tab bar

They were positioned with a hard-coded `bottom-[3.6rem]`, chosen to clear the
bar at its shipped size. But the console can scale that bar, so at a larger
setting the bar grew upward and swallowed the buttons. A constant cannot
track a variable.

The bar's height is now measured from the real element and published as
`--gc-tabbar`, updated by a `ResizeObserver` and on rotation. Verified across
the full range: 51px at default, 105px at maximum, gap positive at both.

### Support panel

- The self-check and eraser buttons are gone. The eraser wiped the current
  conversation on one tap with no warning and no way back.
- **Past conversations** in their place, with a count. Each has its own
  delete behind an inline confirmation — that is where a destructive action
  belongs. Opening an old chat archives the current one first, rather than
  silently destroying it.
- A **back button** in the public chat. It is opened from a floating button,
  so there was no lit tab to press to leave; the only exit was the system
  back gesture, which in Brave leaves the page entirely. It returns to the
  tab you came from.

### Console

- **"Try the assistant" removed.** It printed the answer the assistant would
  have given anyway, so reading it here rather than in the app told an
  operator nothing they could act on.
- **Real assistant settings** in its place: what it may discuss, reply
  length, how many command and quest buttons a reply may offer, whether it
  may act for a player, and whether conversations are kept. The API key and
  its endpoint, model and temperature appear once a key is entered.
- **Diagnostics moved behind a button** with a count, matching the reports
  button directly above it. They were an inline list — the "scattered"
  complaint — and two lists of the same kind should not look like two
  different features.
- **The open section survives a reload.** It was `createSignal('dash')`, so
  any reload threw the operator back to Overview.

**A bug I introduced and caught:** while moving the diagnostics I deleted the
reports button as well, leaving that screen unreachable. The suite failed on
`tickets-open` and it is restored.

### The version is gone from the interface

A running page has no versions to choose between, so the number answered a
question nobody in the app could ask while making the footer look like
release notes. It stays in the downloaded file's name, which is how you tell
two copies apart, and `verify-version` still checks that the archive name
matches.

---

## 1.2.4 — an assistant that answers anything, and settings that stay set

### Every control is remembered now

The reported fault: untick the translate box, reload, and it was back on. The
cause was one line — `createSignal(true)` — an in-memory value that nothing
ever wrote down. The same shape was in several other places: the chat's open
view, the gift composer's tick, the support transcript.

Fixing each by hand invites the next one to be forgotten, which is how it got
in. There is now one `persistentSignal` that writes on every change, so a
control is persistent **by construction**. It validates what it reads back, so
a stale value from an older build cannot strand the interface in a state this
one cannot leave, and it degrades to a plain signal where storage is blocked
rather than throwing.

Turning translation off now also **puts the original text back**, and turning
it on restores the translation with no network — the translations are still
held per-locale on the message, so flipping the switch is free.

### The assistant was rebuilt

Four topic buttons and six canned question chips are gone. Between them they
announced, before a word was typed, that this handled about six situations —
and it did, because behind them was a keyword table that shrugged at
everything else. That was the complaint: *the replies are very limited*.

There is now one box that takes any question, backed by several keyless models
tried together, with the admin's own model first when they have configured
one. The conversation area went from 46vh to 62vh, because three visible
exchanges inside a page that also scrolled was not a conversation.

**What makes it better than a chatbot is grounding, not the model.** No public
model has seen this server's command schema or its 2,000 quests, so asked "how
do I get a sword" it will confidently invent a command that does not exist.
The app searches its own data *first*, hands the real matches to the model as
facts it must use, and turns those matches into **buttons that open the
thing** — tap one and you land in the command library with it open, or on the
quest. A button can never lead somewhere that does not exist, because it was
built from a real entry rather than from the model's output.

If every model is unreachable the grounded matches are still shown, so the
answer arrives anyway. That path is tested with the network blocked.

**A real bug found while testing this:** four providers at a 35-second timeout
each is 140 seconds of spinner before the local answer everyone was going to
get regardless. Measured against the live service a good reply lands in two to
six seconds, so the timeout is 14s and the free providers race rather than
queue. The admin's own model is still tried first and alone — somebody paying
for a model should not have it raced against free ones.

It answers general questions now. Only two things are refused, both decided
locally before anything leaves the device: privacy — passwords, keys, other
people's accounts — and genuinely illegal requests. Forwarding a request for
somebody's password to a third-party API is not a refusal, it is a relay.

"Do it for me" appears only after two replies with nothing to act on, and it
is a second explicit tap on a labelled button. A command that fires because a
model thought you wanted it is the one failure this tool must never have.

### Clearing the chat moved to the console

The player-facing "clear" button is gone. It wiped only that one device's
copy — which reads as moderation and is not, since everyone else still saw
every line — and it destroyed the only record of an incident at the moment it
mattered most.

The console can now clear the messages and the command feed, with the scope
stated plainly rather than implied: **it clears this device's stored log.**
There is no server to purge, because a public broker relays live traffic and
keeps nothing, so copies on other people's phones are beyond any console's
reach. Saying so is better than a button that quietly does less than it looks.

### Ready to publish

`deploy/` now holds a `_headers` file and a hosting guide, and the build copies
the headers into `dist` so a deploy cannot ship without its
Content-Security-Policy because somebody forgot a step.

**Cloudflare Pages** is the recommendation, decided on two things rather than
a feature list: GitHub Pages **cannot send custom headers at all**, so the
entire security policy would be silently ignored there — and Cloudflare is the
only free tier with unlimited bandwidth, which matters when the file is 4.8 MB.

### Also

- The official-site view is removed. Real data, honestly labelled, and useless:
  a fact about somebody else's website that changed nothing a player here could
  act on, costing a third tab in a two-tab switcher and a socket held open for
  the life of the app.
- The room's two sliders were unreadable — "Messages a person may send" with
  the unit split across two places. They now read as whole sentences with the
  unit in the readout, and each carries an icon.
- New suite `verify-brain.ts`: 43 checks over grounding, navigation, refusals,
  and persistence across an actual reload.
- `verify-translate` no longer fails the build when a free translation service
  degrades. SimplyTranslate was observed returning `200` with empty text — not
  something a client can fix. The suite reports each engine and asserts the
  property that matters: enough work that one dying is invisible.

---

## 1.2.3 — a gift that arrives from you, by name

### Gifts are delivered as in-game mail, signed with your character's name

A gift used to drop the item straight into the friend's inventory: it worked,
and it was anonymous. Now it arrives in their mailbox headed by **your**
in-game name, with a note you wrote.

This is Grasscutter's `sendMail`, and the sender line is a genuine free-text
field — read out of the command's source rather than guessed at:

    SendMailCommand.java — mailBuilder.mail.mailContent.sender = msgSender

**Why it is a sequence and not one command.** `sendMail` is a *stateful
composer* on the server. It keeps a builder per sender and advances one stage
per message, with no keywords at all:

    /sendmail <uid>       open the composer
    <title>               stage 0
    <body>                stage 1
    <sender name>         stage 2   ← the whole point
    <itemId> <amt> <lv>   stage 3, repeatable
    /sendmail finish      send

Order is therefore everything, and a single line out of place is invisible in
the result — the body silently becomes the signature and the mail still
"sends". Two consequences are built in:

- Every stage goes through the existing paced gift queue, which drains
  strictly front-first. A burst would arrive scrambled.
- Newlines are collapsed before sending. A newline inside your note would be
  read as the *next* stage, so half your message would become the sender name
  and your name would become an item id.

The name is your character's, not your login — that is who the friend
actually knows — falling back through the account name so the field is never
empty, which the server would read as a stage.

### The gateway cannot validate anything, so the app does not pretend it can

Measured on the live gateway with 9-second gaps to stay clear of the rate
limiter. These four all return **the identical** `retcode 200, "Command
queued, position #26"`:

    /sendmail 110146356
    /sendmessage 110146356 hi
    /announce hi
    /zzzz_bogus_nonsense_9182      ← deliberate nonsense

The gateway is a queue, not a parser. "It queued" proves nothing whatsoever,
so the only honest gate is the published command set: the mail option appears
on Grasscutter and is **absent** on the official-protocol engine, where the
panel says the gift will arrive without your name on it rather than sending
hopefully and reporting success.

### What was asked for and cannot be done

The request also asked for the gift to appear **inside the chat conversation
with your friend**, as a message from you rather than from the system.

That is not possible and it is worth being exact about why. The in-game chat
window is drawn by the game client from packets the game server sends. This
app has no game client and no game server — it hands command text to a web
gateway that queues it. Neither engine's command set has anything that injects
a line into another player's chat as though a player typed it; Grasscutter's
`sendMessage` exists and its own help text says it sends *"as the server"*.

The mailbox is the one place in the game where a message genuinely carries a
player-chosen sender name, which is why the gift goes there.

### Also

- The command preview is shown in mail mode too, listing the composer's exact
  lines. Hiding it was a mistake the suite caught: a multi-step sequence where
  a wrong stage is invisible in the result is *more* worth showing, not less.
- A TDZ crash caught before it shipped — a `createMemo` declared above the
  arrow consts it reads takes down the whole panel on first run, not just the
  preview.
- An offline send is refused rather than half-queued, so a partial mail cannot
  be flushed out of order when the socket returns.
- New suite `verify-giftmail.ts`: 35 checks over the stage ordering, the
  newline defences, engine gating, and all five languages.

---

## 1.2.2 — translation that follows you, a readable command feed, a Translation section

### The chat was not translating, and the reason was structural

Two faults, both in the same mistake. A message's translation was computed
once, when it arrived, and written into the message. The reader's language
was read from a plain module variable at that instant.

So: switch the app to English and every Arabic line stayed Arabic, because
nothing re-ran. And your *own* messages were never translated at all — the
code short-circuited on "this is mine", so an Arabic speaker reading the room
in English saw everyone else in English and themselves still in Arabic.

A translation is a **function of** the reader's language, not a snapshot taken
at arrival. Messages now keep the original plus a map of translations by
locale, and an effect fills in whatever the current language is missing.
Switching languages re-derives the whole log; switching back is instant and
the original is never lost.

The engines were never the problem — all four answer from `file://`, verified
in a real browser, which is the only place the question is meaningful because
a local file sends `Origin: null` and that is what a service rejects. gtx,
clients5, MyMemory and SimplyTranslate are tried in order; three share no
infrastructure, so one going down is survivable.

The cache now survives a reload — and a second bug was found writing this: the
debounce reset its own timer on every message, so on a busy channel the write
*never happened*. The first write of a burst is now scheduled and left alone,
and there is a `pagehide` flush for the phone browser that kills a backgrounded
tab without warning.

### A Translation section, because it was scattered across three places

New section in the console. What is translated (chat, command names, support
replies, your own text — each independently), which engine and in what order,
with live success counts per engine so a failing one is visible rather than
guessed at. A preview box that runs the real engines against the *unsaved*
draft. The cache size and a button to clear it.

And the reader-facing controls are now the admin's to remove: the header
language picker and the "translate messages" checkbox above the chat can each
be hidden. A single-language server has no use for either.

### The command feed says who did what, once

It printed raw command lines — `/give 11101 x5 lv90` — which is noise to
everyone except the sender, and twenty of them in a row buried the room. It
now reads *"Prok used the command give ×5"*: the person, the command's name,
and a count. Repeats from the same person inside five minutes collapse into
one row. Command names go through the translator like everything else; the
ids and quantities are dropped, which is also why nothing identifying reaches
the feed.

Two real bugs surfaced building this, both caught by the suite rather than by
reading:

- **A read-then-write race.** Five commands shared in one synchronous loop all
  read the same pre-loop value, all concluded "no matching row", and produced
  three rows instead of one. The merge decision has to happen *inside* the
  updater, where Solid hands you the current value.
- **The duplicate guard scanned the visible rows.** Once repeats merged, the
  merged row took the newest id and the older ones vanished from the list — so
  the broker's echo of an earlier id found no match and merged a second time.
  Five shared commands became nine. It is a bounded `Set` now.

### The download list survives the site being taken down

It was fetch-or-nothing: a fresh install with no cache and no reachable feed
showed an empty tab, and if the upstream host went away it would be empty for
everyone, permanently. A scrubbed catalogue snapshot now ships inside the file
as the floor — live feed first, then this device's cache, then the bundle.
Verified with every upstream request aborted.

**The honest limit:** this preserves the *catalogue* — every name, URL,
version, checksum and note — not the files. A single HTML document cannot
carry multi-gigabyte game archives, and saying otherwise would be a lie
discovered at the worst possible moment. If the host disappears, what you have
is a complete record of what existed and where, which is what makes finding a
mirror possible.

### The console, tidied

- **A genuinely duplicated control, found by counting checkboxes rather than
  by looking.** Whether the Support tab appears was settable in two places —
  the assistant section and the tab list under Layout — so turning it off in
  one left the other still ticked. Tab visibility has one owner now: the tab
  list. The assistant section is what the assistant *does*.
- "Chat tab" was renamed to "Public chat" and its description corrected: chat
  is reached from a floating button and has not been a tab for two releases.
- The three paragraphs under the filter word lists are gone. They explained
  what the fields already say. Two compact side-by-side lists with live
  counts, and one line of hint.
- "Facts about your server" is removed.
- **New room controls, which did not exist:** room name and broker (so a
  community can have a channel of its own), a per-person rate limit — a word
  list does nothing about flooding, and thirty lines a minute kills a channel
  as effectively as abuse — a maximum message length, a read-only switch for
  cooling a channel without deleting it, and switches for command sharing and
  the official-site view.
- A refused send now says *why*: "the admin closed the channel", "you are
  sending too fast" and "not connected" were all being reported as the last
  one.

---

## 1.2.1 — a private line to the admin, an encrypted room, a filter that speaks 25 languages

### Messaging the admin is its own door, not a button in the chat

Reaching a person and asking the assistant were sharing one control. Pinning
the first to the second meant the entire transcript was sent whenever somebody
wanted to say one sentence — every typo, every test, every answer already
given — and the admin had to read a page of noise to find the message actually
addressed to them. Worse, the button only appeared *after* the assistant
failed, so wanting to talk to a human required first asking something nobody
could answer.

It is now a screen of its own, reached from an envelope in the support header,
before a word is typed. One message, written deliberately, is what is sent.
What has already been sent is listed underneath with whether the admin has
marked it handled, so nothing disappears into a void.

A pasted password is caught **before** the message is filed, not redacted
after. The old code only recognised `password: hunter2`; "my password is
hunter2" — how a person actually writes it — went straight through. Fixed in
all five languages, and found by testing the sentence rather than the pattern
the code was written against.

### Everything crossing the broker is now ciphertext

The room runs on a public MQTT broker, which is what makes a serverless group
chat possible at all. The honest cost was that the topic is world-readable:
anyone who guessed the room name could subscribe with any MQTT client and read
every line, and so could whoever runs the broker. Messages went over it as
plain JSON.

They are AES-256-GCM now, with a fresh nonce per message and a key derived per
room, so a frame published to one room cannot be opened in another. Verified
by sealing a 29-character canary in a real browser and confirming it appears
neither in the frame nor in the decoded payload, and by carrying a message
between two separate browser profiles end to end.

**The limit, stated rather than dressed up:** the shipped key is inside the
file, so everyone holding the app holds it. This is confidentiality against
outsiders and the broker — not against other players. An admin who wants a
genuinely private room sets their own passphrase in the console, and then the
guarantee is real for anyone they have not given it to.

### The profanity filter: 22 words became 2,668

The old list was 65 hand-written stems across five languages. It was a
gesture. The list is now built at release time from LDNOOBW — the list
Shutterstock publishes — curated, graded and frozen into the file: **2,668
terms across 25 languages**, nothing fetched at run time.

Three things had to be got right and each was measured, not assumed:

- **The build silently ate four languages.** A junk filter written as `\W`
  means "not `[A-Za-z0-9_]`", so every Arabic, Korean, Thai and Chinese row
  counted as punctuation and was discarded — all 38 Arabic, all 72 Korean, 311
  of 319 Chinese — and the build still printed success. The per-language
  counts are now printed precisely so a collapse like that cannot pass unseen.
- **Severity, not one wall.** A racial slur and the word "anal" are not the
  same offence, and a filter masking both is one players learn to laugh at.
  Every term is graded and the admin picks a level; level 2 is the default.
- **Two views of every message.** Making short Latin terms whole-word-only to
  stop `analysis` being masked broke `f.u.c.k off`, because the stripped form
  is `fuckof` and the boundary test then rejects it. The matcher now keeps
  both a fully-stripped view for long and CJK terms and a spacing-preserving
  one for short terms. Caught by the test suite, not by review.

Arabic now folds its letter variants (`أ إ آ ى ة`) and strips harakat and
tatweel, so one stored stem covers the spellings people actually type.
Verified against 15 languages of real abuse and 6 innocent sentences —
Scunthorpe, `a class assessment`, `run the analysis again` — all left alone.

### The assistant's replies can be told apart

The colour coding added last release could not be seen, and the reason was
measurable rather than aesthetic: 8% of the accent over a dark card is a
two-value luminance difference, below what a phone screen resolves in
daylight. Each reply now carries a 3px stripe in the full-strength colour and
a labelled header — *AI answer*, *Best guess*, *Cannot answer*, *From the
admin* — because colour alone fails for a colour-blind reader and fails again
on a theme where two accents sit close.

The first attempt at the stripe used `ltr:border-l-[3px]`, which the CSS
generator read as a *colour* and rendered as a 1px default: the class was
there, the intent was clear, and the stripe was invisible for a completely
different reason. Now a logical `border-s-3` — which also puts the stripe on
the right in Arabic with no second rule — and the suite asserts on the
computed width rather than on the class name.

`what is my password` was being answered like an ordinary question, because
the refusal list only knew about *somebody else's* password. It is the same
refusal either way.

### The official console, watched live

The command feed was limited to people running this file, which is a small
room. It now also shows everyone signed in to the official console right now,
with their language and role, alongside the live in-game, on-site and queue
counts. Commands are tagged with where they came from.

**What the gateway does not provide, and why nothing here pretends
otherwise.** Captured over 75 seconds and again over 240 seconds on separate
days: an anonymous socket receives the roster and the online counts and
*nothing else*. No event of any name carries another player's command; 42
consecutive samples had the queue counter at zero; `/command/list`,
`/command/history` and `/api/command/recent` answer 404, 405, or a rate-limit.
A feed of "what everyone on the official site is running" would have to be
fabricated, and a fabricated feed is worse than an empty one because it is
believed. The panel says exactly what it shows and what it cannot.

### Also

- Your own command appears in the feed whether or not the broker is reachable
  — hiding it because a public service is down made the feed lie about you.
- A new suite, `verify-room.ts`: 47 checks over the filter in 15 languages,
  the encryption envelope, the admin message screen, the reply labelling and
  the official roster.

---

## 1.2.0 — a chat that actually works, an assistant instead of canned rows

### The chat now carries messages between people

The official gateway broadcasts only to sockets it has authenticated. Measured
repeatedly on the wire — 50 seconds, 8 online-count updates, 12 roster
updates, **zero messages** — an anonymous socket never receives chat. That is
the server’s rule and no client change alters it, so a chat built on it was
an empty box for everyone not signed in. Which is exactly what you saw.

Chat is now a room for **this app’s** users: everyone running this file can
talk to everyone else running it, signed in or not. It goes through a public
MQTT broker over WebSocket, which needs no key and no backend — verified in
two real browsers before being built on, and there is now a test that fails if
a message typed in one browser does not arrive in another.

Two honest limits, both stated in the panel: a public broker is public
infrastructure and can be slow or gone, and there is no history, so what you
see is what arrived while you were connected plus what this device kept.

The command feed is fed by the same room. Everyone using the app sees who ran
what, which the gateway could never provide — it does not broadcast other
players’ commands at all.

### Fixed

- **Your own message never appeared.** A broker is not obliged to deliver a
  message back to the client that published it, and this one does not, so the
  sender saw everyone else and never themselves. It is shown immediately on
  send and de-duplicated by id if an echo does arrive.

- **"Operator" is now "admin"** throughout, in all five languages.

- **Reaching a person was buried.** The offer appeared only after the
  assistant failed, attached to that one reply — so wanting a human meant
  first asking something unanswerable. It is its own button now, always there.

### Changed

- **The canned-answer list is gone.** It was a list of keyword rows to
  maintain in place of an assistant that answers — the opposite of what was
  asked for. What replaces it is one box: state what is true of *your* server
  in plain sentences, and it is handed to the assistant with every question.
  One paragraph covers what a dozen keyword rows could not.

- **Replies are colour-coded by what kind of answer they are.** A refusal is
  red, a best guess is amber, a settled fact is plain, a model answer and an
  admin-written one each have their own tint. Reading five different kinds of
  claim as one grey wall is why a conversation stops being scannable.

### On the browser reverting desktop mode

Checked directly: the app ships `width=device-width`, stores nothing about
layout, and no script touches the viewport tag — verified against the built
file. Following a reload at 980px it stayed at 980px. The reset you are seeing
is Brave’s own behaviour for a `content://` URL, which is a fresh one-shot
address each time, so there is nothing for it to remember the setting
against. Opening the file from a normal path, or hosting it, will hold.

### Notes
- 1,062 tests across 21 suites, all passing.

---

## 1.1.9 — the browser decides the layout, Support tab reaches the console, a command feed

### Fixed

- **The app was permanently stuck in the desktop layout.** My own detection
  code caused it. It looked for Android’s "Desktop site", stored a flag, and
  from then on forced `width=980` — so after a single desktop-mode visit the
  wide layout was applied on every load afterwards, including on a phone in
  normal mode, with no way out.

  Looking at the official site settled it: `ps-new.yuuki.me` uses a plain
  `width=device-width` tag and **no script for this at all**. That is already
  the correct behaviour — it means "lay out at whatever width the browser
  says", which is the phone width normally and about 980 when the user picks
  Desktop site. The whole module is deleted. A test now asserts the app
  stores nothing about layout and that a stale flag from an older build
  cannot force it.

- **Support was missing from the console’s tab list.** It appeared in the
  app’s bar but could not be renamed, reordered, hidden, or made the landing
  tab — and nothing said why. Download had exactly this fault before it, so
  the fix comes with a check that compares the two lists and fails when they
  drift.

### Added

- **A command feed inside chat.** A second view beside the conversation,
  read-only, with its own unread dot. Commands and conversation are different
  traffic and mixing them ruins both: a busy server pushes a command every
  second or two, which buries a conversation, and a conversation buries the
  one command somebody wanted to copy.

  Its limit is stated in the panel rather than implied: the gateway broadcasts
  chat but **not** other players’ commands — checked on the wire, there is no
  event carrying them — so the feed shows what this device has run. A feed
  labelled "who is running what" that silently held only your own would be a
  lie about the server.

- **Ready-made questions in Support, and a box that does not require choosing
  a topic first.** The four buttons pick a *subject*; these are the questions
  people actually arrive with, phrased the way they phrase them. They are
  built from the knowledge table rather than written out again, so a
  suggestion cannot promise an answer that no longer exists — and answers the
  operator adds appear among them. Requiring a topic before typing was a wall
  for anyone who already knew what they wanted to ask.

- **The chat button has its own edge.** It followed the console launcher,
  which is fine until you want one on each side and there is no way to say
  so. They still start together and only offset when they would collide.

- **The unread dot colour is yours.** On both docks. Red by default because
  that is what an unread marker is expected to look like.

### Removed

- **"Import built-in" in the Assistant section.** It was a misreading of the
  request: the answers wanted were the ones players see as suggestions, which
  is what the ready-made questions above now are.

### Notes
- 1,059 tests across 21 suites, all passing.
- The layout fix was found by reading the official site rather than by
  reasoning about my own code, which had a plausible-sounding explanation for
  every part of what it did.

---

## 1.1.8 — desktop mode follows the browser, one chat connection, editable built-in answers

### Fixed

- **Two chat connections instead of one.** The dock and the panel each built
  their own client. That is two sockets to the same gateway from one app, and
  it is wrong three ways that all look like "chat does not work": the server
  saw two clients for one player and chose which to broadcast to; both wrote
  to the same stored history, so a message could be saved twice and one
  write could clobber the other’s translation; and a message sent from the
  panel arrived on a socket the unread count was not watching. There is one
  shared session now — verified as exactly one WebSocket after opening chat.

- **The layout switch is gone; desktop mode is automatic.** A second control
  for something the browser already controls is two places to set one thing,
  and they disagree the moment you touch either. The app now detects that the
  browser is laying the page out wide, remembers that, and re-creates it on
  the next load — which is what was needed, because a `content://` URL is a
  fresh origin every time and the browser cannot remember it itself. Turning
  desktop mode off in the browser clears the flag, so the browser stays the
  single place this is decided. A real tablet is not mistaken for a phone in
  desktop mode; that case is tested.

- **"I do not have a reliable answer" was an apology, not help.** It now gives
  the three checks behind most problems here — the status dot, the selected
  character, the matching server — and then offers to send the question on.

### Added

- **Five more subjects the assistant knows**, taking it to fifteen: game
  version and updating, artifacts and their stats, characters and
  constellations, rate limiting and why batches are paced, and saved quests.

- **The built-in answers are importable and editable.** Until now the
  assistant’s knowledge was invisible in the console: you could add answers
  but not see, reword, or switch off the ones already being given. One button
  copies all fifteen in as ordinary rows, in the console’s language, each
  with its own enable box and delete. Pressing it again updates rather than
  duplicates, because the obvious thing to do after editing one is press it
  again.

- **Conversation history is always reachable.** The button was hidden until a
  log existed — a discoverability trap: nobody learns the feature is there, so
  nobody expects conversations to be kept, so nobody looks. It shows a count
  now, and explains itself when empty.

- **A "floating buttons" group in Layout.** The console launcher and the chat
  button sit *over* the app rather than in the bar, and they were configured
  in two different sections — the chat one under Chat, the console one nowhere
  at all. They are one subject now, each with its own icon picker, an on/off
  switch, a choice of which edge to sit on, and the unread dot as a separate
  setting. The side follows the reading direction rather than being pinned to
  a physical side, so it lands correctly in Arabic.

### Notes
- 1,057 tests across 21 suites, all passing.
- Chat still shows nothing to a signed-out reader, and that is the server’s
  rule rather than a fault here: measured again over a 60-second window with
  people online — 15 roster updates, zero messages. The empty state says so.

---

## 1.1.7 — custom tabs behave like real tabs, a filter you can test, answers you can write

### Fixed

- **A tab you added could not be ordered, hidden, or made the landing tab.**
  The ordering list filtered itself to built-in tabs only, so a custom tab
  appeared in the app’s bar but nowhere in the console — and nothing said
  why. It now sits in the list like any other, marked as yours, with the same
  arrows, the same hide box and the same home button.

- **A custom tab showed as a blank square and could not be renamed there.**
  Its icon lives in its own record while the ordering list read only the
  override map, and renaming wrote to the translation table — which a custom
  tab does not use. Both now read and write the tab itself, so the two cannot
  disagree about what it is called or what it looks like.

### Added

- **A live preview of the bottom bar.** Ordering by pressing arrows on a
  vertical list is a poor model of a horizontal bar: you are editing one
  arrangement while picturing another. The bar is drawn as players will see
  it, with the landing tab highlighted. Two warnings that state a fact rather
  than a vague worry: past six tabs the labels start clipping on a narrow
  phone, and hiding every tab would open the app on a blank screen.

- **Your own words in the chat filter, and your own exceptions.** A shipped
  list is always wrong at the edges for a specific community — it misses their
  slang, and it masks ordinary words, usually names, for everybody. Both are
  now editable, and neither was fixable before without editing the source.

- **A filter tester.** Type a sentence and see exactly what players would see,
  with your lists applied, before publishing. A word list is guesswork until
  you watch it mangle a real sentence — the commonest mistake is a stem that
  silently eats half an innocent word.

- **The floating chat button is separately switchable.** Chat and the
  always-connected dock are different costs: the dock holds a socket for the
  whole session so the unread dot can mean anything at all. An operator can
  now keep chat and drop that.

- **Answers you write yourself, for the assistant.** The most useful thing a
  support tool can offer is a way to add the answer to the question you are
  tired of being asked. Before this the only routes were editing the source or
  paying for a model, neither of which is available to the person actually
  reading the reports.

  They are matched on keywords and tried *before* the built-in table, so they
  also correct a shipped answer that reads badly for a particular community.
  Written in one language; Apply translates them into the rest. A warning
  fires on a keyword short enough to swallow unrelated questions.

### Notes
- 1,055 tests across 21 suites, all passing.
- Verified end to end: an answer written in the console reaches a player’s
  assistant and is used in preference to the built-in one.

---

## 1.1.6 — the assistant answers with a real model, chat sends, desktop mode adopted

### Fixed

- **The command name field was empty.** It showed only an *override*, so for
  every command that had never been renamed there was nothing in it — you
  could not see the name you were about to change, and editing meant retyping
  it from the heading above. It now shows the effective name: the operator’s
  wording, else the bundled translation, else the raw English. A reset button
  appears once there is something to undo.

- **Chat sent nothing, and the reason was subtle.** Measured on the live
  gateway: `emit('chat', { input: 'hi' })` draws a reply, while the same emit
  carrying `session: '', id_player: ''` draws **silence**. Empty credential
  fields are not the same as absent ones — the server treats them as a
  malformed frame and drops it without answering. My own "announce" was
  sending exactly that shape, so it was suppressing the server’s own error
  message. Blank fields are now omitted entirely.

  Server notices (`uid: 0` — "You must be logged in to chat", rate limits) are
  shown as warnings instead of being filtered, translated and mistaken for
  silence. They are not persisted: a stale "sign in" replayed tomorrow is
  worse than none.

- **Desktop mode reverted on every reload, and no page can stop that.**
  Android remembers "Desktop site" per origin, and a file opened through a
  content provider gets a fresh one-shot URL each time, so the browser has
  nothing to key against. What the app *can* do is notice desktop mode is on
  and adopt it as its own setting — then re-create the same wide layout on the
  next load, when the browser has forgotten. Detection compares the layout
  viewport against `screen.width`, so a real tablet is not misread; that case
  is tested.

- **A game question was refused as off-topic.** "can I change the weather in
  Liyue" hit a bare `weather` entry in the block list. Every entry is a phrase
  now. Over-blocking is the worse failure: someone asking a genuine question
  and being told "I only discuss the app" does not come back.

### Changed

- **Chat is no longer a bottom-bar tab.** It opens from the floating button
  beside the console launcher, which is where something you dip into *while
  doing something else* belongs — a tab means leaving the screen you were on,
  and could not carry the unread dot.

- **Reports open in their own screen.** Listed inline they put a wall of
  message text between the settings above and the diagnostics below. The
  section now shows one button with a waiting count; the reports get a
  full-height view, unhandled first.

### Added

- **A model that needs no key.** Pollinations serves GPT-OSS 20B to anonymous
  callers over an OpenAI-compatible endpoint, verified against the live
  service. The assistant now reaches a real model out of the box.

  Three honest limits, all handled in code rather than in a promise: it is a
  free public service and may be slow or down, so the local table is tried
  first and any failure falls back to the frame answer rather than to silence;
  anonymous means shared, so redaction and the privacy refusals both run
  *before* any request leaves; and an operator who wants their own model puts
  a key in the console and this is bypassed entirely.

### Notes
- 1,055 tests across 21 suites, all passing.
- The assistant suite now waits for the reply rather than a fixed pause. A
  question that reaches the model takes as long as a free service takes, and a
  fixed wait made the suite flaky for a reason that had nothing to do with the
  app.

---

## 1.1.5 — the assistant understands, desktop mode sticks, an operator inbox

### Fixed

- **Desktop mode was cancelled by every reload, and it was never this app’s
  doing.** Android’s "Desktop site" is remembered *per origin*. A file opened
  through a content provider gets a fresh one-shot URL each time, so the
  browser records the setting against something that no longer exists and
  reverts. Nothing in a page can change that.

  What a page *can* do is ask for the wide layout directly, and remember the
  choice itself. There is a switch in the header now: it produces the same
  980px layout and survives a reload, verified 412px → 981px and still wide
  after reloading.

- **The assistant often answered nothing.** Three separate causes, all found
  and fixed. Chinese and Japanese have no spaces, so the word-splitting
  matcher produced one long token that matched nothing at all. Greetings,
  thanks, complaints and refusals had no path to a reply — they fell through
  to the same apology as a genuinely unknown question. And the bare noun
  "commands" made the tutorial outrank the fault answer.

  There is a proper reading layer now: it works out the *shape* of a request —
  broken, how-to, whether, where, why, request, complaint — before looking for
  a subject. "how do I fix commands not working" and "how do commands work"
  share every keyword and now get opposite answers. Verified across 15 phrasings
  in five languages, plus every social turn.

- **Chat showed nothing.** Measured over two captures, 45 and 70 seconds, with
  7-10 people online: an anonymous socket receives the roster and the online
  count indefinitely and **never a single message**. The gateway broadcasts
  only to sockets tied to an account. The app now presents the session as soon
  as it has one and again on every reconnect, and the empty state says which
  silence it is — signed out, or simply quiet — instead of looking broken.

- **The console’s section bar was unreadable.** Ten sections across a 360px
  phone gave each 36px and clipped every label. It scrolls sideways now at
  73px per item, with the active section scrolled into view.

- **Cautions read as hints.** `--warn` was amber, which on this dark palette
  against grey text did not register as a warning at all. It is red now — a
  lighter, warmer red than `--bad`, so "be careful" and "this failed" stay
  distinguishable. One variable, so all 43 uses moved together.

### Added

- **A chat button beside the console launcher, with an unread dot.** It holds
  its own connection for the whole session, so the dot means *a message
  arrived while you were elsewhere* — a badge that only counts while the tab
  is open counts nothing worth knowing. Your own messages never raise it.

- **An operator inbox, replacing the unanswered-questions list.** That list
  filled with typos and idle testing: a hundred rows of noise per real report,
  and an unread list is worse than none because it looks like coverage. A
  ticket exists only because a player chose to send it, and that intent
  filters better than any heuristic. Each carries a diagnostic snapshot taken
  *at the moment of sending* — by the time an operator reads it the fault may
  have cleared, and "everything is fine" attached to "nothing works" is how a
  real problem gets dismissed.

- **Privacy and scope enforced before anything is sent.** Passwords, keys,
  another player’s account, server internals and hacking are refused outright
  and never relayed to a model — forwarding a request for someone’s password
  to an API is not a refusal, it is a relay. Off-topic questions are deflected
  narrowly, so a genuine game question is never turned away.

### Notes
- 1,052 tests across 21 suites, all passing.
- The new suite asserts frames directly rather than inferring them from reply
  text: a broken reader still *answers*, just wrongly, and nothing would show
  up as an error. It caught one real overlap — "does it" is a substring of
  "why does it keep disconnecting", so a fault report scored as a yes/no
  question.

---

## 1.1.4 — a reload keeps your place, commands speak every language

### Fixed

- **A reload threw you back to the landing tab.** The open tab was never
  stored, so every reload re-derived it from scratch. On a phone that is not a
  rare, deliberate act: the browser discards a backgrounded tab and restores
  it the moment you switch back from the game — precisely when you were in the
  middle of something. It is remembered now.

  The operator is not overruled by this. Their landing tab still wins when
  they *change* it, once, and after that your own place is kept again. Both
  behaviours are verified together, because either alone is the wrong answer:
  remembering forever means a newly published landing tab reaches nobody, and
  not remembering at all is the bug above.

- **Command names and descriptions were English in every language.** All 61
  missing descriptions are now translated into Arabic, Russian, Japanese and
  Chinese — coverage is 101/101 labels, 64/64 names, 67/67 options in all
  four. Machine-translated, then corrected by hand where the machine got the
  sense wrong: "character" as a game character rather than a letter, "Q" as
  the burst key, and `become god`, which Google rendered into Arabic as
  "become Allah" — offensive to a Muslim reader and unshippable. It is named
  for what the command does instead.

- **There was no way to rename a command for one language.** The name field
  edited the upstream English `head`, which is the key translations are
  matched by — so changing it silently broke the lookup for every *other*
  language. A separate "name players see" field writes a proper per-locale
  override, and the English field now says what it is for.

- **The support assistant never answered in Chinese or Japanese.** Those
  scripts have no spaces, so the word-splitting matcher produced one long
  token that matched nothing and fell straight through to "I have no answer".
  It now substring-matches for those scripts. Three more routing faults went
  with it: the bare noun "commands" made the tutorial outrank the
  troubleshooting answer for "الأوامر لا تعمل" and "commands do nothing".
  Seven questions across five languages now route correctly.

### Added

- **Apply fills in the other four languages.** You edit in one; publishing
  translates interface text, command names and custom tabs into the rest.
  Only gaps are filled — anything you already wrote for a language is your
  wording and is never overwritten by a machine.

- **Gifts: real controls.** The pause goes up to 15 seconds, not 6 — the old
  ceiling stopped short of the only remedy for a gateway refusing bursts. A
  batch cap that *refuses* rather than trims, because silently sending 40 of
  90 looks exactly like the server dropping the rest. A retry pass. And the
  arithmetic worked out for you: what your chosen pause means for 10 gifts
  and for 50.

- **Two rating prompts, each switched on separately.** The second used to be
  the first multiplied by five and could not be disabled alone — two
  decisions welded into one. They are independent now, with a warning if the
  second is set below the first, since that gate would never be reached.

- **Chat sits beside Commands,** shows the time on each message, lists who is
  connected and what language they write in, and keeps a local history. On
  history: the gateway has none. `/chat/history`, `/api/chat/messages` and
  every socket variant were probed and all return 404 — messages are pushed
  live and nothing more. So the app keeps its own record of what you have
  seen, which is honestly bounded and stated as such.

- **Support: a back arrow and past conversations.** Transcripts are kept on
  the device, redacted before they are written, because the likeliest thing
  in one is a session key somebody pasted. Three new subjects: queues and
  batches, changing language, and whether any of this is safe for an account.

### Notes
- 1,009 tests across 20 suites, all passing.
- Two crashes were caught in testing, both worth recording. Adding the
  landing-tab comparison beside `startTab` hit a temporal dead zone and broke
  the entire app on load — the same trap the rating feature already
  documents, in a new place. And three tests clicked `nav button` by index;
  moving Chat made index 4 the wrong screen, so they now name the tab.

---

## 1.1.3 — chat, a support assistant, live feeds made visible

### Added

- **Public chat, on the official gateway.** The protocol is undocumented, so
  it was read off the wire rather than guessed: `chat` to send, `chatRsp` for
  each message, `chat_user_update_public` for the roster. Two things fell out
  of that and both shaped the build — the gateway refuses an unauthenticated
  send (so the composer is hidden until you sign in, rather than failing
  silently), and the roster carries each person’s language, which is what
  makes the translation honest instead of guesswork.

- **Automatic translation, per reader.** Everyone reads the channel in the
  language they chose: Chinese arrives as Arabic, and your Arabic reaches a
  Japanese reader in Japanese. Translated **on arrival, for each reader** —
  not once on send, because a room has five languages being read at the same
  time and the sender cannot know who is listening. Commands, UIDs and links
  are masked out before translation and restored after, or `/give 11101 x5`
  comes back as `/يعطي 11101 x5` and no longer runs. The original is one tap
  away, because a translation is a guess.

- **Profanity filtering in all five languages.** It masks rather than blocks:
  a refused message tells the sender exactly which spelling to try next, and
  they will keep trying until one lands. Normalisation undoes the mechanical
  evasions first — digits for letters, repeated characters, punctuation
  inserted mid-word, Cyrillic lookalikes — so dozens of spellings collapse to
  one entry. Two real bugs were found and fixed while testing: `fuuuuck` got
  through (repeats collapsed to two, the stem had one) and "Scunthorpe" was
  censored. Short stems that occur inside ordinary words now match only whole
  words. Stated plainly in the console: a word list is a speed bump, not a
  moderator.

- **A support assistant, and it works with no AI key at all.** The common
  questions are narrow and repetitive, and are answered from a table inside
  the app — offline, instantly, in all five languages. A model handles the
  rest *if the operator supplies a key*, and the reason it is not built in is
  stated rather than glossed: this is one file anyone can open, so a key
  inside it is a key given away.

  The conversation opens with four buttons instead of a blank box, because a
  blank prompt makes people invent the shape of their own request and most
  answer it with "not working".

- **It investigates real faults, and repairs what it safely can.** Choosing
  "something is broken" runs actual checks against actual state: did each feed
  answer, is storage writable or full, is the published patch readable, are
  any values out of range, is the device online. A corrupt patch is removed, a
  full cache is pruned — both verified end to end. Anything upstream or on the
  network is *reported to the console*, not silently retried, because those
  are other people’s machines and claiming to have fixed one would send the
  operator away believing a live problem was solved.

- **Two console sections: Chat and Assistant.** Every switch, the filter, the
  translation, the API key, the model, the endpoint and the creativity dial —
  plus the list of questions the assistant could not answer, which is what
  tells you which answer to write next.

- **Your own tabs.** A real screen in the bottom bar, not a footer link that
  leaves the app. Name, icon, text and an optional button. Plain text only:
  the ad slot is the one place third-party markup runs, deliberately and with
  a warning, and a tab an operator types prose into must not quietly become a
  second way to inject script into every player’s copy.

- **Live updates, made visible.** Servers, commands and quests already
  refreshed from the official feeds — a server added upstream appears within
  the minute, and set 2 currently carries 42 commands against the 37 this
  build shipped with. What was missing was any way to *see* it. Every refresh
  fails soft by design, so a broken feed looks identical to a working one; the
  console now shows when each last answered, with how many rows, and why it
  failed.

### Fixed

- **Renaming a built-in command was impossible.** The pencil revealed an
  editor that kept its own collapsed state, so it took two clicks on two
  different controls and the first appeared to do nothing but print the name
  again. One arrow now opens one thing.

- **Settings hide behind an arrow.** Each group is a heading and a switch;
  the detail appears when asked for. Collapsing is separate from switching
  off, so closing a panel never changes what the app does.

### Notes
- 1,047 tests across 20 suites, all passing.
- A flaky security assertion was found and fixed: it sealed `{ secret: 42 }`
  and checked the base64 did not contain "42", which fails about 1.3% of the
  time by chance — measured at 5 false alarms in 400 runs. A flaky security
  test is worse than none, because the first reaction to it failing is to
  assume it is flaky again.

---

## 1.1.2 — the side rail removed, the black lock screen fixed, settings regrouped

### Fixed

- **The console opened to a black screen with a padlock.** With a remembered
  session, the holding panel drawn before resuming carried no `id`, and the
  code that clears the gate looks for `#gate`. So the console mounted
  *underneath* a full-screen black overlay: a working interface, completely
  hidden. One missing attribute; the whole panel was unreachable.

- **The desktop layout is gone and the app is one interface again.** The
  navigation rail and the phone/desktop switch are removed. They also broke
  the console, which shares `.app-frame`: the rule that indented the page by
  15rem to make room for the rail applied there too, pushing the panel off the
  edge of the display — that is what "choosing desktop mode locked it" was.

- **A reload signed you out.** The boot code dropped the session key on *any*
  error, so a phone changing networks or a slow gateway wiped a perfectly
  valid key and asked for the password again. Only a genuine rejection —
  something naming a retcode, an expired or invalid token — discards it now. A
  network failure leaves the key alone and the existing reconnect logic
  recovers on its own.

- **Command names were English in the console while Arabic in the app.** The
  app runs every schema string through `tHead`; the console printed the raw
  catalogue value. An operator working in Arabic saw `/giveall` in one place
  and "منح الكل" in the other with no way to match them up. The raw name is
  still shown underneath in small type, because that is what upstream calls
  it and it is needed for comparison.

- **Download was missing from the tab list.** It could not be renamed,
  reordered, hidden, or made the landing tab, and nothing indicated why. The
  app's bar has six tabs; the console listed five.

- **"Choose File / No file chosen" stayed English.** A browser draws that text
  inside a file input in its own locale and no page can translate it. The
  input is hidden and labelled by the console instead, so the wording follows
  the console language like everything else.

### Changed

- **Every setting now owns its controls.** Settings were filed by *type*: the
  backdrop's switch under "feature switches" in Overview, the video it plays
  under Appearance, and the darkening that decides whether text stays readable
  nowhere at all — it was hard-coded. Changing the background meant knowing it
  was three places, with nothing to suggest the other two existed.

  A switch and everything belonging to it are now one group, indented under
  it, revealed when it is on:

  · **Background** — image or video, motion on/off, darkening, accent tint, blur
  · **Server detection** — plus the deep probe
  · **Gift sending** — plus the pause between gifts
  · **Rating prompt** — plus how many commands trigger it
  · **Copy protection** — plus whether command text stays copyable
  · **Blank when switched away** — with its limits stated in the panel

  Three of those controls did not exist before; they were constants in the
  source. Nothing is in two places: Appearance keeps the logo only.

- **Tabs are fully editable in Layout.** A pencil on each opens a rename box
  and a 40-icon picker in place. The rename writes to the same text override
  that tapping the label in the preview produces, rather than a second store
  that could disagree with it.

### Security

- **Screen-capture resistance, honestly bounded.** There is no screenshot
  event on the web and there cannot be one — the system recorder reads the
  compositor's output, far below anything a tab can see, and `FLAG_SECURE` has
  no web equivalent. What *is* observable are the side effects: the capture
  key combination stealing focus, and the preview thumbnail changing the
  visual viewport without changing the layout viewport. Both now blank the
  content. This defeats a casual screenshot and shoulder-surfing; a determined
  person with a second camera still gets the picture, and the panel says so.

### Notes
- 1,006 tests across 20 suites, all passing.
- The version counter carries at nine, so this follows 1.1.1.

---

## 1.1.1 — a real desktop layout, a session that survives a reload, editable icons

### Fixed

- **The computer browser was never showing a desktop interface.** The report
  was that reloading "turns it into the mobile interface". It had never been
  anything else: on a 1440px monitor the app drew one narrow column adrift in
  the middle of the screen with a six-button thumb bar glued to the bottom
  edge. Two separate things were wrong and both are fixed.

  The layout is now genuinely different on a wide screen — navigation moves to
  a labelled rail down the side, the thumb bar is removed rather than
  restyled, and the content column keeps a readable measure beside it. The
  panels themselves are unchanged; rebuilding them would be a second interface
  to maintain and every divergence between the two would be a bug reported on
  one and not the other.

  Separately, which layout to draw was being decided from `innerWidth` at
  load. A desktop browser has not always finished sizing the window by the
  time a reload's scripts run, so a maximised window could report a phone
  width — and only after a reload, because a fresh tab happens to be sized by
  then. That is exactly the shape of the complaint. It follows a media query
  now, which the layout engine evaluates against the real viewport and which
  cannot race.

- **The layout and the sizing disagreed with each other.** They asked the same
  question in two places — one at 640px, one in the stylesheet — so a 700px
  window took the desktop measurements while drawing the phone interface.
  There is one decision now, in `lib/device.ts`, and everything reads it.

- **The console asked for the password on every reload.** The credentials only
  ever existed in a module variable, so a refresh started over. See below.

### Added

- **A layout switch, and it is remembered.** Automatic follows the window;
  the other two settings pin it. A stored choice survives a reload instead of
  being re-derived from the window every time, and forcing the compact layout
  now also switches to the phone measurements — with the old split it gave
  the compact interface at desktop scale, which is neither of the two things
  on offer.

- **Stay signed in, without the password ever being written down.** The
  obvious implementations are all worse than the problem: the password in
  cleartext, or the derived key as raw bytes, which is the same thing wearing
  a hat. Instead the browser generates a **non-extractable** key — one it will
  use but will never hand back, where `exportKey` throws — keeps it in its own
  key store, and only the encrypted credentials are written beside it.
  Copying the profile elsewhere carries nothing usable. It is off by default,
  expires after 12 hours, and a lock button in the header ends it.

  The honest limit, stated plainly: someone at the unlocked machine in that
  browser profile can ask the same key to decrypt the same blob. Any "stay
  signed in" is a machine that can unlock itself. That is why it is a choice
  and not the default.

- **Every icon has a pencil.** Edit-in-place could rename any word, because
  words pass through the translator and can be traced back to a key. Icons
  had nothing to point at. They are now named by where they sit — `tab:gift`,
  `role:layout` — derived from the DOM when tapped, so nothing had to be
  tagged at several hundred call sites and no attribute ships to players. Tap
  an icon in the preview, pick a replacement, apply. An icon with no
  distinguishing context is keyed by itself and every copy changes together,
  which is almost always what was meant and, unlike a positional path, does
  not break silently when a panel gains a row.

### Security

- **Argon2id replaces PBKDF2 for the console's key.** PBKDF2 at 600,000
  iterations is defensible and has one weakness no iteration count fixes: it
  needs almost no memory, so an attacker runs tens of thousands of guesses in
  parallel on a GPU while the honest operator waits on one phone. Argon2id is
  memory-hard — each guess must hold 46 MiB — so the same second of the
  operator's time buys one to two orders of magnitude more attacker cost. It
  is OWASP's first choice and the PHC winner, at OWASP's named parameters.
  Measured at ~0.9s here, and *cheaper* than the PBKDF2 it replaces.

  Workspaces sealed by earlier builds still open: the version tag on the box
  selects the derivation, and anything re-saved is upgraded in the course of
  ordinary use.

- **A Content Security Policy on both files.** `object-src`, `base-uri` and
  `form-action` are closed, and `connect-src` is limited to the hosts the
  protocol actually uses — so injected code cannot post a session token to an
  arbitrary server, which is the failure that would matter most here. What a
  policy can be worth in a single inline-everything file is limited and is
  documented as such rather than oversold: `script-src` must allow inline,
  because the app *is* inline.

  `frame-ancestors` is deliberately absent. Browsers ignore it in a `<meta>`
  element, and a directive that silently does nothing is worse than none
  because it reads as handled. Framing is refused in script instead, which
  does work from `file://` — this app holds a live game session, and an
  invisible frame under a decoy is the classic way to make someone's clicks
  land on controls they cannot see.

### Notes
- 1,016 tests across 20 suites, all passing — including two new suites that
  cover the reload cases specifically, because a first load was always fine
  and that is precisely why these survived so long.
- This release was first cut as 1.2.0, which skipped eight numbers: the
  previous build was 1.1.0, and the next one along is 1.1.1. The counter is
  enforced in `scripts/release.ts` now rather than left to whoever is
  editing the file to remember.

---

## 1.1.0 — edit any label by tapping it, desktop reload fixed

### Added
- **Edit-in-place.** Open the preview, switch editing on, tap any word in the
  real interface and rename it. This replaces the panel that listed 280 keys
  in one flat column — names like `navGift` and `dlBtnOfficialPart`, in no
  order anyone could predict — where finding the word you wanted meant
  scrolling past everything and guessing which key produced it.

  No call site was tagged to make this work: the app already routes every
  string through one translator, so the overlay walks the rendered DOM and
  matches each text back to its key using a reverse index of the dictionary.
  Nothing extra ships to players, and the editor exists only in a preview tab.
  Renames are collected by the console when it regains focus, and published
  with Apply like any other change.

- **The live game version in the download tab.** `download.json` says which
  files exist; `info.json` says which release they belong to. A new build
  usually reuses the same file names, so the list alone could never tell a
  player whether they were up to date. Engine versions upstream reports as
  `?.?.?` are hidden rather than printed as-is.

### Fixed
- **A desktop reload came back in the phone layout.** The sizing was read once
  from `innerWidth` at load, and on a desktop browser the window is not always
  sized by the time that runs — so a wide window could report a phone width.
  It now follows a media query, which also makes a genuine resize switch sets
  correctly.
- **The bottom bar ignored the icon setting.** Those six buttons carry an
  explicit `text-[16px]`, and an absolute font size does not inherit, so every
  other icon in the app grew with the scale while the most-used ones did not
  move at all. They are sized in `rem` against the same knobs now.

### Notes
- 947 tests across 18 suites, all passing.
- Edit-in-place covers every string the app renders. Numbers, links and icons
  that come from the command schema are edited in **Commands**, where each one
  already has a pencil.

---

## 1.0.9 — the preview stops leaking, desktop tightened, feed translated

### Fixed
- **The preview leaked onto the public app.** The app and the console share one
  origin and therefore one `localStorage`, and the draft key was read
  unconditionally — so *every* open copy of the player-facing app picked it up,
  a player's included, and showed a warning strip about someone else's
  unpublished changes. The preview is now gated on an explicit
  `GenshinConsole.html#preview`, which only the tab the eye button opens
  carries. A normal visit cannot see a draft however recently one was written.
- **The preview was consumed on first read**, so reloading it threw the draft
  away — useless for the one task it exists for, which is iterating on a
  change. The draft now survives reloads; closing the tab leaves it.
- **Download descriptions stayed English** while the button and title beside
  them translated, which is the worst of both: a translated interface with one
  untranslated paragraph reads as a bug. All three descriptions the feed ships
  are now translated in five languages.
- **Desktop looked sparse.** The interface is drawn for a phone, and simply
  letting it grow to 48rem on a monitor spread every row across a column far
  wider than its content. The column is capped at 42rem and panels are denser.
- **A whole class of CSS rules was silently doing nothing.** `.card` is a
  UnoCSS shortcut that expands into utility classes, so any hand-written
  `.card { … }` had identical specificity and lost purely on source order — it
  parsed, it matched, and it had no effect. The build now emits the authored
  stylesheet *after* the generated utilities, split at a marker so the `:root`
  variables still come first.

### Notes
- 919 tests across 17 suites, all passing.
- The size controls asked about are in **Appearance**: overall scale, button
  height, icon size, corner rounding, spacing, border strength and panel
  opacity — each with independent phone and desktop values, added in 1.0.8 and
  now reachable from the section bar at the bottom.

---

## 1.0.8 — built-in commands are editable, with step and icon controls

### Added
- **Every built-in command can now be edited in place.** Previously the only
  options were to hide one or copy it, and a copy left two commands with the
  same name and no indication which the app would use — so the catalogue could
  not really be corrected at all. A pencil opens the full editor under the row;
  an edited command is marked, and one tap restores the original.
- **Per-field step.** A slider always moved by one, which is right for a level
  and useless for Mora: at a million, one step is a fraction of a pixel and no
  round number can be landed on. The operator sets the grain per field.
- **Choices can be buttons or icons, not only a dropdown.** A dropdown hides
  three options behind a tap and shows a word where a symbol reads instantly.
  Each option takes its own icon name, and a choice with no icon set simply
  renders without one rather than leaving an empty square.

### How edits are stored
- As a **diff against the catalogue**, not a copy. The bundled command set is
  replaced wholesale on every live schema refresh, so a stored copy would pin
  a renamed command to the version it was edited on and it would never receive
  corrected ranges or new parameters. Only the changed fields are kept, and
  they are re-applied over whatever upstream now says. There is a test for
  exactly this: a renamed command still picks up the catalogue's own range.
- Icons live beside `data` rather than inside it, for the same reason — `data`
  mirrors upstream and is overwritten; the icons are the operator's own.

### Fixed
- **Reset did nothing.** Solid's store setter *merges* a plain object rather
  than replacing it, so handing it a copy with the key deleted left the key
  exactly where it was: the command stayed marked as edited forever. Both
  writers now use `produce`, which performs a real delete. Caught by the new
  suite, not by reading.
- A JSX fragment was missing around the row and its editor, which broke the
  build outright.

### Notes
- 867 tests across 16 suites, all passing.
- Still to come: the console rebuilt to mirror the app, size controls, and
  separate phone and desktop settings.

---

## 1.0.7 — batch picking, preview before publishing, feature files

### Added
- **Select all / Clear in the icon picker.** The bulk bar is now present as
  soon as a batch is possible, rather than appearing only after something was
  ticked — which left "Select all" with nowhere to live and no way to reach it
  without first tapping an entry by hand. "All" takes everything the current
  filter shows, not the whole catalogue: selecting seven hundred hidden items
  from a search for one word would be a trap.
- **A picked batch now sends itself.** Choosing twenty avatars used to fill the
  queue and stop there until the operator found the Run button in the console
  dock, which reads as the picker having done nothing. It runs immediately,
  one command at a time at the configured interval. Sending a single command
  during a batch still interrupts it, delivers, and resumes — that was already
  the behaviour and is unchanged.
- **A preview button beside Apply.** The eye opens the app with the current
  draft applied but *not* published, so a change can be looked at before it
  goes live. The preview is read once and discarded, so reloading returns to
  the published patch, and the app shows a warning strip while one is active —
  a preview is pixel-identical to the real thing and must say so.

### Changed
- **"Save" is now "Apply"** in all five languages. The button publishes
  straight to the app; "Save" suggested a local draft needing a second step.
- **The Text section is gone.** Editing 280 keys in one flat list was never how
  anyone wanted to change a label.
- **Features are moving into their own files.** `features/gift.ts` and
  `features/rating.ts` are the first two: each owns its signals and receives
  what it cannot own, so changing one no longer means reading past four
  others. The store is 1234 → ~1050 lines and shrinking.

### Fixed
- **A crash on boot, caught by the new tests.** Extracting the rating gate made
  it construct before `patch` existed, so every launch threw "Cannot access
  before initialization" and the gate silently never appeared. The dependency
  is now resolved lazily, which removes the ordering constraint entirely.

### Notes
- 840 tests across 14 suites, all passing.
- Still to come: the console rebuilt to mirror the app, per-element editing of
  every name and icon, size controls, separate phone and desktop settings.

---

## 1.0.6 — the notice finally crosses, cards expand in place, real ranges

### Fixed
- **Every numeric field claimed "1 to 90".** The hint was keyed only by the
  label text, so every parameter named "Level" printed *character level, 1 to
  90* — wrong for an artifact (max 20), a Grasscutter item (200), a battle
  pass (50), an Abyss floor (12) and adventure rank (60). The baked-in numbers
  are gone from all five translations and the range is now taken from each
  command's own bounds, so the hint and the slider can no longer disagree.
  Digits are localised, so Arabic shows Arabic-Indic numerals throughout.
- **The notice bar still did not travel edge to edge.** Two earlier fixes had
  each solved a different half of it. This one changes the geometry: a single
  copy of the text, starting at `100vw` — fully off one edge — and ending at
  `-100%` of its own width, fully off the other.
- **The same notice started *inside* the bar in Arabic.** An element wider
  than its container is anchored to the end of the line, so under `dir="rtl"`
  every offset measured from a different origin. The bar is now pinned to one
  layout direction and the text alone is flipped back.

### Changed
- **A command expands inside its own card again, not over the whole screen.**
  Making it a full page fixed the cramped form and broke something worse: with
  the list gone, the command *next to* the one being filled in could not be
  opened at all. Cards now grow within their grid column, two can be open side
  by side, and a closed neighbour keeps its own height.

### Added
- **Notice speed and direction, in the admin console.** Seconds per pass —
  with zero meaning "derive it from the length", so short and long notices
  read at the same speed — plus which edge the text enters from (automatic,
  right, or left), and a switch to stop the motion entirely, in which case the
  message wraps and stays fully readable.

### Verified against the live schema
- All 65 non-staff commands still match upstream exactly: names, parameter
  counts, types, formats, labels and ranges.

### Notes
- 820 tests across 13 suites, all passing.
- Nine stale tests were corrected. Two caught real defects rather than needing
  adjustment: the Russian and Chinese range strings were byte-identical to
  English, which the suite rightly refuses to call a translation.

---

## 1.0.5 — the notice actually scrolls, commands open full-screen

### Fixed
- **The scrolling notice never appeared to move.** `translateX(-100%)` is a
  percentage of the element being animated, and the track holds *two* copies of
  the message — so it travelled twice the distance it should and the bar sat
  completely empty for the whole second half of every lap. Measured: 498px of
  travel where one copy is 249px. It now moves `-50%`, which is exactly one
  copy, so the second lands where the first began and the bar is never blank.
  The pace constant was halved to match, or correcting the distance would have
  doubled the apparent speed.

### Changed
- **A command now opens as its own screen**, the way the official site does it.
  Expanding inline put a long form between two list rows: on a phone the fields
  were half off-screen, the Run button was below the fold, and the command being
  configured had scrolled out of sight. Only one is open at a time, the list is
  replaced rather than pushed apart, and there is a full-width Back control at
  the top — the easiest place to reach one-handed.
- Values typed into a form survive leaving and returning to it.
- The screen shows the **untranslated command name** under the translated
  title. The translation says what the command does; the server only accepts
  the original, and showing one without the other leaves the user unable to do
  one of those two things.

### Verified against the live schema
- All **65 non-staff commands** match upstream exactly: same names, same
  parameter counts, same types, formats, labels and ranges — no differences.
- Every command name and every field label has an Arabic translation; none
  falls back to English.

### Notes
- 802 tests across 13 suites, all passing.
- Six stale tests were corrected rather than deleted — several asserted the old
  inline behaviour, one matched `:has-text("Run")` against a description
  containing the word "run", and one looked for a text input on a command that
  has no parameters.

---

## 1.0.4 — audio removed, one theme, a far deeper ad panel

### Removed
- **All sound and music.** The click sounds were clips of the game's own
  interface audio, embedded in the file; the music system was built to carry
  whatever the operator uploaded. Both are gone entirely rather than switched
  off, because a switch would have left that material shipping to every user
  regardless of its position. The app is silent and 235 KB smaller.
- **Light mode.** The whole app is dark. Every surface, scrim and overlay
  needed a second set of numbers that had to be kept in step with the first,
  and the two drifted apart more than once. An old patch asking for light is
  ignored rather than obeyed — honouring it now would leave the page with no
  matching variables at all, which is light text on a light background.
- The colour editor is one palette instead of two. A patch written by an
  earlier build keeps its dark colours; the discarded light half is dropped.

### Added
- **A much deeper advertising panel.** Fifteen networks recognised instead of
  eight, and the report now shows every third-party host the slot will
  contact, the publisher and zone identifiers it found, the markup size, and
  whether the slot adapts to the screen.
- **New checks**, each for a real failure: calls that can open a window or
  navigate on their own, inline event handlers, fixed sizes that cannot shrink
  on a phone, tall slots that push the interface down, a dependency on
  `DOMContentLoaded` in a page that never reloads, an unusual number of
  domains, and a plain warning on networks that serve pop-unders by default.
- **A sandboxed live preview.** The analyser reads the markup; this runs it, in
  an iframe with `allow-scripts` and nothing else — no access to the console,
  no storage, no navigation. An empty frame is itself informative: it usually
  means the network refused the origin, exactly as it would in the app.
- **A summary across every slot** — how many are live, how many are broken, how
  many domains in total, where each one lands, and a warning past two.
- **Duplicate a slot**, so the same creative in two positions does not mean
  retyping a publisher id by hand.

### Notes
- The scrolling notice bar from the previous build is unchanged and still
  covered by its own suite.
- 745 tests across 12 suites, all passing.

---

## 1.0.3 — real game sounds, operator music, a rating gate, live data

### Added
- **The game's own interface sounds, replacing the synthesised bells.** The
  previous engine built struck-bell tones from oscillators. The recipe was
  right in principle and still sounded like a synthesiser, because the game's
  UI audio is recorded material with a texture no oscillator stack
  reproduces. Ten clips now cover every gesture — tap, tab, choose, switch,
  open, close, send, accepted, error, not-found. Each is trimmed of silence,
  loudness-normalised so one gesture is not twice as loud as the next,
  downmixed to mono and re-encoded at 48 kbps. All are under three seconds;
  most are near one, and the whole set is about 110 KB.
- **A Music section in the admin console.** The operator adds their own audio
  files and controls everything: order, per-track level, shuffle, repeat,
  volume, fade length, whether the player is visible at all, whether it keeps
  playing in the background, and whether the music ducks under interface
  clicks and by how much. Music plays **only in the player-facing app**, never
  in the console. A build with no tracks ships no audio and costs nothing.
- **Players-online counts.** A live total sits beside the connection dot in
  the header, and the account tab lists every server with its own count,
  busiest first. Both refresh once a minute, matching how often the source is
  sampled upstream.
- **A live quest library.** The bundled snapshot is now merged with the
  upstream handbook at run time, so a quest added in a game update appears
  without a rebuild.

### Changed
- **Ratings are asked for twice, and they block sending.** At ten commands and
  again at fifty. A prompt that can be dismissed forever is dismissed forever,
  so this one has no close button and cannot be tapped away — but it explains
  why it appeared and takes one tap to satisfy. After the second, it never
  returns.
- **The background switch moved out of the app.** Choosing the backdrop is an
  operator decision; a per-user toggle could turn off a background the
  operator had just published. Two controls over one layer will eventually
  disagree.
- **The sound-kit picker is gone.** It offered four synthesised palettes
  because oscillators were the only source of variety. With the game's real
  audio there is exactly one correct set, so the console now offers
  auditioning instead of choosing.
- The bundled `README.md` was removed from the release archive.

### Fixed
- **Reloading escaped the rating gate.** The prompt lived in a signal that
  starts false, so refreshing the page cleared it while the counters said
  otherwise. Found by the new suite, not by reading.
- **A merged quest ran backwards.** Steps reconstructed from the handbook were
  built by unshifting inside a descending loop, which reversed them.
- **The placeholder filter only ran on one of three entry points.** Upstream
  prints `Quest 348-34817` where a title should be; that was rejected on fetch
  but not when the same rows arrived from the cache.
- **A failed server poll blanked the count.** One dropped request — a phone
  changing networks — replaced a working list with the built-in fallback and
  flashed the population to zero.

### Notes
- Autoplay is *armed*, not forced. No browser starts audio before the user has
  touched the page, and there is no setting, permission or trick that changes
  this from a `file://` document. The music begins on the first tap, and the
  console states this plainly next to the switch rather than offering a option
  that silently does nothing.
- 733 tests across 12 suites, all passing.

---

## 1.0.2 — bell-synth sounds, ad analyser, operator-owned theme

### Fixed
- **The click sounds were nothing like the game.** They were bare sine and
  square oscillators, which is a beep, not a UI tick. Genshin's clicks are
  struck-bell sounds, and a bell is not one frequency: it is a short noise
  transient followed by several *inharmonic* partials ringing at once, each
  decaying at its own rate. The engine now models all three properties —
  overtones at roughly 1 : 2.0 : 2.4 : 3.0 : 4.5 rather than whole multiples,
  faster decay on the high partials, and 12 ms of bandpassed noise for the
  strike. A shared compressor keeps the summed partials from clipping on a
  phone speaker.
- **Untranslated strings in the Download tab.** The feed ships English only —
  "Download Official", "PC", "Game Data (Global) (One Click)". The app now
  translates the phrases it recognises in all five languages and falls back to
  the original for anything new.

### Changed — the app
- **The theme toggle is gone.** The colour scheme is set by the operator, so a
  per-user switch could contradict the palette they authored.
- **The notice banner animates**: a short slide on arrival, then a slow pulse
  that takes its colour from the tone. A notice that never moves stops being
  seen after the first day.
- The privacy shield's description now states plainly what it does when on and
  when off, and why it is off by default.

### Changed — the admin console
- **Four sound kits**, auditioned in place: Crystal (closest to the game), Soft,
  Wood and Plain, plus per-gesture preview buttons.
- **The ad FAQ became an analyser.** Pasted markup is parsed with `DOMParser` —
  never inserted into the page, so nothing can execute — and reported on:
  which network it belongs to, what will render, its declared size, and the
  specific faults. It detects an AdSense snippet missing its loader, its
  `<ins>` element, its `push()` call or its `data-ad-client`, an empty
  `<script>`, `document.write`, mixed content, and protocol-relative sources.
- **Appearance** chooses the shipped scheme and edits dark and light as
  separate palettes, previewing whichever is selected.
- **Layout** reorders tabs, nominates which opens first, and gives links icons.
- **"Reset everything" removed** — one mis-tap from discarding an afternoon's
  work, and every section already reverts individually.

### Verified
540 checks across ten suites.

---

## 1.0.1 — light-theme fix, admin console rework

### Fixed
- **Light mode hid every label once colours had been customised.** The admin
  console wrote its palette inline on `:root`, which outranks the
  `[data-theme='light']` block in the cascade — so a dark palette followed the
  user into light mode and the text disappeared against its own background.
  Colours are now emitted as a stylesheet scoped per theme, so they obey the
  switch instead of overriding it. Dark and light are edited as separate sets,
  because a value that reads well on `#0b0d12` is invisible on `#f5f7fb`.
- **A shadowed variable broke the banner tone labels.** The loop variable was
  named `t`, which shadowed the translator, so each button rendered its raw id.

### Changed — the app
- **Sound and the privacy shield moved to the admin console.** They are
  operator decisions, not per-user preferences, and two copies could disagree.
- **Download titles carry no site branding.** The feed labels its files
  "YuukiPS Launcher (NEW)" and "YuukiGI for GIO"; only the meaningful tag is
  kept — "Launcher (NEW)", "GIO". The brand is removed together with whatever
  letters are glued to it, since it prefixes several different words.

### Changed — the admin console
- **The Styles section is gone.** Raw CSS next to a live app was a footgun with
  no upside now that colours, images and layout are all editable properly.
- **Appearance takes two uploads, not four.** One for the app mark, one for the
  background; each accepts a photo, an animated GIF or a video. The separate
  "still frame" fields were maintenance for no gain.
- **Layout does more than hide tabs**: reorder them, choose which opens first,
  and give footer links an icon from a fixed set with a warning when a URL is
  not a URL.
- **The banner is a real editor** — a live preview rendered exactly as the app
  will show it, three named importance levels, and a character count.
- **Ads gained a troubleshooting guide** covering the four reasons pasted ad
  code usually shows nothing, a per-position explanation, and a live status
  telling an enabled-but-empty slot apart from a working one.
- Every new string is translated into all five languages.

### Verified
532 checks across ten suites. The light-theme case applies a dark override,
switches themes and measures the rendered heading colour rather than trusting
a class name.

---

## 1.0.0 — first public release

Version numbering restarts here at the owner's request. Everything below is the
state of the app as shipped, not a history of how it got here.

### The app

- **Quest library.** 2,076 quests and 15,500 steps, searched by a Rust/WASM
  fuzzy engine in a Web Worker — `wtp` finds *Winds of the Past*. Roughly 6,000
  sub-steps have no name in the game data and none in the upstream handbook
  either, so those are numbered by position rather than labelled "untitled".

- **Live command bridge.** Signs in with the account you use for the game,
  opens a realtime socket, and sends commands straight to your character.

- **Automatic version detection.** The app finds which server your game is
  actually open on and unlocks only the commands that build accepts, locking
  the other. There is no API for this — the gateway is probed with a silent,
  read-only command, because it is the only component that knows. Sign-in never
  guesses: the badge turns green on evidence, not on a stored preference.

- **Command library.** Two catalogues, GC and GIO, mirrored from the upstream
  schema and rendered as forms — no syntax to memorise. Destructive commands
  are red and carry an explicit warning.

- **Gift tab.** Locate a friend by UID, then send characters, weapons, items or
  artifacts, paced by a delay you control because the gateway refuses bursts.

- **Download tab.** Pulled live from the official download feed, so a new build
  or launcher appears without this app being rebuilt.

- **Reviews.** Ratings with author and stars; one or two stars, or either
  negative choice, require a written reason — a bare low score cannot be acted
  on.

- **Five languages**, complete: English, Arabic, Russian, Japanese, Chinese.
  Command names, field labels, dropdown options and every explanation are
  translated, not just the shell.

- **Interface sounds**, synthesised with the Web Audio API rather than shipped
  as files: a distinct tone per surface and a chime when the game accepts a
  command. Adds no bytes to the bundle.

- **Copy protection.** Selection, the long-press callout, the context menu,
  clipboard events and image drag-out are blocked; the app's own Copy buttons
  still work. This stops casual copying and cannot stop someone reading the
  page source — no client-side measure can.

- **Optional privacy shield** that blanks the app when it is not in front. A web
  page cannot block a screenshot: Android's capture reads the compositor
  output, far below anything a browser tab may touch. This defeats casual
  capture and shoulder-surfing, nothing more.

### The admin console

A separate document, so its editor never ships inside the app players open.

- **The bundle is encrypted at rest** with AES-256-GCM. A username *and*
  password derive the key through PBKDF2-SHA512 at 600,000 iterations; neither
  is stored or compared, so a wrong credential yields a key that fails the
  authentication tag rather than a check that could be patched out. Verified by
  measuring the payload's entropy, not by assertion.

- **Ten sections**: overview with live counts and feature switches, text
  editing grouped by area, a full command editor, appearance with theme
  presets, layout, review moderation, advertising slots, a stylesheet box, a
  security summary and sealed backups.

- **Translate once, apply everywhere.** Editing a string in any language fills
  the other four automatically, with placeholders masked so `{server}` survives
  the round trip. Results are drafts, shown before they are saved.

- **Advertising slots.** Paste provider markup and choose its position; scripts
  are re-created so they actually execute, which pasted ad code otherwise
  does not.

### Verified

502 automated checks across ten suites, covering the protocol, detection,
localisation, the admin encryption and the user interface.
