#!/usr/bin/env python3
# ============================================================================
# PadLink 1.1.12 - Android mirror + universal gamepad + SMART AI COLOR LAYER.
# Pure ASCII source; all Arabic text in ui_ar.json.
#
# Pages:
#   1) Devices   : phone (USB/WiFi) + any gamepad status, doctor, tips
#   2) Screen    : standalone mirror window (never disappears) + controls
#                  + the SMART AI COLOR LAYER: smart auto colors, advanced
#                  clarity, exposure - ultra-fast (240fps presets)
#   3) Controller: PRO VECTOR 3D gamepad model (every button with its
#                  real letter in its real place) + live glow/stick/
#                  trigger effects, vibration tuning, deadzone, auto-fix
#
# Stack: PyGObject(GTK3) + evdev + adb (bundled) + scrcpy (bundled)
#        + cairo overlays. Controller forwarding via UHID/AOAv2.
# ============================================================================
import glob, json, math, os, shutil, subprocess, sys, threading, time
import traceback
from datetime import datetime

APP_VERSION = "1.1.12"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
BIN_DIR = os.path.join(APP_DIR, "bin")
CONFIG_DIR = os.path.expanduser("~/.config/padlink")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
SCREENSHOT_DIR = os.path.expanduser("~/Pictures")
VIDEO_DIR = os.path.expanduser("~/Videos")
LOCALE_CANDIDATES = [
    os.environ.get("PADLINK_LOCALE", ""),
    "/usr/share/padlink/ui_ar.json",
    os.path.join(APP_DIR, "ui_ar.json"),
    os.path.normpath(os.path.join(APP_DIR, "..", "..", "share", "padlink", "ui_ar.json")),
]
EMBED_TITLE = "padlink_window"
K_HOME, K_BACK, K_APP, K_VOLUP, K_VOLDOWN, K_POWER = 3, 4, 187, 24, 25, 26

# ---------- UPDATE SERVER (the GitHub repo itself) ----------
# update.json at the repo root always points at the newest build.
UPDATE_API = ("https://api.github.com/repos/Pr00k/genshin-mod/"
              "contents/update.json?ref=arena/01a05e92-genshin-mod")
UPDATE_BASE = ("https://api.github.com/repos/Pr00k/genshin-mod/"
               "contents/")
UPDATE_REF = "ref=arena/01a05e92-genshin-mod"
UPDATE_HEADERS = {"User-Agent": "padlink",
                  "Accept": "application/vnd.github.raw"}


def _ver_gt(a, b):
    """True if version string a is strictly newer than b (1.2 > 1.10)."""
    def t(v):
        out = []
        for x in str(v).split("."):
            n = ""
            for ch in x:
                if ch.isdigit():
                    n += ch
                else:
                    break
            out.append(int(n) if n else 0)
        while len(out) < 3:
            out.append(0)
        return tuple(out[:3])
    try:
        return t(a) > t(b)
    except Exception:
        return False

# Vector controller model (same directory): a parametric Xbox-360-style
# 3D gamepad drawn entirely with cairo + live effects. No photos.
try:
    if APP_DIR not in sys.path:
        sys.path.insert(0, APP_DIR)
    import padlink_controller as _pc
except Exception:
    _pc = None

# Smart AI color/clarity layer over the standalone mirror window.
try:
    if APP_DIR not in sys.path:
        sys.path.insert(0, APP_DIR)
    import smart_overlay as _so
except Exception:
    _so = None


def log(msg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(os.path.join(CONFIG_DIR, "app.log"), "a", encoding="utf-8") as fh:
            fh.write("[%s] %s\n" % (datetime.now().isoformat(timespec="seconds"), msg))
    except Exception:
        pass


def load_locale():
    for p in LOCALE_CANDIDATES:
        if p and os.path.isfile(p):
            try:
                return json.load(open(p, encoding="utf-8"))
            except Exception:
                continue
    return {}

T = load_locale()


def tr(k, fb=""):
    v = T.get(k)
    return v if v is not None else (fb if fb else k)


def run_cmd(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception as e:
        return -1, "", str(e)


def _ensure_exec(p):
    try:
        if os.path.isfile(p) and not os.access(p, os.X_OK):
            os.chmod(p, 0o755)
        return os.path.isfile(p) and os.access(p, os.X_OK)
    except Exception:
        return False


def find_adb():
    for c in (os.path.join(BIN_DIR, "adb"), "/usr/lib/padlink/bin/adb"):
        if _ensure_exec(c):
            return c
    return shutil.which("adb")


def adb_cmd(args):
    return [find_adb() or "adb"] + args


def find_scrcpy():
    for c in (os.path.join(BIN_DIR, "scrcpy"), "/usr/lib/padlink/bin/scrcpy"):
        if _ensure_exec(c):
            return c
    return shutil.which("scrcpy")


def is_wayland():
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def detect_phones():
    """Detect connected Android phones via USB. Restarts adb server once
    if the first query finds nothing (common USB enumeration glitch)."""
    if find_adb() is None:
        return "adb_missing", []
    rc, out, _ = run_cmd(adb_cmd(["devices"]), 8)
    if rc != 0:
        return "none", []
    devs, unauth = [], False
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 2:
            if p[1] == "device":
                devs.append(p[0])
            elif p[1] == "unauthorized":
                unauth = True
            elif p[1] == "offline":
                # device present but stuck offline: try restarting adb
                run_cmd(adb_cmd(["kill-server"]), 8)
                run_cmd(adb_cmd(["start-server"]), 8)
                time.sleep(0.5)
    if devs:
        return "ok", devs
    if unauth:
        return "unauthorized", []
    # one retry with a fresh server
    run_cmd(adb_cmd(["kill-server"]), 8)
    run_cmd(adb_cmd(["start-server"]), 8)
    rc, out, _ = run_cmd(adb_cmd(["devices"]), 8)
    devs, unauth = [], False
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 2:
            if p[1] == "device":
                devs.append(p[0])
            elif p[1] == "unauthorized":
                unauth = True
    if devs:
        return "ok", devs
    if unauth:
        return "unauthorized", []
    return "none", []



def get_phone_size(serial):
    rc, out, _ = run_cmd(adb_cmd(["-s", serial, "shell", "wm", "size"]), 6)
    for line in out.splitlines():
        if "size" in line.lower() and "x" in line:
            part = line.split(":", 1)[-1].strip().lower()
            try:
                w, h = part.split("x")
                return int(w), int(h)
            except Exception:
                continue
    return 1080, 2400


def detect_controllers():
    """Detect ANY gamepad the kernel exposes (wired or Bluetooth).
    Uses a broad heuristic: an input device with analog axes and at least
    one of the common gamepad buttons, or a joystick js* node."""
    ctrls = []
    try:
        import evdev
    except Exception:
        return ctrls
    _NON_PAD = ("keyboard", "kbd", "mouse", "touchpad", "trackpoint",
                "thinkpad", "power button", "video bus", "lid switch",
                "rfkill", "dvd", "wmi", "hotkey", "sleep button")
    for path in evdev.list_devices():
        if "event" not in os.path.basename(path):
            continue
        try:
            dev = evdev.InputDevice(path)
            name = (dev.name or "").lower()
            if any(n in name for n in _NON_PAD):
                dev.close()
                continue
            caps = dev.capabilities(verbose=False)
            raw_abs = caps.get(evdev.ecodes.EV_ABS, [])
            abs_keys = [i[0] if isinstance(i, tuple) else i for i in raw_abs]
            key_keys = caps.get(evdev.ecodes.EV_KEY, [])
            # axes: sticks/triggers OR a d-pad hat (some pads report only hat)
            has_axis = any(k in (evdev.ecodes.ABS_X, evdev.ecodes.ABS_Y,
                                 evdev.ecodes.ABS_RX, evdev.ecodes.ABS_RZ,
                                 evdev.ecodes.ABS_Z, evdev.ecodes.ABS_HAT0X,
                                 evdev.ecodes.ABS_HAT0Y, evdev.ecodes.ABS_BRAKE,
                                 evdev.ecodes.ABS_GAS) for k in abs_keys)
            has_btn = any(k in (evdev.ecodes.BTN_A, evdev.ecodes.BTN_SOUTH,
                                evdev.ecodes.BTN_JOYSTICK, evdev.ecodes.BTN_GAMEPAD,
                                evdev.ecodes.BTN_TL, evdev.ecodes.BTN_TR,
                                evdev.ecodes.BTN_START, evdev.ecodes.BTN_SELECT,
                                evdev.ecodes.BTN_DPAD_UP, evdev.ecodes.BTN_DPAD_DOWN,
                                evdev.ecodes.BTN_DPAD_LEFT, evdev.ecodes.BTN_DPAD_RIGHT)
                          for k in key_keys)
            if has_axis and has_btn:
                info = (0, 0, 0, 0)
                phys = ""
                try:
                    info, phys = dev.info, dev.phys or ""
                except Exception:
                    pass
                ctrls.append({"name": dev.name or "Gamepad", "path": path,
                              "readable": True, "vendor": info[1],
                              "product": info[2], "phys": phys,
                              "buttons": len(key_keys), "axes": len(abs_keys)})
            dev.close()
        except PermissionError:
            ctrls.append({"name": os.path.basename(path), "path": path,
                          "readable": False, "vendor": 0, "product": 0,
                          "phys": "", "buttons": 0, "axes": 0})
        except Exception:
            continue
    # Fallback: classic joystick nodes
    if not ctrls:
        for js in sorted(glob.glob("/dev/input/js*")):
            ctrls.append({"name": js, "path": js, "readable": False,
                          "vendor": 0, "product": 0, "phys": "",
                          "buttons": 0, "axes": 0})
    return ctrls



def controller_type(name):
    """PadLink targets the Xbox 360 controller. Return its label."""
    return "\u0625\u0643\u0633 \u0628\u0648\u0643\u0633 360"

def test_rumble(path, intensity=100, duration=400):
    if intensity <= 0:
        return False
    try:
        import evdev
        from evdev import ff
        dev = evdev.InputDevice(path)
        try:
            caps = dev.capabilities()
            if evdev.ecodes.FF_RUMBLE not in caps.get(evdev.ecodes.EV_FF, []):
                return False
            s = max(0, min(0xFFFF, int(intensity * 0xFFFF / 100)))
            fx = ff.FF_RUMBLE(s, s, int(duration), 0)
            dev.upload(fx)
            dev.write(evdev.ecodes.EV_FF, fx.id, 1)
            return True
        finally:
            dev.close()
    except Exception:
        return False


def default_config():
    return {"max_size": "1024", "fps": "60", "bitrate": "16M", "audio": True,
            "gamepad": "uhid", "mode": "standalone", "preset": "balanced",
            "record": False, "stay_awake": False, "turn_screen_off": False,
            "mouse_mode": "sdk", "forward_enabled": True, "vibration_enabled": True,
            "vibration": 100, "vibration_ms": 400, "deadzone": 8,
            "auto_mirror": True,
            "overlay_enabled": False, "overlay_color": [77, 124, 255],
            "overlay_opacity": 0.25, "overlay_auto": True,
            "overlay_clarity": 0.0, "overlay_exposure": 0.0,
            "overlay_saturation": 0.0, "overlay_contrast": 0.0,
            "overlay_temperature": 0.0}


def load_config():
    try:
        d = json.load(open(CONFIG_FILE, encoding="utf-8"))
        m = default_config()
        m.update(d)
        m["mode"] = "standalone"  # forced: never disappears
        return m
    except Exception:
        return default_config()


def save_config(c):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        json.dump(c, open(CONFIG_FILE, "w", encoding="utf-8"), indent=2)
    except Exception:
        pass


GTK_OK, _ERR, cairo = False, "", None
try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib, Gdk, GdkPixbuf
    GTK_OK = True
    try:
        import cairo
        gi.require_foreign("cairo")
    except Exception:
        cairo = None
except Exception as e:
    _ERR = str(e)


def clamp(v, lo=-1.0, hi=1.0):
    return max(lo, min(hi, v))


if GTK_OK:

    class GamepadReader(threading.Thread):
        def __init__(self, path, on_update):
            super().__init__(daemon=True)
            self.path, self.on_update = path, on_update
            self.buttons, self.axes, self.ranges = {}, {}, {}
            self.offsets, self.running = {}, True
            self.lock = threading.Lock()

        def run(self):
            try:
                import evdev
            except Exception:
                return
            try:
                dev = evdev.InputDevice(self.path)
            except Exception:
                return
            try:
                try:
                    for item in dev.capabilities(verbose=False).get(evdev.ecodes.EV_ABS, []):
                        code = item[0] if isinstance(item, tuple) else item
                        try:
                            ai = dev.absinfo(code)
                            self.ranges[code] = (ai.min, ai.max)
                        except Exception:
                            pass
                except Exception:
                    pass
                for ev in dev.read_loop():
                    if not self.running:
                        break
                    if ev.type == evdev.ecodes.EV_KEY:
                        with self.lock:
                            self.buttons[ev.code] = ev.value
                        GLib.idle_add(self.on_update)
                    elif ev.type == evdev.ecodes.EV_ABS:
                        with self.lock:
                            self.axes[ev.code] = ev.value
                        GLib.idle_add(self.on_update)
            except Exception:
                pass
            finally:
                try:
                    dev.close()
                except Exception:
                    pass

        def stop(self):
            self.running = False

        def state(self):
            with self.lock:
                return dict(self.buttons), dict(self.axes), dict(self.ranges)

    class PadLinkWindow(Gtk.Window):
        def __init__(self):
            super().__init__(title=tr("app_title"))
            self.set_default_size(1000, 660)
            self.config = load_config()
            self.phone_state, self.phones = "none", []
            self.ctrls, self.reader = [], None
            self.proc, self.proc_tail, self.first_error = None, [], None
            self.mirror_running = False
            self.mirror_start_ts = 0.0
            self.timers, self._alive = [], True
            self._auto_started = ""
            self._auto_blocked = False
            self._auto_mirror_run = False
            # full-control bridge state (gamepad -> system key events)
            self.fc_shell, self.fc_state = None, "off"
            self.fc_sent, self.fc_held, self.fc_last = 0, None, 0.0
            self.fc_prev_btns, self._fc_toggling = {}, False

            self.overlay = {"enabled": bool(self.config.get("overlay_enabled", False)),
                            "color": list(self.config.get("overlay_color", [77, 124, 255])),
                            "opacity": float(self.config.get("overlay_opacity", 0.12)),
                            "auto": bool(self.config.get("overlay_auto", True)),
                            "clarity": float(self.config.get("overlay_clarity", 0.0)),
                            "exposure": float(self.config.get("overlay_exposure", 0.0)),
                            "saturation": float(self.config.get("overlay_saturation", 0.0)),
                            "contrast": float(self.config.get("overlay_contrast", 0.0)),
                            "temperature": float(self.config.get("overlay_temperature", 0.0))}
            for k in ("overlay_enabled", "overlay_color", "overlay_opacity",
                      "overlay_auto", "overlay_clarity", "overlay_exposure",
                      "overlay_saturation", "overlay_contrast", "overlay_temperature"):
                self.config.setdefault(k, default_config().get(k, self.overlay.get(
                    k.replace("overlay_", ""), None)))
                if k == "overlay_color" and not isinstance(self.config[k], list):
                    self.config[k] = [77, 124, 255]
            self.smart_ov = None

            if os.path.isfile("/usr/share/padlink/padlink.svg"):
                try:
                    self.set_icon_from_file("/usr/share/padlink/padlink.svg")
                except Exception:
                    pass

            hdr = Gtk.HeaderBar()
            hdr.set_show_close_button(True)
            hdr.props.title = tr("app_title")
            hdr.props.subtitle = tr("app_subtitle") + "  v" + APP_VERSION
            self.set_titlebar(hdr)
            helpb = Gtk.Button.new_from_icon_name("help-about", Gtk.IconSize.BUTTON)
            helpb.set_tooltip_text(tr("btn_help"))
            helpb.connect("clicked", lambda _b: self.show_help())
            hdr.pack_end(helpb)

            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            self.add(vbox)
            body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            sidebar = Gtk.StackSidebar()
            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
            sidebar.set_stack(self.stack)
            body.pack_start(sidebar, False, False, 0)
            sc = Gtk.ScrolledWindow()
            sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sc.add(self.stack)
            body.pack_start(sc, True, True, 0)
            vbox.pack_start(body, True, True, 0)
            self.statusbar = Gtk.Label(xalign=0.0)
            self.statusbar.set_margin_start(10)
            self.statusbar.set_margin_end(10)
            self.statusbar.set_margin_top(4)
            self.statusbar.set_margin_bottom(4)
            vbox.pack_end(self.statusbar, False, False, 0)

            self.build_devices_page()
            self.build_screen_page()
            self.build_controller_page()
            self.stack.connect("notify::visible-child", self.on_page_changed)
            self.connect("destroy", self.on_destroy)
            self.connect("key-press-event", self.on_key)
            self.refresh_async()
            self.timers.append(GLib.timeout_add(4000, self.periodic_refresh))
            self.timers.append(GLib.timeout_add(1000, self.watch_mirror))
            # ultra-fast smart layer loop: 15Hz (self-throttles internally)
            self.timers.append(GLib.timeout_add(66, self.overlay_tick))
            # auto-update: ask the update server (GitHub) on startup
            self.timers.append(GLib.timeout_add(8000, self._upd_check_later))

        # ---------- helpers ----------
        def toast(self, m):
            if self._alive:
                self.statusbar.set_text(m)
                GLib.timeout_add(7000, self.clear_toast)

        def clear_toast(self):
            if self._alive:
                self.statusbar.set_text("")
            return False

        def color(self, t, c):
            return '<span color="%s"><b>%s</b></span>' % (c, GLib.markup_escape_text(t))

        def on_page_changed(self, _s, _p):
            if self.stack.get_visible_child_name() == "page_controller":
                self.refresh_ctrls_ui()
                # automatic smart calibration the first time the page opens:
                # re-measures the artwork and corrects every control position
                if not getattr(self, "_calibrated", False) and self.cc is not None:
                    self._calibrated = True
                    try:
                        cal = self.cc.auto_calibrate()
                        if cal:
                            self.cc.set_state(self._ctrl_state())
                            self.drawing.queue_draw()
                            self.toast(tr("autofix_calib_auto"))
                    except Exception:
                        pass

        def on_key(self, _w, ev):
            """Keyboard shortcuts:
            Ctrl+1..3 switch pages, Ctrl+Enter start mirror, F5 refresh."""
            try:
                key = ev.keyval
                ctrl = ev.state & Gdk.ModifierType.CONTROL_MASK
                if ctrl and key == Gdk.KEY_1:
                    self.stack.set_visible_child_name("page_devices"); return True
                if ctrl and key == Gdk.KEY_2:
                    self.stack.set_visible_child_name("page_screen"); return True
                if ctrl and key == Gdk.KEY_3:
                    self.stack.set_visible_child_name("page_controller"); return True
                if ctrl and key == Gdk.KEY_Return:
                    self.start_mirror(); return True
                if key == Gdk.KEY_F5:
                    self.refresh_async(force=True); return True
            except Exception:
                pass
            return False

        def icon_btn(self, icon, sym, handler, tip=None):
            b = Gtk.Button()
            try:
                if icon and Gtk.IconTheme.get_default().has_icon(icon):
                    b.add(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON))
                else:
                    b.set_label(tr(sym, ""))
            except Exception:
                b.set_label(tr(sym, ""))
            b.connect("clicked", handler)
            if tip:
                b.set_tooltip_text(tr(tip))
            return b

        # ---------- Page 1: Devices ----------
        def build_devices_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            page.set_margin_top(12); page.set_margin_bottom(12)
            page.set_margin_start(12); page.set_margin_end(12)
            cols = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

            pf = Gtk.Frame(label=tr("phone_frame"))
            pb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            pb.set_margin_top(8); pb.set_margin_bottom(8); pb.set_margin_start(10); pb.set_margin_end(10)
            self.phone_status = Gtk.Label(xalign=0.0)
            self.phone_list = Gtk.Label(xalign=0.0, selectable=True, wrap=True)
            self.phone_model = Gtk.Label(xalign=0.0, wrap=True, selectable=True)
            self.phone_android = Gtk.Label(xalign=0.0)
            self.phone_batt = Gtk.Label(xalign=0.0)
            hint = Gtk.Label(xalign=0.0, wrap=True)
            hint.set_markup('<span color="#888888" size="small">%s</span>' % tr("phone_hint"))
            rb = Gtk.Button(label=tr("phone_refresh"))
            rb.connect("clicked", lambda _b: self.refresh_async(force=True))
            for w in (self.phone_status, self.phone_list, self.phone_model,
                      self.phone_android, self.phone_batt, hint, rb):
                pb.pack_start(w, False, False, 0)
            pf.add(pb)

            cf = Gtk.Frame(label=tr("ctrl_frame"))
            cb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            cb.set_margin_top(8); cb.set_margin_bottom(8); cb.set_margin_start(10); cb.set_margin_end(10)
            self.ctrl_status = Gtk.Label(xalign=0.0)
            self.ctrl_name = Gtk.Label(xalign=0.0, wrap=True, selectable=True)
            self.ctrl_detail = Gtk.Label(xalign=0.0, wrap=True, selectable=True)
            ch = Gtk.Label(xalign=0.0, wrap=True)
            ch.set_markup('<span color="#888888" size="small">%s</span>' % tr("ctrl_hint"))
            for w in (self.ctrl_status, self.ctrl_name, self.ctrl_detail, ch):
                cb.pack_start(w, False, False, 0)
            cf.add(cb)

            cols.pack_start(pf, True, True, 0)
            cols.pack_start(cf, True, True, 0)
            page.pack_start(cols, True, True, 0)

            act = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            act.set_halign(Gtk.Align.CENTER)
            start = Gtk.Button(label=tr("btn_start"))
            start.get_style_context().add_class("suggested-action")
            start.connect("clicked", lambda _b: self.start_mirror())
            doctor = self.icon_btn("applications-engineering", "sym_doctor",
                                   lambda _b: self.run_doctor(), "btn_doctor")
            diagb = Gtk.Button(label=tr("diag_btn"))
            diagb.set_tooltip_text(tr("diag_help"))
            diagb.connect("clicked", lambda _b: self.run_diag())
            upd = Gtk.Button(label=tr("upd_btn"))
            upd.set_tooltip_text(tr("upd_btn_help"))
            upd.connect("clicked", lambda _b: self._upd_manual())
            about = Gtk.Button(label=tr("btn_about"))
            about.connect("clicked", lambda _b: self.show_about())
            for b in (start, doctor, upd, about):
                act.pack_start(b, False, False, 0)
            page.pack_start(act, False, False, 0)
            self.stack.add_titled(page, "page_devices", tr("tab_devices"))

        # ---------- Page 2: Screen ----------
        def build_screen_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            r1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
            r1.set_margin_top(4); r1.set_margin_start(4); r1.set_margin_end(4)
            self.btn_start2 = self.icon_btn("media-playback-start", "sym_start",
                                            lambda _b: self.start_mirror(), "btn_start2")
            self.btn_stop = self.icon_btn("media-playback-stop", "sym_stop",
                                          lambda _b: self.stop_mirror(manual=True), "btn_stop")
            self.btn_stop.set_sensitive(False)
            fs = self.icon_btn("view-fullscreen", "sym_fullscreen",
                               lambda _b: self.toggle_fullscreen(), "btn_fullscreen")
            zi = self.icon_btn("zoom-in", "sym_zoom_in", lambda _b: self.zoom(1), "btn_zoom_in")
            zo = self.icon_btn("zoom-out", "sym_zoom_out", lambda _b: self.zoom(-1), "btn_zoom_out")
            fit = self.icon_btn("zoom-fit-best", "sym_fit", lambda _b: self.fit(), "btn_fit")
            rot = self.icon_btn("object-rotate-right", "sym_rotate",
                                lambda _b: self.rotate_screen(), "btn_rotate")
            shot = self.icon_btn("camera-photo", "sym_shot",
                                 lambda _b: self.screenshot(), "btn_screenshot")
            self.rec = Gtk.ToggleButton()
            self.rec.set_active(bool(self.config.get("record", False)))
            if Gtk.IconTheme.get_default().has_icon("media-record"):
                self.rec.add(Gtk.Image.new_from_icon_name("media-record", Gtk.IconSize.BUTTON))
            else:
                self.rec.set_label(tr("sym_record", ""))
            self.rec.set_tooltip_text(tr("btn_record"))
            self.rec.connect("toggled", self.on_rec)
            self.aud = Gtk.ToggleButton()
            self.aud.set_active(bool(self.config.get("audio", True)))
            if Gtk.IconTheme.get_default().has_icon("audio-volume-high"):
                self.aud.add(Gtk.Image.new_from_icon_name("audio-volume-high", Gtk.IconSize.BUTTON))
            else:
                self.aud.set_label(tr("sym_audio", ""))
            self.aud.set_tooltip_text(tr("audio_on") if self.config.get("audio") else tr("audio_off"))
            self.aud.connect("toggled", self.on_aud)
            self.stay = Gtk.ToggleButton()
            self.stay.set_active(bool(self.config.get("stay_awake", False)))
            if Gtk.IconTheme.get_default().has_icon("weather-clear-night"):
                self.stay.add(Gtk.Image.new_from_icon_name("weather-clear-night", Gtk.IconSize.BUTTON))
            else:
                self.stay.set_label(tr("sym_stay"))
            self.stay.set_tooltip_text(tr("stay_awake"))
            self.stay.connect("toggled", self.on_stay)
            # dedicated SMART COLOR ENGINE toggle (the whole old expander
            # was replaced by this single on/off button)
            self.ov_btn = Gtk.ToggleButton()
            self.ov_btn.set_active(self.overlay.get("enabled", False))
            if self.ov_btn.get_active():
                self.ov_btn.get_style_context().add_class("suggested-action")
            if Gtk.IconTheme.get_default().has_icon("color-select"):
                self.ov_btn.add(Gtk.Image.new_from_icon_name("color-select", Gtk.IconSize.BUTTON))
            else:
                self.ov_btn.set_label(tr("sym_smart_color", "\U0001f3a8"))
            self.ov_btn.set_tooltip_text(tr("btn_smart_color"))
            self.ov_btn.connect("toggled", self.on_ov_btn)
            st = self.icon_btn("preferences-system", "sym_settings",
                               lambda _b: self.settings_popover(_b), "btn_settings")
            for w in (self.btn_start2, self.btn_stop, fs, zi, zo, fit, rot, shot, self.rec, self.aud, self.stay, self.ov_btn, st):
                r1.pack_start(w, False, False, 0)
            page.pack_start(r1, False, False, 0)

            r2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
            r2.set_margin_start(4); r2.set_margin_end(4)
            for icon, sym, h, tip in (
                ("go-up", "sym_scroll_up", lambda _b: self.scroll("up"), "btn_scroll_up"),
                ("go-down", "sym_scroll_down", lambda _b: self.scroll("down"), "btn_scroll_down"),
                ("input-mouse", "sym_focus", lambda _b: self.focus_video(), "btn_focus"),
                ("go-home", "sym_home", lambda _b: self.keyev(K_HOME), "btn_home"),
                ("go-previous", "sym_back", lambda _b: self.keyev(K_BACK), "btn_back"),
                ("view-grid", "sym_recents", lambda _b: self.keyev(K_APP), "btn_recents"),
                ("audio-volume-high", "sym_vol_up", lambda _b: self.keyev(K_VOLUP), "btn_vol_up"),
                ("audio-volume-low", "sym_vol_down", lambda _b: self.keyev(K_VOLDOWN), "btn_vol_down"),
                ("system-shutdown", "sym_power", lambda _b: self.keyev(K_POWER), "btn_power"),
            ):
                r2.pack_start(self.icon_btn(icon, sym, h, tip), False, False, 0)
            page.pack_start(r2, False, False, 0)

            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup('<span color="#888888" size="small">%s</span>' % tr("scroll_note"))
            note.set_margin_start(6)
            page.pack_start(note, False, False, 0)

            ph = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            ph.set_valign(Gtk.Align.CENTER); ph.set_halign(Gtk.Align.CENTER)
            self.ph_label = Gtk.Label(wrap=True)
            self.ph_label.set_markup('<span size="x-large">%s</span>' % tr("scr_placeholder"))
            self.dl_btn = Gtk.Button(label=tr("scr_download"))
            self.dl_btn.connect("clicked", lambda _b: self.bundle_note())
            self.dl_btn.set_no_show_all(True); self.dl_btn.hide()
            ph.pack_start(self.ph_label, False, False, 0)
            ph.pack_start(self.dl_btn, False, False, 0)
            self.screen_holder = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            self.screen_holder.set_hexpand(True); self.screen_holder.set_vexpand(True)
            self.screen_holder.pack_start(ph, True, True, 0)
            page.pack_start(self.screen_holder, True, True, 0)

            self.scr_status = Gtk.Label(xalign=0.0)
            self.scr_status.set_margin_start(8); self.scr_status.set_margin_bottom(2)
            page.pack_start(self.scr_status, False, False, 0)
            self.stack.add_titled(page, "page_screen", tr("tab_screen"))
            self.update_placeholder()

        def update_placeholder(self):
            p = find_scrcpy()
            self.dl_btn.hide()
            if p is None:
                self.ph_label.set_markup('<span size="x-large">%s</span>' % tr("scr_placeholder"))
            else:
                self.ph_label.set_markup(
                    '<span size="x-large">%s</span>\n<span color="#2e7d32" size="small">%s</span>'
                    % (tr("scr_placeholder"), tr("bundled_ok")))

        def bundle_note(self):
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.WARNING,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("bundle_missing_title"))
            d.format_secondary_text(tr("bundle_missing"))
            d.run(); d.destroy()

        # ---------- Page 3: Controller (fully rebuilt) ----------
        # The stage shows a PRO VECTOR 3D model of the gamepad (Xbox 360
        # layout) drawn with cairo: every button with its real letter
        # (A/B/X/Y, LB/LT, RB/RT, LS/RS, SELECT/START, D-pad arrows), a
        # green guide sphere, cable and grip details - plus LIVE effects:
        # stick caps follow the axes, triggers fill, presses glow.

        def controller_family(self, name):
            return "\u0625\u0643\u0633 \u0628\u0648\u0643\u0633 360"

        def _ctrl_page_status(self, txt, color):
            lbl = getattr(self, "ctrl_status_lbl", None)
            if lbl is not None:
                lbl.set_markup(self.color(txt, color))

        def build_controller_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            page.set_margin_top(10); page.set_margin_bottom(10)
            page.set_margin_start(10); page.set_margin_end(10)

            # row 1: pick the pad (all detected) + auto-detect + refresh
            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            top.pack_start(Gtk.Label(label=tr("ctrl_select"), xalign=0.0), False, False, 0)
            self.ctrl_combo = Gtk.ComboBoxText()
            self.ctrl_combo.set_size_request(360, -1)
            self.ctrl_combo.set_hexpand(True)
            self.ctrl_combo.connect("changed", self.on_ctrl_changed)
            top.pack_start(self.ctrl_combo, True, True, 0)
            detect = Gtk.Button(label=tr("ctrl_autodetect"))
            detect.set_tooltip_text(tr("help_autodetect"))
            detect.connect("clicked", lambda _b: self.auto_detect())
            top.pack_start(detect, False, False, 0)
            refresh = self.icon_btn("view-refresh", "sym_refresh",
                                    lambda _b: self.refresh_ctrls_ui(), "ctrl_refresh")
            top.pack_start(refresh, False, False, 0)
            page.pack_start(top, False, False, 0)

            # the stage: big vector model, dominant (professional dark scene)
            frame = Gtk.Frame(label=tr("ctrl_diagram"))
            self.drawing = Gtk.DrawingArea()
            self.drawing.set_size_request(560, 380)
            self.drawing.set_hexpand(True); self.drawing.set_vexpand(True)
            self.drawing.connect("draw", self.draw_controller)
            frame.add(self.drawing)
            page.pack_start(frame, True, True, 0)
            self.cc = _pc.PadLinkController() if _pc is not None else None
            self._cc_last = time.time()
            self.timers.append(GLib.timeout_add(33, self.on_cc_tick))
            self.timers.append(GLib.timeout_add(50, self._fc_tick))

            # status row: colored state + live axis readout
            sr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)
            self.ctrl_status_lbl = Gtk.Label(xalign=0.0)
            sr.pack_start(self.ctrl_status_lbl, True, True, 0)
            self.axis_lbl = Gtk.Label(xalign=0.0, selectable=True)
            sr.pack_start(self.axis_lbl, True, True, 0)
            page.pack_start(sr, False, False, 0)

            # row 2: forward + vibration switches | vibration tuning
            r2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
            fsw = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            self.fwd_sw = Gtk.Switch(); self.fwd_sw.set_active(bool(self.config.get("forward_enabled", True)))
            self.fwd_sw.connect("notify::active", lambda s, p: self.on_fwd())
            fsw.pack_start(Gtk.Label(label=tr("fwd_switch"), xalign=0.0), False, False, 0)
            fsw.pack_start(self.fwd_sw, False, False, 0)
            r2.pack_start(fsw, False, False, 0)
            vsw = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            self.vib_sw = Gtk.Switch(); self.vib_sw.set_active(bool(self.config.get("vibration_enabled", True)))
            self.vib_sw.connect("notify::active", lambda s, p: self.on_vib())
            vsw.pack_start(Gtk.Label(label=tr("vib_switch"), xalign=0.0), False, False, 0)
            vsw.pack_start(self.vib_sw, False, False, 0)
            r2.pack_start(vsw, False, False, 0)
            r2.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 0)
            r2.pack_start(Gtk.Label(label=tr("ctrl_vib_intensity"), xalign=0.0), False, False, 0)
            self.vib_i = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.vib_i.set_range(0, 100); self.vib_i.set_value(float(self.config.get("vibration", 100)))
            self.vib_i.set_size_request(120, -1); self.vib_i.set_draw_value(True)
            self.vib_i.connect("value-changed", lambda s: self.cfg("vibration", int(s.get_value())))
            r2.pack_start(self.vib_i, False, False, 0)
            self.vib_ms = Gtk.SpinButton.new_with_range(100, 2000, 100)
            self.vib_ms.set_value(float(self.config.get("vibration_ms", 400)))
            self.vib_ms.set_tooltip_text(tr("ctrl_vib_duration"))
            self.vib_ms.connect("value-changed", lambda s: self.cfg("vibration_ms", int(s.get_value())))
            r2.pack_start(self.vib_ms, False, False, 0)
            vibtest = self.icon_btn("audio-volume-high", "sym_vibrate",
                                    lambda _b: self.do_vibrate(), "ctrl_vibrate")
            r2.pack_start(vibtest, False, False, 0)
            page.pack_start(r2, False, False, 0)

            # row 3: FULL CONTROL (system-wide) + deadzone + calibration ...
            r3 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            fcsw = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            fcsw.set_tooltip_text(tr("fc_help"))
            fcsw.pack_start(Gtk.Label(label=tr("fc_switch"), xalign=0.0), False, False, 0)
            self.fc_sw = Gtk.Switch()
            self.fc_sw.connect("notify::active", self.on_fc)
            fcsw.pack_start(self.fc_sw, False, False, 0)
            r3.pack_start(fcsw, False, False, 0)
            self.fc_status = Gtk.Label(xalign=0.0)
            self.fc_status.set_markup(self.color(tr("fc_off"), "#888888"))
            r3.pack_start(self.fc_status, False, False, 0)
            r3.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 0)
            r3.pack_start(Gtk.Label(label=tr("ctrl_deadzone"), xalign=0.0), False, False, 0)
            self.dz = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.dz.set_range(0, 50); self.dz.set_value(float(self.config.get("deadzone", 8)))
            self.dz.set_size_request(140, -1); self.dz.set_draw_value(True)
            self.dz.connect("value-changed", lambda s: self.cfg("deadzone", int(s.get_value())))
            r3.pack_start(self.dz, False, False, 0)
            rc = Gtk.Button(label=tr("ctrl_recenter"))
            rc.set_tooltip_text(tr("help_recenter"))
            rc.connect("clicked", lambda _b: self.recenter())
            r3.pack_start(rc, False, False, 0)
            rs = Gtk.Button(label=tr("ctrl_reset_cal"))
            rs.set_tooltip_text(tr("help_reset_cal"))
            rs.connect("clicked", lambda _b: self.reset_cal())
            r3.pack_start(rs, False, False, 0)
            fwdchk = Gtk.Button(label=tr("fwd_check_btn"))
            fwdchk.set_tooltip_text(tr("fwd_check_help"))
            fwdchk.connect("clicked", lambda _b: self.check_fwd())
            r3.pack_start(fwdchk, False, False, 0)
            spacer = Gtk.Box(); spacer.set_hexpand(True)
            r3.pack_start(spacer, True, True, 0)
            autofix = Gtk.Button(label=tr("autofix_btn"))
            autofix.set_tooltip_text(tr("autofix_help"))
            autofix.get_style_context().add_class("suggested-action")
            autofix.connect("clicked", self.auto_fix)
            r3.pack_start(autofix, False, False, 0)
            page.pack_start(r3, False, False, 0)

            hint = Gtk.Label(xalign=0.0, wrap=True)
            hint.set_markup('<span color="#888888" size="small">%s</span>' % tr("ctrl_fw"))
            page.pack_start(hint, False, False, 0)

            self.stack.add_titled(page, "page_controller", tr("tab_controller"))
            self.refresh_ctrls_ui()

        def cfg(self, k, v):
            self.config[k] = v
            save_config(self.config)

        def auto_fix(self, _b=None):
            """SMART AUTO-CORRECTION: checks the kernel driver (xpad), udev
            rules, permissions, adb and the connected controller, then
            re-measures the artwork and corrects every control position."""
            if getattr(self, "_autofix_running", False):
                return
            self._autofix_running = True
            self.toast(tr("autofix_running"))
            threading.Thread(target=self.auto_fix_worker, daemon=True).start()

        def auto_fix_worker(self):
            report = []
            def add(txt, ok=True):
                report.append((txt, ok))
            def run_priv(cmd):
                # works both when the app runs as root and via passwordless sudo
                if os.geteuid() == 0:
                    return run_cmd(cmd, 8)
                return run_cmd(["sudo", "-n"] + cmd, 8)
            # 1) kernel drivers (expertise from xpad/xboxdrv: load/reload)
            modprobe = shutil.which("modprobe")
            for mod in ("uinput", "joydev", "xpad"):
                rc, _, _ = run_cmd(["sh", "-c", "lsmod | grep -q '^%s '" % mod], 4)
                if rc == 0:
                    add(tr("autofix_already") % mod)
                elif modprobe is None:
                    add(tr("autofix_nokmod") % mod, False)
                else:
                    rc2, _, _ = run_priv(["modprobe", mod])
                    if rc2 == 0:
                        add(tr("autofix_loaded") % mod)
                    else:
                        add(tr("autofix_need_root") % mod, False)
            # 2) if the driver is up but no controller is seen: reload xpad
            if not detect_controllers() and modprobe is not None:
                run_priv(["sh", "-c",
                          "modprobe -r xpad 2>/dev/null; modprobe xpad 2>/dev/null"])
                time.sleep(1.0)
            # 3) udev rules (always rewrite the correct rule - the old one
            #    with '|' alternation never matched any device)
            rules = "/usr/share/padlink/51-padlink-android.rules"
            dst = "/etc/udev/rules.d/51-padlink-android.rules"
            try:
                if os.path.isfile(rules):
                    run_priv(["sh", "-c",
                              "mkdir -p /etc/udev/rules.d && cp -f '%s' '%s'" % (rules, dst)])
                if os.path.isfile(dst):
                    try:
                        os.chmod(dst, 0o644)
                    except Exception:
                        run_priv(["chmod", "644", dst])
                add(tr("autofix_udev_ok"))
            except Exception:
                add(tr("autofix_udev_need_root"), False)
            rc, _, _ = run_priv(["udevadm", "control", "--reload-rules"])
            run_priv(["udevadm", "trigger"])
            if rc == 0:
                add(tr("autofix_udev_reload"))
            # immediate permissions (no replug needed)
            for ev in glob.glob("/dev/input/event*") + glob.glob("/dev/input/js*") + ["/dev/uinput"]:
                try:
                    if os.access(ev, os.R_OK) and os.access(ev, os.W_OK):
                        continue
                    run_priv(["chmod", "666", ev])
                except Exception:
                    pass
            # input group membership check
            rc2, out, _ = run_cmd(["sh", "-c", "id -nG | tr ' ' '\n' | grep -qx input"], 4)
            if rc2 != 0:
                add(tr("autofix_input_group"), False)
            # 4) adb restart
            run_cmd(adb_cmd(["kill-server"]), 6)
            run_cmd(adb_cmd(["start-server"]), 6)
            add(tr("autofix_adb"))
            # 6) connected controller? re-check readability AFTER the fixes
            ctrls = detect_controllers()
            readable = [c for c in ctrls if c.get("readable")]
            if ctrls:
                add(tr("autofix_ctrl") % ctrls[0]["name"])
                if readable:
                    add(tr("autofix_readable") % readable[0]["name"])
                else:
                    add(tr("autofix_still_unreadable"), False)
            else:
                add(tr("autofix_no_ctrl"), False)
            # 7) smart artwork calibration (measures the real buttons)
            if self.cc is not None:
                try:
                    cal = self.cc.auto_calibrate()
                    for c in cal:
                        add(tr("autofix_calib") % c)
                    self.cc.set_state(self._ctrl_state())
                except Exception:
                    pass
            GLib.idle_add(self._apply_autofix, report)

        def _apply_autofix(self, report):
            self._autofix_running = False
            self.refresh_ctrls_ui()
            self.drawing.queue_draw()
            self.toast(tr("autofix_done"))
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("autofix_title"))
            lines = []
            for txt, ok in report:
                lines.append("\u2022 [%s] %s" % ("OK" if ok else "!", txt))
            d.format_secondary_text(tr("autofix_intro") + "\n\n" + "\n".join(lines))
            d.run(); d.destroy()

        def auto_detect(self):
            """Rescan and auto-select the first readable controller."""
            self.refresh_ctrls_ui()
            for i, c in enumerate(self.ctrls):
                if c.get("readable"):
                    self.ctrl_combo.set_active(i)
                    self.toast(tr("ctrl_autodetect_ok") + " " + c["name"])
                    return
            self.toast(tr("ctrl_no_dev"))

        def refresh_ctrls_ui(self):
            self.ctrls = detect_controllers()
            prev = self.ctrl_combo.get_active_id()
            self.ctrl_combo.handler_block_by_func(self.on_ctrl_changed)
            self.ctrl_combo.remove_all()
            if not self.ctrls:
                self.ctrl_combo.append("", tr("ctrl_no_dev")); self.ctrl_combo.set_active(0)
            else:
                for c in self.ctrls:
                    label = "%s  (%s)" % (c["name"], os.path.basename(c["path"]))
                    self.ctrl_combo.append(c["path"], label)
                if prev:
                    self.ctrl_combo.set_active_id(prev)
                if not self.ctrl_combo.get_active_id():
                    # auto-select first readable
                    idx = next((i for i, c in enumerate(self.ctrls) if c.get("readable")), 0)
                    self.ctrl_combo.set_active(idx)
            self.ctrl_combo.handler_unblock_by_func(self.on_ctrl_changed)
            self.on_ctrl_changed(self.ctrl_combo)

        def on_ctrl_changed(self, combo):
            if self.reader:
                self.reader.stop(); self.reader = None
            path = combo.get_active_id()
            if not path:
                self.ctrl_name.set_text(tr("ctrl_no_dev")); self.axis_lbl.set_text("")
                self._ctrl_page_status(tr("ctrl_no_dev"), "#c62828")
                self.drawing.queue_draw(); return
            sel = next((c for c in self.ctrls if c["path"] == path), None)
            if not sel:
                return
            self.ctrl_name.set_text("%s %s" % (tr("ctrl_name"), sel["name"]))
            det = []
            if sel.get("vendor"):
                det.append("Vendor=0x%04x Product=0x%04x" % (sel["vendor"], sel["product"]))
            if sel.get("buttons"):
                det.append("%s %d | %s %d" % (tr("ctrl_btns"), sel["buttons"],
                                              tr("ctrl_axes"), sel["axes"]))
            self.ctrl_detail.set_text(" | ".join(det))
            if sel["readable"] and "event" in os.path.basename(path):
                self.reader = GamepadReader(path, self.on_gp)
                self.reader.start()
                self.axis_lbl.set_text(tr("ctrl_reading"))
                self._ctrl_page_status(tr("ctrl_reading"), "#2e7d32")
            else:
                self.axis_lbl.set_text(tr("ctrl_perm"))
                self._ctrl_page_status(tr("ctrl_perm"), "#e65100")
            self.drawing.queue_draw()

        def on_fwd(self):
            self.cfg("forward_enabled", self.fwd_sw.get_active())
            self.toast(tr("fwd_on") if self.fwd_sw.get_active() else tr("fwd_off"))

        def on_vib(self):
            self.cfg("vibration_enabled", self.vib_sw.get_active())
            self.toast(tr("vib_on") if self.vib_sw.get_active() else tr("vib_off"))

        def do_vibrate(self):
            if not self.config.get("vibration_enabled", True):
                self.toast(tr("vib_disabled_note")); return
            p = self.ctrl_combo.get_active_id()
            if not p:
                return
            ok = test_rumble(p, int(self.config.get("vibration", 100)),
                             int(self.config.get("vibration_ms", 400)))
            self.toast(tr("ctrl_vib_sent").format(pct=int(self.config.get("vibration", 100)),
                                                  ms=int(self.config.get("vibration_ms", 400)))
                       if ok else tr("ctrl_vibrate_fail"))

        def _phone_input_devices(self):
            """Ask the PHONE itself (adb dumpsys input) whether the virtual
            gamepad exists there. Returns (ok, lines)."""
            if find_adb() is None:
                return False, [tr("fwd_chk_adb_missing")]
            rc, out, _ = run_cmd(adb_cmd(["shell", "dumpsys", "input"]), 8)
            if rc != 0 or not out:
                return False, [tr("fwd_chk_phone_query_fail")]
            hits = []
            for line in out.splitlines():
                low = line.lower()
                if any(k in low for k in ("gamepad", "uhid", "x-box", "xbox", "joystick")):
                    hits.append(line.strip())
            return True, hits

        def check_fwd(self):
            """END-TO-END gamepad forwarding check - tells exactly where
            the chain breaks: pad -> computer -> scrcpy -> phone -> game."""
            js = sorted(glob.glob("/dev/input/js*"))
            pads = [c for c in self.ctrls if c.get("readable")]
            lines = []
            # 1) is the pad visible + readable on the computer?
            if pads and js:
                lines.append(("[OK] ", tr("fwd_chk_pad") % pads[0]["name"]))
            elif pads:
                lines.append(("[!]", tr("fwd_chk_pad_noperm")))
            elif js:
                lines.append(("[!]", tr("fwd_chk_js_only")))
            else:
                lines.append(("[!]", tr("fwd_chk_nopad")))
            # 2) can we create the virtual gamepad (UHID)?
            if os.geteuid() == 0 or (os.path.exists("/dev/uinput")
                                     and os.access("/dev/uinput", os.W_OK)):
                lines.append(("[OK] ", tr("fwd_chk_uinput")))
            else:
                lines.append(("[!]", tr("fwd_chk_uinput_bad")))
            # 3) mirror + forwarding state of THIS running instance
            if not self.mirror_running:
                lines.append(("[!]", tr("fwd_chk_nomirror")))
            else:
                mode = getattr(self, "_gp_mode", None) or "uhid"
                if mode == "disabled":
                    if not self.config.get("forward_enabled", True):
                        lines.append(("[!]", tr("fwd_chk_fwd_off")))
                    else:
                        lines.append(("[!]", tr("fwd_chk_uinput_bad")))
                else:
                    lines.append(("[OK] ", tr("fwd_chk_mode") % mode.upper()))
                    glines = [t for t in self.proc_tail if any(
                        k in t.lower() for k in
                        ("gamepad", "uhid", "joystick", "uinput"))]
                    if glines:
                        lines.append(("[i]", "scrcpy: " + glines[-1]))
            # 4) what to verify on the phone / in the game
            lines.append(("[i]", tr("fwd_chk_phone")))
            lines.append(("[i]", tr("fwd_chk_game")))
            lines.append(("[i]", tr("fwd_chk_genshin")))
            lines.append(("[i]", tr("fwd_chk_aoa")))
            # 5) THE DEFINITIVE CHECK: does the pad exist on the PHONE?
            if self.mirror_running and self.phone_state == "ok":
                lines.append(("", "--- " + tr("fwd_chk_phone_input") + " ---"))
                pok, hits = self._phone_input_devices()
                if pok:
                    if hits:
                        lines.append(("[OK] ", tr("fwd_chk_phone_has_pad")))
                        lines.extend(("", h) for h in hits[:8])
                    else:
                        lines.append(("[!]", tr("fwd_chk_phone_no_pad")))
                else:
                    lines.extend(("[i]", h) for h in hits)
            # 6) raw scrcpy log tail (deep diagnosis)
            if self.mirror_running and self.proc_tail:
                lines.append(("", "--- scrcpy " + tr("fwd_chk_log") + " ---"))
                lines.extend(("", l) for l in self.proc_tail[-12:])
            body = "\n".join(tag + " " + txt for tag, txt in lines)
            d = Gtk.Dialog(title=tr("fwd_chk_title"), transient_for=self,
                           modal=True, destroy_with_parent=True)
            d.set_default_size(780, 540)
            bx = d.get_content_area()
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            tv = Gtk.TextView()
            tv.set_editable(False)
            tv.set_cursor_visible(False)
            tv.set_wrap_mode(Gtk.WrapMode.WORD)
            tv.get_buffer().set_text(body)
            sw.add(tv)
            bx.pack_start(sw, True, True, 0)
            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup(
                '<span color="#888888" size="small">%s</span>' % tr("fwd_chk_copy"))
            bx.pack_start(note, False, False, 0)
            d.add_button(tr("help_close"), Gtk.ResponseType.CLOSE)
            d.show_all()
            d.run(); d.destroy()

        def recenter(self):
            if self.reader is None:
                return
            import evdev
            _, axes, rng = self.reader.state()
            self.reader.offsets = {c: self.norm(axes.get(c, 0), rng.get(c), 0.0)
                                   for c in (evdev.ecodes.ABS_X, evdev.ecodes.ABS_Y,
                                             evdev.ecodes.ABS_RX, evdev.ecodes.ABS_RY)}
            self.toast(tr("ctrl_cal_done"))

        def reset_cal(self):
            if self.reader:
                self.reader.offsets = {}
            self.toast(tr("ctrl_cal_reset"))

        def norm(self, v, rng, dz):
            if not rng:
                return 0.0
            mn, mx = rng
            half = (mx - mn) / 2.0
            if half == 0:
                return 0.0
            x = (v - (mn + mx) / 2.0) / half
            return 0.0 if abs(x) < dz else clamp(x)

        def on_gp(self):
            self.drawing.queue_draw()
            try:
                import evdev
            except Exception:
                return
            if self.reader is None:
                return
            b, a, rng = self.reader.state()
            dz = self.config.get("deadzone", 8) / 100.0
            lx = self.norm(a.get(evdev.ecodes.ABS_X, 0), rng.get(evdev.ecodes.ABS_X), dz)
            ly = self.norm(a.get(evdev.ecodes.ABS_Y, 0), rng.get(evdev.ecodes.ABS_Y), dz)
            rx = self.norm(a.get(evdev.ecodes.ABS_RX, 0), rng.get(evdev.ecodes.ABS_RX), dz)
            ry = self.norm(a.get(evdev.ecodes.ABS_RY, 0), rng.get(evdev.ecodes.ABS_RY), dz)
            lt = self.norm(a.get(evdev.ecodes.ABS_Z, 0), rng.get(evdev.ecodes.ABS_Z), 0.0)
            rt = self.norm(a.get(evdev.ecodes.ABS_RZ, 0), rng.get(evdev.ecodes.ABS_RZ), 0.0)
            self.axis_lbl.set_text(tr("axis_readout").format(lx=lx, ly=ly, rx=rx, ry=ry, lt=lt, rt=rt))

        def _ctrl_state(self):
            """Current evdev state -> ControllerState for the artwork module."""
            st = _pc.ControllerState()
            if self.reader is None:
                return st
            b, a, rng = self.reader.state()
            try:
                import evdev
                E = evdev.ecodes
            except Exception:
                E = None
            def btn(n):
                if E is None:
                    return False
                c = getattr(E, n, -1)
                return c != -1 and b.get(c, 0) == 1
            st.A = btn("BTN_SOUTH"); st.B = btn("BTN_EAST")
            st.X = btn("BTN_WEST"); st.Y = btn("BTN_NORTH")
            st.LB = btn("BTN_TL"); st.RB = btn("BTN_TR")
            st.Xbox = btn("BTN_MODE")
            st.View = btn("BTN_SELECT"); st.Menu = btn("BTN_START")
            st.Share = btn("BTN_TRIGGER_HAPPY3")
            st.LS = btn("BTN_THUMBL"); st.RS = btn("BTN_THUMBR")
            def axis01(n, dmin, dmax):
                if E is None:
                    return 0.0
                c = getattr(E, n, -1)
                if c == -1:
                    return 0.0
                r = rng.get(c)
                mn, mx = r if r else (dmin, dmax)
                v = a.get(c, mn)
                return clamp((v - mn) / max(1.0, mx - mn), 0.0, 1.0)
            st.LT = axis01("ABS_Z", 0, 255) or axis01("ABS_BRAKE", 0, 255) or (1.0 if btn("BTN_TL2") else 0.0)
            st.RT = axis01("ABS_RZ", 0, 255) or axis01("ABS_GAS", 0, 255) or (1.0 if btn("BTN_TR2") else 0.0)
            dz = self.config.get("deadzone", 8) / 100.0
            def stick(n):
                if E is None:
                    return 0.0
                c = getattr(E, n, -1)
                if c == -1:
                    return 0.0
                return self.norm(a.get(c, 0), rng.get(c), dz)
            st.LX = stick("ABS_X"); st.LY = stick("ABS_Y")
            st.RX = stick("ABS_RX"); st.RY = stick("ABS_RY")
            hx = a.get(getattr(E, "ABS_HAT0X", -1) if E else -1, 0)
            hy = a.get(getattr(E, "ABS_HAT0Y", -1) if E else -1, 0)
            has_hat = E is not None and (getattr(E, "ABS_HAT0X", -1) in rng or getattr(E, "ABS_HAT0Y", -1) in rng)
            if has_hat:
                st.DU = hy == -1; st.DD = hy == 1
                st.DL = hx == -1; st.DR = hx == 1
            else:
                st.DU = btn("BTN_DPAD_UP"); st.DD = btn("BTN_DPAD_DOWN")
                st.DL = btn("BTN_DPAD_LEFT"); st.DR = btn("BTN_DPAD_RIGHT")
            return st

        def _theme_bg(self, wdg):
            """Best-effort theme background color (no deprecated API)."""
            try:
                ctx = wdg.get_style_context()
                col = Gdk.RGBA()
                if ctx.lookup_color("theme_bg_color", col):
                    if col.alpha > 0.01:
                        return col
                # fallback: walk parents with the same safe lookup
                p = wdg.get_parent()
                while p is not None:
                    c2 = Gdk.RGBA()
                    if p.get_style_context().lookup_color("theme_bg_color", c2) and c2.alpha > 0.01:
                        return c2
                    p = p.get_parent()
            except Exception:
                pass
            return None

        def on_cc_tick(self):
            """Animation loop: guide pulse + easing of sticks/triggers/glows."""
            if not self._alive:
                return False
            if self.stack.get_visible_child_name() == "page_controller" and self.cc is not None:
                now = time.time()
                dt = min(0.1, now - getattr(self, "_cc_last", now))
                self._cc_last = now
                self.cc.update(dt)
                self.drawing.queue_draw()
            return True

        def draw_controller(self, wdg, cr):
            """Draw the USER'S controller artwork (transparent shape, no
            image background) with live effects on top."""
            if _pc is None:
                return
            al = wdg.get_allocation()
            W, H = al.width, al.height
            if W <= 0 or H <= 0:
                return
            if self.cc is None:
                self.cc = _pc.PadLinkController()
            # Clean page background (theme color only - the shape has none).
            col = self._theme_bg(wdg)
            if col is not None:
                cr.set_source_rgba(col.red, col.green, col.blue, col.alpha)
            else:
                cr.set_source_rgb(0.94, 0.94, 0.94)
            cr.paint()
            self.cc.set_state(self._ctrl_state())
            self.cc.draw(cr, W, H)

        # ---------- Auto mirror (controller works on the phone) ----------
        def _maybe_auto_mirror(self):
            """Start the mirror automatically when phone + controller are
            both connected, so the gamepad works on the phone at once."""
            if not self.config.get("auto_mirror", True) or self._auto_blocked:
                return
            if self.mirror_running:
                return
            if self.phone_state != "ok" or not self.ctrls:
                return
            serial = ",".join(self.phones)
            if self._auto_started == serial:
                return
            self._auto_started = serial
            GLib.idle_add(self._do_auto_mirror)

        def _do_auto_mirror(self):
            if self._alive and not self.mirror_running:
                self.start_mirror(auto=True)
                if self.mirror_running:
                    self.toast(tr("auto_mirror_on"))
                else:
                    self._auto_blocked = True
            return False

        # ---------- Refresh ----------
        def refresh_async(self, force=False):
            threading.Thread(target=self.refresh_worker, args=(force,), daemon=True).start()

        def refresh_worker(self, force):
            try:
                phones = detect_phones()
                ctrls = detect_controllers()
                GLib.idle_add(self.apply_refresh, phones, ctrls)
            except Exception as e:
                log("refresh: %s" % e)

        def periodic_refresh(self):
            self.refresh_async()
            if self.reader is not None:
                try:
                    if not os.path.exists(self.reader.path):
                        self.reader.stop()
                        self.reader = None
                        self.drawing.queue_draw()
                except Exception:
                    pass
            return True

        def apply_refresh(self, phones, ctrls):
            if not self._alive:
                return
            state, serials = phones
            self.phone_state, self.phones = state, serials
            if state == "ok":
                self.phone_status.set_markup(self.color(tr("phone_ok"), "#2e7d32"))
                self.phone_list.set_text(tr("phone_serial") + " " + ", ".join(serials))
            else:
                self._auto_started = ""
                self._auto_blocked = False
                if state == "unauthorized":
                    self.phone_status.set_markup(self.color(tr("phone_unauthorized"), "#e65100"))
                elif state == "adb_missing":
                    self.phone_status.set_markup(self.color(tr("phone_adb_missing"), "#c62828"))
                else:
                    self.phone_status.set_markup(self.color(tr("phone_none"), "#c62828"))
            if ctrls:
                readable = [c for c in ctrls if c.get("readable")]
                if readable:
                    self.ctrl_status.set_markup(self.color(tr("ctrl_ok"), "#2e7d32"))
                else:
                    self.ctrl_status.set_markup(self.color(tr("ctrl_perm"), "#e65100"))
                self.ctrl_name.set_text("\n".join(
                    "%s [%s] - %s" % (c["name"], os.path.basename(c["path"]),
                                      controller_type(c["name"])) for c in ctrls))
            else:
                self.ctrl_status.set_markup(self.color(tr("ctrl_none"), "#c62828"))
                self.ctrl_name.set_text("")
            self._maybe_auto_mirror()

        def _try_fix_uinput(self):
            """Best-effort silent uinput fix (root or passwordless sudo;
            never prompts for a password)."""
            def ready():
                return (os.path.exists("/dev/uinput") and
                        os.access("/dev/uinput", os.W_OK))
            if ready():
                return True
            def try_priv(cmd):
                if os.geteuid() == 0:
                    return run_cmd(["sh", "-c", cmd], 6)
                return run_cmd(["sudo", "-n", "sh", "-c", cmd], 8)
            if not os.path.exists("/dev/uinput"):
                try_priv("modprobe uinput 2>/dev/null || true")
                time.sleep(0.4)
            if not ready():
                try_priv("chmod 666 /dev/uinput 2>/dev/null || true")
            return ready()

        def _pick_gamepad_mode(self):
            """Decide the REAL gamepad forwarding mode for this run.
            The pad is NOT required at startup: scrcpy 4.x hot-plugs
            gamepads at runtime, so a pad plugged in later is picked up
            automatically. Only uinput (UHID) readiness can block it,
            and we try to fix that silently first."""
            want = self.config.get("gamepad", "uhid")
            if not self.config.get("forward_enabled", True):
                return "disabled", None
            if want == "uhid" and os.geteuid() != 0:
                if not (os.path.exists("/dev/uinput") and
                        os.access("/dev/uinput", os.W_OK)):
                    if self._try_fix_uinput():
                        log("uinput auto-fixed before mirror start")
                    else:
                        return "disabled", "gp_uinput_warn"
            return want, None

        def build_scrcpy_args(self, sc):
            args = [sc, "--window-title=" + EMBED_TITLE, "--shortcut-mod=lalt"]
            mode = getattr(self, "_gp_mode", None)
            if mode is None:
                mode = "uhid" if self.config.get("forward_enabled", True) else "disabled"
            args.append("--gamepad=" + mode)
            if self.config.get("mouse_mode", "sdk") == "uhid":
                args += ["--mouse=uhid", "--keyboard=uhid"]
            else:
                args += ["--mouse=sdk", "--keyboard=sdk"]
            preset = self.config.get("preset", "balanced")
            audio = self.config.get("audio", True)
            ms = self.config.get("max_size", "1024"); fps = self.config.get("fps", "60")
            br = self.config.get("bitrate", "16M")
            if preset == "speed240":
                audio = False; ms = "720"; fps = "240"; br = "12M"
            elif preset == "gaming":
                audio = False; ms = "800"; fps = "144"; br = "12M"
            elif preset == "quality":
                audio = True; ms = "1920"; fps = "60"; br = "32M"
            if ms != "original":
                try:
                    args += ["--max-size", str(int(ms))]
                except ValueError:
                    pass
            try:
                args += ["--max-fps", str(int(fps))]
            except ValueError:
                pass
            args += ["--video-bit-rate", br]
            if not audio:
                args.append("--no-audio")
            if self.config.get("stay_awake"):
                args.append("--stay-awake")
            if self.config.get("turn_screen_off"):
                args.append("--turn-screen-off")
            if self.config.get("record"):
                try:
                    os.makedirs(VIDEO_DIR, exist_ok=True)
                except Exception:
                    pass
                args += ["--record", os.path.join(VIDEO_DIR, "padlink_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".mp4")]
            return args

        # ---------- FULL CONTROL: gamepad -> system key events ----------
        # The virtual gamepad (UHID) only drives apps that read gamepads
        # (games, emulators). To control EVERY screen on the phone (home
        # screen, settings, any app) the pad becomes a remote: D-pad and
        # sticks inject KEYCODE_DPAD_* focus navigation, A=select, B=back,
        # Y=home, X=menu, START=recents - through ONE persistent
        # "adb shell" stdin pipe (each line = one keyevent, low latency).
        FC_DIR = {"up": 19, "down": 20, "left": 21, "right": 22}
        # Linux evdev button code -> Android keycode (Xbox layout)
        FC_BTN = {0x30: 23, 0x31: 4, 0x32: 82, 0x33: 3,
                  0x35: 4, 0x36: 187, 0x37: 3,
                  0x71: 19, 0x72: 20, 0x73: 21, 0x74: 22}

        def _fc_set_state(self, st):
            self.fc_state = st
            lbl = getattr(self, "fc_status", None)
            if lbl is not None:
                if st == "on":
                    lbl.set_markup(self.color(tr("fc_on"), "#2e7d32"))
                elif st == "dead":
                    lbl.set_markup(self.color(tr("fc_shell_dead"), "#c62828"))
                else:
                    lbl.set_markup(self.color(tr("fc_off"), "#888888"))

        def _fc_key(self, code):
            sh = self.fc_shell
            if sh is None or sh.poll() is not None:
                self._fc_set_state("dead")
                return False
            try:
                sh.stdin.write(b"input keyevent %d\n" % code)
                sh.stdin.flush()
                self.fc_sent += 1
                return True
            except Exception:
                self._fc_set_state("dead")
                return False

        def _fc_stop(self):
            sh = self.fc_shell
            self.fc_shell = None
            self.fc_held = None
            if sh is not None:
                try:
                    sh.stdin.close()
                except Exception:
                    pass
                try:
                    sh.terminate()
                except Exception:
                    pass
            self._fc_set_state("off")

        def _fc_start(self):
            self._fc_stop()
            if self.reader is None:
                self.toast(tr("fc_no_pad"))
                self._fc_toggling = True
                self.fc_sw.set_active(False)
                self._fc_toggling = False
                return
            adb = find_adb()
            if adb is None:
                self.toast(tr("fc_no_adb"))
                self._fc_toggling = True
                self.fc_sw.set_active(False)
                self._fc_toggling = False
                return
            try:
                self.fc_shell = subprocess.Popen([adb, "shell"],
                                                 stdin=subprocess.PIPE,
                                                 stdout=subprocess.DEVNULL,
                                                 stderr=subprocess.DEVNULL)
            except Exception:
                self.fc_shell = None
                self.toast(tr("fc_no_adb"))
                self._fc_toggling = True
                self.fc_sw.set_active(False)
                self._fc_toggling = False
                return
            self.fc_sent, self.fc_held, self.fc_last = 0, None, 0.0
            self.fc_prev_btns = {}
            self._fc_set_state("on")
            self.toast(tr("fc_map"))

        def on_fc(self, _s=None, _p=None):
            if getattr(self, "_fc_toggling", False):
                return
            if self.fc_sw.get_active():
                self._fc_start()
            else:
                self._fc_stop()

        def _fc_dir(self, buttons, axes, ranges):
            """Current navigation direction: D-pad hat first, then sticks."""
            hx = axes.get(16, 0)   # ABS_HAT0X
            hy = axes.get(17, 0)   # ABS_HAT0Y
            if hy == -1:
                return "up"
            if hy == 1:
                return "down"
            if hx == -1:
                return "left"
            if hx == 1:
                return "right"
            try:
                import evdev
                E = evdev.ecodes
                pairs = ((getattr(E, "ABS_X", 0), getattr(E, "ABS_Y", 1)),
                         (getattr(E, "ABS_Z", 2), getattr(E, "ABS_RZ", 5)),
                         (getattr(E, "ABS_RX", 3), getattr(E, "ABS_RY", 4)))
            except Exception:
                pairs = ((0, 1), (2, 5), (3, 4))
            dz = max(0, min(50, int(self.config.get("deadzone", 8)))) / 100.0
            base = dz if dz > 0.0 else 0.12
            for cx, cy in pairs:
                nx = self.norm(axes.get(cx, 0), ranges.get(cx), base)
                ny = self.norm(axes.get(cy, 0), ranges.get(cy), base)
                if nx:
                    return "left" if nx < 0 else "right"
                if ny:
                    return "up" if ny < 0 else "down"
            return None

        def _fc_tick(self):
            if not self._alive or self.fc_state != "on":
                return True
            if self.fc_sw is None or not self.fc_sw.get_active():
                return True
            if self.reader is None:
                return True
            try:
                buttons, axes, ranges = self.reader.state()
            except Exception:
                return True
            now = time.time()
            d = self._fc_dir(buttons, axes, ranges)
            if d != self.fc_held:
                self.fc_held = d
                self.fc_last = now
                if d is not None:
                    self._fc_key(self.FC_DIR[d])
            elif d is not None and now - self.fc_last > 0.16:
                self._fc_key(self.FC_DIR[d])
                self.fc_last = now
            for code, val in buttons.items():
                if val == 1 and self.fc_prev_btns.get(code, 0) == 0 \
                        and code in self.FC_BTN:
                    self._fc_key(self.FC_BTN[code])
            self.fc_prev_btns = dict(buttons)
            return True


        # ---------- SELF-CHECK: did the pad reach the phone? ----------
        # ~12s after mirror start (pad forwarding on), ask the phone
        # itself. If the virtual pad is absent, open a dialog that says
        # exactly why + offers the one-tap alternate mode / full report.
        def _selfcheck(self):
            if not self._alive or not self.mirror_running:
                return False
            mode = getattr(self, "_gp_mode", None)
            self._selfcheck_count = getattr(self, "_selfcheck_count", 0) + 1
            if self._selfcheck_count > 2:
                return False
            if mode == "disabled":
                try:
                    self._selfcheck_dialog_disabled()
                except Exception:
                    pass
                return False
            try:
                ok, hits = self._phone_input_devices()
            except Exception:
                return False
            if not ok or hits:
                return False
            try:
                self._selfcheck_dialog(mode)
            except Exception:
                pass
            return False

        def _selfcheck_dialog_disabled(self):
            d = Gtk.MessageDialog(transient_for=self, modal=False,
                                  message_type=Gtk.MessageType.WARNING,
                                  text=tr("sd_dis_title"))
            d.format_secondary_text(tr("sd_dis_body"))
            d.add_button(tr("sd_dis_fix"), 1)
            d.add_button(tr("help_close"), Gtk.ResponseType.CLOSE)

            def on_resp(_d, r):
                d.destroy()
                if r == 1:
                    sw = getattr(self, "fwd_sw", None)
                    if sw is not None and not sw.get_active():
                        sw.handler_block_by_func(self.on_fwd)
                        sw.set_active(True)
                        sw.handler_unblock_by_func(self.on_fwd)
                    self.config["forward_enabled"] = True
                    save_config(self.config)
                    self.start_mirror(auto=True)
                return False
            d.connect("response", on_resp)
            d.show_all()

        def _selfcheck_dialog(self, mode):
            body = tr("sd_aoa_body") if mode == "aoa" else tr("sd_uhid_body")
            d = Gtk.MessageDialog(transient_for=self, modal=False,
                                  message_type=Gtk.MessageType.WARNING,
                                  text=tr("sd_title"))
            d.format_secondary_text(body)
            if mode == "aoa":
                d.add_button(tr("sd_btn_uhid"), 2)
            else:
                d.add_button(tr("sd_btn_aoa"), 1)
            d.add_button(tr("sd_btn_report"), 3)
            d.add_button(tr("help_close"), Gtk.ResponseType.CLOSE)

            def on_resp(_d, r):
                if r == 1:
                    self.config["gamepad"] = "aoa"
                    save_config(self.config)
                    d.destroy()
                    self.start_mirror(auto=True)
                elif r == 2:
                    self.config["gamepad"] = "uhid"
                    save_config(self.config)
                    d.destroy()
                    self.start_mirror(auto=True)
                elif r == 3:
                    d.destroy()
                    self.check_fwd()
                else:
                    d.destroy()
                return False
            d.connect("response", on_resp)
            d.show_all()

        def start_mirror(self, auto=False):
            self._auto_mirror_run = auto
            if find_adb() is None:
                self.toast(tr("phone_adb_missing")); return
            state, _ = detect_phones()
            if state != "ok":
                self.toast(tr("scr_need_phone")); return
            sc = find_scrcpy()
            if sc is None:
                self.bundle_note(); return
            self.stop_mirror()
            self._gp_mode, self._gp_warn = self._pick_gamepad_mode()
            args = self.build_scrcpy_args(sc)
            log("start: " + " ".join(args))
            try:
                self.proc = subprocess.Popen(args, stdout=subprocess.PIPE,
                                             stderr=subprocess.STDOUT)
            except Exception as e:
                log("start err %s" % e); self.toast(str(e)); return
            self.mirror_running = True
            self.mirror_start_ts = time.time()
            self.proc_tail = []; self.first_error = None
            self.btn_start2.set_sensitive(False); self.btn_stop.set_sensitive(True)
            self.scr_status.set_text(tr("scr_running"))
            self.overlay_start()
            # gamepad forwarding feedback (the two silent killers)
            if self._gp_warn:
                self.toast(tr(self._gp_warn))
            elif self._gp_mode != "disabled":
                if not glob.glob("/dev/input/js*"):
                    self.toast(tr("gp_pad_later"))
                else:
                    self.toast(tr("gp_in_game_note"))
            # self-diagnosis (12s): catch disabled forwarding too
            self._selfcheck_count = 0
            self.timers.append(GLib.timeout_add(12000, self._selfcheck))
            # Show standalone note inside the holder.
            for ch in list(self.screen_holder.get_children()):
                self.screen_holder.remove(ch)
            note = Gtk.Label(label=tr("scr_standalone_note"), wrap=True,
                             halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
            self.screen_holder.pack_start(note, True, True, 0)
            self.screen_holder.show_all()
            threading.Thread(target=self.drain_proc, daemon=True).start()

        def drain_proc(self):
            if self.proc is None or self.proc.stdout is None:
                return
            try:
                for line in iter(self.proc.stdout.readline, b""):
                    t = line.decode(errors="replace").strip()
                    self.proc_tail.append(t)
                    if len(self.proc_tail) > 40:
                        self.proc_tail.pop(0)
                    if t and self.first_error is None and ("ERROR" in t.upper() or "failed" in t.lower()):
                        self.first_error = t
            except Exception:
                pass

        def watch_mirror(self):
            if self._alive and self.proc is not None and self.mirror_running:
                if self.proc.poll() is not None:
                    if time.time() - self.mirror_start_ts < 6.0:
                        GLib.idle_add(self.on_early_exit)
                    else:
                        GLib.idle_add(self.on_exit)
                    return False
            return True

        def on_early_exit(self):
            self.mirror_running = False
            self.btn_start2.set_sensitive(True); self.btn_stop.set_sensitive(False)
            self.proc = None
            self.overlay_stop()
            if self._auto_mirror_run:
                self._auto_mirror_run = False
                self._auto_blocked = True
                self.toast(tr("auto_mirror_fail"))
                return
            body = tr("err_body")
            if self.first_error:
                body += "\n\n<big><b>%s</b></big>" % GLib.markup_escape_text(self.first_error)
            elif self.proc_tail:
                body += "\n\n<tt>%s</tt>" % GLib.markup_escape_text("\n".join(self.proc_tail[-5:]))
            body += "\n\n" + tr("err_tips")
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.ERROR,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("err_title"))
            d.format_secondary_markup(body)
            d.run(); d.destroy()

        def on_exit(self):
            self.mirror_running = False
            self.btn_start2.set_sensitive(True); self.btn_stop.set_sensitive(False)
            self.scr_status.set_text(tr("scr_ended"))
            self.proc = None
            self.overlay_stop()

        def stop_mirror(self, manual=False):
            if manual:
                self._auto_blocked = True
            self.overlay_stop()
            if self.proc is not None:
                try:
                    self.proc.terminate(); self.proc.wait(timeout=4)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
            self.proc = None
            self.mirror_running = False
            self.btn_start2.set_sensitive(True); self.btn_stop.set_sensitive(False)
            self.scr_status.set_text(tr("scr_stopped"))
            # restore placeholder
            for ch in list(self.screen_holder.get_children()):
                self.screen_holder.remove(ch)
            ph = Gtk.Label(wrap=True)
            ph.set_markup('<span size="x-large">%s</span>' % tr("scr_placeholder"))
            ph.set_halign(Gtk.Align.CENTER); ph.set_valign(Gtk.Align.CENTER)
            self.screen_holder.pack_start(ph, True, True, 0)
            self.screen_holder.show_all()

        # ---------- Screen controls ----------
        def target_xid(self):
            if xdotool():
                rc, out, _ = run_cmd(["xdotool", "search", "--name", EMBED_TITLE], 5)
                for line in out.splitlines():
                    try:
                        return int(line)
                    except ValueError:
                        continue
            return 0

        def wcenter(self, xid):
            rc, out, _ = run_cmd(["xdotool", "getwindowgeometry", "--shell", str(xid)], 5)
            d = {}
            for line in out.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    try:
                        d[k] = int(v)
                    except ValueError:
                        continue
            return d.get("X", 0) + d.get("WIDTH", 0) // 2, d.get("Y", 0) + d.get("HEIGHT", 0) // 2

        def zoom(self, direction):
            if not xdotool():
                self.toast(tr("no_xdotool")); return
            xid = self.target_xid()
            if not xid:
                return
            cx, cy = self.wcenter(xid)
            if not cx:
                return
            run_cmd(["xdotool", "mousemove", str(cx), str(cy)], 5)
            run_cmd(["xdotool", "keydown", "alt"], 5)
            run_cmd(["xdotool", "click", "4" if direction > 0 else "5"], 5)
            run_cmd(["xdotool", "keyup", "alt"], 5)

        def fit(self):
            if not xdotool():
                self.toast(tr("no_xdotool")); return
            xid = self.target_xid()
            if not xid:
                return
            run_cmd(["xdotool", "windowfocus", "--sync", str(xid)], 5)
            run_cmd(["xdotool", "key", "alt+g"], 5)

        def toggle_fullscreen(self):
            if self.mirror_running and xdotool():
                xid = self.target_xid()
                if xid:
                    run_cmd(["xdotool", "windowactivate", "--sync", str(xid)], 5)
                    run_cmd(["xdotool", "key", "alt+f"], 5)
                    self.toast(tr("fs_scrcpy")); return
            self.toast(tr("fs_on"))

        def focus_video(self):
            if not xdotool():
                self.toast(tr("no_xdotool")); return
            xid = self.target_xid()
            if not xid:
                self.toast(tr("focus_no_window")); return
            run_cmd(["xdotool", "windowfocus", "--sync", str(xid)], 5)
            cx, cy = self.wcenter(xid)
            if cx:
                run_cmd(["xdotool", "mousemove", str(cx), str(cy)], 5)
                run_cmd(["xdotool", "click", "1"], 5)
            self.toast(tr("focus_done"))

        def scroll(self, direction):
            if not self.phones:
                self.toast(tr("scr_need_phone")); return
            serial = self.phones[0]
            w, h = get_phone_size(serial)
            cx = w // 2
            if direction == "down":
                y1, y2 = int(h * 0.68), int(h * 0.32)
            else:
                y1, y2 = int(h * 0.32), int(h * 0.68)
            run_cmd(adb_cmd(["-s", serial, "shell", "input", "swipe",
                             str(cx), str(y1), str(cx), str(y2), "220"]), 8)
            self.toast(tr("scroll_ok_" + direction))

        def keyev(self, code):
            run_cmd(adb_cmd(["shell", "input", "keyevent", str(code)]), 8)

        def rotate_screen(self):
            run_cmd(adb_cmd(["shell", "settings", "put", "system", "accelerometer_rotation", "0"]))
            rc, out, _ = run_cmd(adb_cmd(["shell", "settings", "get", "system", "user_rotation"]), 8)
            try:
                cur = int(out.strip())
            except ValueError:
                cur = 0
            run_cmd(adb_cmd(["shell", "settings", "put", "system", "user_rotation", str((cur + 1) % 4)]))
            self.toast(tr("rotated"))

        def screenshot(self):
            try:
                os.makedirs(SCREENSHOT_DIR, exist_ok=True)
                path = os.path.join(SCREENSHOT_DIR, "padlink_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".png")
                with open(path, "wb") as f:
                    subprocess.run(adb_cmd(["exec-out", "screencap", "-p"]), stdout=f, timeout=20)
                self.toast(tr("scr_saved") + ": " + path)
            except Exception:
                self.toast(tr("scr_saved"))

        def on_rec(self, b):
            self.cfg("record", b.get_active())
            self.toast(tr("record_started") if b.get_active() else tr("record_off"))

        def on_aud(self, b):
            self.cfg("audio", b.get_active())
            try:
                self.aud.set_tooltip_text(tr("audio_on") if b.get_active() else tr("audio_off"))
            except Exception:
                pass
            self.toast(tr("audio_on") if b.get_active() else tr("audio_off"))

        def on_stay(self, b):
            self.cfg("stay_awake", b.get_active())
            self.toast(tr("stay_on") if b.get_active() else tr("stay_off"))

        # ---------- Smart color layer ----------
        def _overlay_params(self):
            return dict(
                auto=True,  # the button IS the fully-automatic engine
                opacity=self.overlay.get("opacity", 0.25),
                tint=[c / 255.0 for c in self.overlay.get("color", [77, 124, 255])],
                clarity=self.overlay.get("clarity", 0.0),
                exposure=self.overlay.get("exposure", 0.0),
                saturation=self.overlay.get("saturation", 0.0),
                contrast=self.overlay.get("contrast", 0.0),
                temperature=self.overlay.get("temperature", 0.0))

        def overlay_start(self):
            if _so is None:
                log("overlay module missing (import failed)")
                self.toast(tr("ov_module_missing"))
                self.smart_ov = None
                return
            if not self.overlay.get("enabled", False):
                self.smart_ov = None
                return
            try:
                if self.smart_ov is None or self.smart_ov.broken:
                    self.smart_ov = _so.SmartOverlay()
                self.smart_ov.set_broken_cb(self.on_ov_broken)
                self.smart_ov.set_params(**self._overlay_params())
                self.smart_ov.start()
            except Exception as e:
                log("overlay start err %s" % e)
                self.smart_ov = None

        def overlay_stop(self):
            if self.smart_ov is not None:
                try:
                    self.smart_ov.stop()
                except Exception:
                    pass
                self.smart_ov = None

        def overlay_tick(self):
            """High-rate timer (66ms / 15Hz) inside the GTK loop. The
            engine self-throttles: geometry @ ~5Hz, scene AI @ 15Hz
            (adaptive down to ~8Hz on static scenes)."""
            if self.smart_ov is not None and self.mirror_running and \
                    self.overlay.get("enabled", False):
                try:
                    self.smart_ov.tick()
                except Exception:
                    pass
            return True

        def on_ov_broken(self):
            """Engine self-test failed (no compositor / no RGBA alpha):
            the window would be opaque. Revert the toggle and tell the
            user - a white screen is impossible now."""
            self.smart_ov = None
            self.overlay["enabled"] = False
            self.cfg("overlay_enabled", False)
            b = getattr(self, "ov_btn", None)
            if b is not None:
                if b.get_active():
                    b.handler_block_by_func(self.on_ov_btn)
                    b.set_active(False)
                    b.handler_unblock_by_func(self.on_ov_btn)
                try:
                    b.get_style_context().remove_class("suggested-action")
                except Exception:
                    pass
            try:
                d = Gtk.MessageDialog(transient_for=self, modal=False,
                                      message_type=Gtk.MessageType.WARNING,
                                      text=tr("ov_broken_title"))
                d.format_secondary_text(tr("ov_broken_body"))
                d.add_button(tr("ov_retry"), 1)
                d.add_button(tr("help_close"), Gtk.ResponseType.CLOSE)

                def on_resp(_d, r):
                    d.destroy()
                    if r == 1:
                        bb = getattr(self, "ov_btn", None)
                        if bb is not None and not bb.get_active():
                            bb.handler_block_by_func(self.on_ov_btn)
                            bb.set_active(True)
                            bb.handler_unblock_by_func(self.on_ov_btn)
                    return False
                d.connect("response", on_resp)
                d.show_all()
            except Exception:
                pass
            self.toast(tr("ov_unsupported"))

        def on_ov_btn(self, b):
            """Dedicated SMART COLOR ENGINE on/off button: one press
            activates the full advanced grading pipeline automatically
            over the mirror window (or arms it for the next start).
            If the environment cannot be transparent, the engine self-
            tests and reverts the switch (see on_ov_broken)."""
            on = b.get_active()
            self.overlay["enabled"] = on
            self.cfg("overlay_enabled", on)
            if on:
                b.get_style_context().add_class("suggested-action")
                if self.mirror_running:
                    self.overlay_start()
                    if self.smart_ov is not None and not self.smart_ov.broken:
                        self.toast(tr("ov_on"))
                    # else: on_ov_broken already reverted switch + toast
                else:
                    self.toast(tr("ov_on_idle"))
            else:
                b.get_style_context().remove_class("suggested-action")
                self.overlay_stop()
                self.toast(tr("ov_off"))

        # ---------- Settings ----------
        def settings_popover(self, btn):
            pop = Gtk.Popover.new(btn)
            bx = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            bx.set_margin_top(10); bx.set_margin_bottom(10); bx.set_margin_start(12); bx.set_margin_end(12)
            bx.set_size_request(380, -1)

            def row(label, combo, tip=None):
                r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                r.pack_start(Gtk.Label(label=label), False, False, 0)
                r.pack_start(combo, True, True, 0)
                if tip:
                    combo.set_tooltip_text(tr(tip))
                return r

            preset = Gtk.ComboBoxText()
            for v, k in (("balanced", "preset_balanced"), ("gaming", "preset_gaming"),
                         ("speed240", "preset_speed240"), ("quality", "preset_quality")):
                preset.append(v, tr(k))
            preset.set_active_id(self.config.get("preset", "balanced"))
            bx.pack_start(row(tr("preset"), preset, "help_preset"), False, False, 0)

            size = Gtk.ComboBoxText()
            for v, l in (("original", tr("opt_original")), ("1920", "1920"), ("1280", "1280"),
                         ("1024", "1024"), ("800", "800"), ("720", "720")):
                size.append(v, l)
            size.set_active_id(self.config.get("max_size", "1024"))
            bx.pack_start(row(tr("set_max_size"), size, "help_max_size"), False, False, 0)

            fps = Gtk.ComboBoxText()
            for v in ("240", "144", "120", "90", "60", "30", "15"):
                fps.append(v, v)
            fps.set_active_id(self.config.get("fps", "60"))
            bx.pack_start(row(tr("set_fps"), fps, "help_fps"), False, False, 0)

            bit = Gtk.ComboBoxText()
            for v in ("32M", "16M", "8M", "4M", "2M"):
                bit.append(v, v)
            bit.set_active_id(self.config.get("bitrate", "16M"))
            bx.pack_start(row(tr("set_bitrate"), bit, "help_bitrate"), False, False, 0)

            gp = Gtk.ComboBoxText()
            gp.append("uhid", tr("opt_uhid")); gp.append("aoa", tr("opt_aoa"))
            gp.set_active_id(self.config.get("gamepad", "uhid"))
            bx.pack_start(row(tr("set_gamepad"), gp, "help_gamepad"), False, False, 0)

            mouse = Gtk.ComboBoxText()
            mouse.append("sdk", tr("mouse_sdk")); mouse.append("uhid", tr("mouse_uhid_opt"))
            mouse.set_active_id(self.config.get("mouse_mode", "sdk"))
            bx.pack_start(row(tr("set_mouse"), mouse, "help_mouse"), False, False, 0)

            toggles = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
            aud = Gtk.Switch(); aud.set_active(bool(self.config.get("audio", True)))
            t1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t1.pack_start(Gtk.Label(label=tr("set_audio")), False, False, 0); t1.pack_start(aud, False, False, 0)
            stay = Gtk.Switch(); stay.set_active(bool(self.config.get("stay_awake", False)))
            t2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t2.pack_start(Gtk.Label(label=tr("stay_awake")), False, False, 0); t2.pack_start(stay, False, False, 0)
            off = Gtk.Switch(); off.set_active(bool(self.config.get("turn_screen_off", False)))
            t3 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t3.pack_start(Gtk.Label(label=tr("turn_screen_off_label")), False, False, 0); t3.pack_start(off, False, False, 0)
            for t in (t1, t2, t3):
                toggles.pack_start(t, True, True, 0)
            bx.pack_start(toggles, False, False, 0)
            am = Gtk.Switch(); am.set_active(bool(self.config.get("auto_mirror", True)))
            t4 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t4.pack_start(Gtk.Label(label=tr("auto_mirror_switch")), False, False, 0)
            t4.pack_start(am, False, False, 0)
            t4.set_tooltip_text(tr("auto_mirror_help"))
            toggles.pack_start(t4, True, True, 0)

            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup('<span color="#888888" size="small">%s</span>' % tr("set_note"))
            bx.pack_start(note, False, False, 0)
            ap = Gtk.Button(label=tr("set_apply"))
            ap.get_style_context().add_class("suggested-action")

            def apply(_b):
                self.config.update(preset=preset.get_active_id() or "balanced",
                                   max_size=size.get_active_id() or "1024",
                                   fps=fps.get_active_id() or "60",
                                   bitrate=bit.get_active_id() or "16M",
                                   gamepad=gp.get_active_id() or "uhid",
                                   mouse_mode=mouse.get_active_id() or "sdk",
                                   audio=aud.get_active(), stay_awake=stay.get_active(),
                                   turn_screen_off=off.get_active(),
                                   auto_mirror=am.get_active())
                save_config(self.config)
                pop.popdown()
                self.toast(tr("set_saved"))

            ap.connect("clicked", apply)
            bx.pack_start(ap, False, False, 0)
            pop.add(bx)
            pop.show_all()

        # ---------- Tips / Doctor / Help ----------
        def show_tips(self):
            tips = [tr("tip_adv_%d" % i) for i in range(1, 9)]
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("tips_title"))
            d.format_secondary_text(tr("tips_intro") + "\n\n" + "\n".join("\u2022 " + t for t in tips))
            d.run(); d.destroy()

        def run_doctor(self):
            lines = ["PadLink doctor (%s)" % APP_VERSION, "=" * 42]
            try:
                import gi as _g
                lines.append("%-18s OK   python3-gi" % "pygobject")
            except Exception:
                lines.append("%-18s FAIL python3-gi" % "pygobject")
            try:
                import cairo as _c
                lines.append("%-18s OK   python3-cairo" % "pycairo")
            except Exception:
                lines.append("%-18s FAIL python3-cairo" % "pycairo")
            try:
                import evdev as _e
                lines.append("%-18s OK   python3-evdev" % "evdev")
            except Exception:
                lines.append("%-18s FAIL python3-evdev" % "evdev")
            adb = find_adb()
            lines.append("%-18s %s %s" % ("adb", "OK " if adb else "FAIL", adb or "missing"))
            sp = find_scrcpy()
            lines.append("%-18s %s %s" % ("scrcpy", "OK " if sp else "FAIL", sp or "missing"))
            ctrl = len(detect_controllers())
            lines.append("%-18s %s %d controller(s)" % ("gamepad", "OK " if ctrl else "FAIL", ctrl))
            report = "\n".join(lines)
            try:
                os.makedirs(CONFIG_DIR, exist_ok=True)
                open(os.path.join(CONFIG_DIR, "doctor.log"), "w", encoding="utf-8").write(report + "\n")
            except Exception:
                pass
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("doctor_title"))
            d.format_secondary_markup("<tt>%s</tt>" % GLib.markup_escape_text(report))
            d.run(); d.destroy()

        def run_diag(self):
            if getattr(self, "_diag_running", False):
                return
            self._diag_running = True
            self.toast(tr("diag_running"))
            threading.Thread(target=self._diag_worker, daemon=True).start()

        def _diag_worker(self):
            report = ""
            try:
                report = diag_controllers()
                try:
                    os.makedirs(CONFIG_DIR, exist_ok=True)
                    open(os.path.join(CONFIG_DIR, "diag.log"), "w", encoding="utf-8").write(report + "\n")
                except Exception:
                    pass
            except Exception as e:
                report = "diag error: %s" % e
            GLib.idle_add(self._diag_show, report)

        def _diag_show(self, report):
            self._diag_running = False
            self.toast(tr("diag_done"))
            d = Gtk.Dialog(title=tr("diag_title"), transient_for=self, modal=True,
                           destroy_with_parent=True)
            d.set_default_size(760, 560)
            bx = d.get_content_area()
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            lb = Gtk.Label(xalign=0.0, valign=Gtk.Align.START, selectable=True, wrap=False)
            lb.set_markup("<tt>%s</tt>" % GLib.markup_escape_text(report))
            sw.add(lb)
            bx.pack_start(sw, True, True, 0)
            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup('<span color="#888888" size="small">%s</span>' % tr("diag_note"))
            bx.pack_start(note, False, False, 0)
            d.add_button(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
            d.show_all()
            d.run(); d.destroy()

        def show_about(self):
            sp = find_scrcpy()
            spv = ""
            if sp:
                rc, out, _ = run_cmd([sp, "--version"], 6)
                for line in out.splitlines():
                    if line.startswith("scrcpy "):
                        spv = line.split()[1]
                        break
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("about_title"))
            d.format_secondary_markup(
                "<b>PadLink %s</b>\n%s\n\n"
                "scrcpy: %s\nadb: %s\n\n"
                "<span color=\"#888888\" size=\"small\">%s</span>"
                % (APP_VERSION, tr("about_body"),
                   spv or tr("about_unknown"), os.path.basename(find_adb() or "adb"),
                   tr("about_footer")))
            d.run(); d.destroy()

        def show_help(self):
            items = [
                ("grp_mirror", [("btn_start2", "help_start"), ("btn_stop", "help_stop")]),
                ("grp_view", [("btn_fullscreen", "help_fullscreen"), ("btn_zoom_in", "help_zoom_in"),
                              ("btn_zoom_out", "help_zoom_out"), ("btn_fit", "help_fit"),
                              ("btn_rotate", "help_rotate"), ("btn_screenshot", "help_shot"),
                              ("btn_record", "help_record")]),
                ("grp_nav", [("btn_scroll_up", "help_scroll_up"), ("btn_scroll_down", "help_scroll_down"),
                             ("btn_focus", "help_focus"), ("btn_home", "help_home"),
                             ("btn_back", "help_back"), ("btn_recents", "help_recents"),
                             ("btn_vol_up", "help_vol_up"), ("btn_vol_down", "help_vol_down"),
                             ("btn_power", "help_power")]),
                ("grp_overlay", [("btn_smart_color", "help_smart_color")]),
                ("grp_ctrl", [("fwd_switch", "help_forward"), ("vib_switch", "help_vib_enable"),
                              ("ctrl_deadzone", "help_deadzone"), ("ctrl_recenter", "help_recenter"),
                              ("ctrl_reset_cal", "help_reset_cal")]),
                ("grp_util", [("btn_doctor", "help_doctor"), ("btn_settings", "help_settings"),
                              ("btn_tips", "help_tips")]),
            ]
            d = Gtk.Dialog(title=tr("help_title"), transient_for=self, modal=True,
                           destroy_with_parent=True)
            d.set_default_size(700, 560)
            tv = Gtk.TextView(); tv.set_editable(False); tv.set_cursor_visible(False)
            tv.set_wrap_mode(Gtk.WrapMode.WORD)
            sw = Gtk.ScrolledWindow(); sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            sw.add(tv)
            d.get_content_area().pack_start(sw, True, True, 0)
            d.add_button(tr("help_close"), Gtk.ResponseType.CLOSE)
            d.show_all()
            buf = tv.get_buffer()
            buf.insert(buf.get_end_iter(), tr("help_intro") + "\n\n")
            for gid, gname in items:
                buf.insert(buf.get_end_iter(), "=== " + tr(gid) + " ===\n")
                for key, hk in gname:
                    desc = tr(hk, "")
                    if desc:
                        buf.insert(buf.get_end_iter(), "\u2022 %s\n    %s\n" % (tr(key, key), desc))
                buf.insert(buf.get_end_iter(), "\n")
            d.run(); d.destroy()


        # ---------- AUTO-UPDATE (GitHub = the update server) ----------
        # 8s after start: fetch update.json in the background. A newer
        # version offers ONE-TAP update: download from the server ->
        # install (pkexec asks the password in a dialog) -> restart.
        def _upd_check_later(self):
            threading.Thread(target=self._upd_fetch, daemon=True).start()
            return False

        def _upd_manual(self):
            if getattr(self, "_upd_busy", False):
                return
            self._upd_busy = True
            self.toast(tr("up_checking"))
            threading.Thread(target=self._upd_fetch, args=(True,),
                             daemon=True).start()

        def _upd_fetch(self, manual=False):
            import base64, urllib.request
            try:
                req = urllib.request.Request(UPDATE_API,
                                             headers=UPDATE_HEADERS)
                with urllib.request.urlopen(req, timeout=20) as r:
                    data = json.loads(r.read().decode())
                info = json.loads(base64.b64decode(data["content"]).decode())
            except Exception as e:
                log("update check failed: %s" % e)
                if manual:
                    GLib.idle_add(self._upd_check_done, False, True)
                return
            GLib.idle_add(self._upd_result, info)
            if manual:
                GLib.idle_add(self._upd_check_done, True, False)

        def _upd_check_done(self, ok, net_err):
            self._upd_busy = False
            if net_err:
                self.toast(tr("up_check_fail"))
            elif ok and getattr(self, "_upd_pending", None) is None:
                self.toast(tr("up_up_to_date") % APP_VERSION)

        def _upd_result(self, info):
            if not self._alive:
                return
            try:
                new_v = str(info.get("version", "0"))
                if not _ver_gt(new_v, APP_VERSION):
                    return
            except Exception:
                return
            self._upd_pending = (new_v, info)
            d = Gtk.MessageDialog(transient_for=self, modal=False,
                                  message_type=Gtk.MessageType.INFO,
                                  text=tr("up_found") % new_v)
            d.format_secondary_text(str(info.get("note", "")))
            d.add_button(tr("up_now"), 1)
            d.add_button(tr("up_later"), Gtk.ResponseType.CLOSE)

            def on_resp(_d, r):
                d.destroy()
                if r == 1 and getattr(self, "_upd_pending", None):
                    self._upd_start(self._upd_pending[1].get("deb", ""),
                                    self._upd_pending[0])
                return False
            d.connect("response", on_resp)
            d.show_all()

        def _upd_start(self, deb, ver):
            if not deb:
                return
            self.toast(tr("up_downloading"))

            def work():
                import urllib.request
                dest = os.path.expanduser("~/padlink_update.deb")
                url = UPDATE_BASE + deb + "?" + UPDATE_REF
                try:
                    req = urllib.request.Request(url,
                                                 headers=UPDATE_HEADERS)
                    with urllib.request.urlopen(req, timeout=300) as r, \
                            open(dest, "wb") as f:
                        while True:
                            chunk = r.read(1 << 16)
                            if not chunk:
                                break
                            f.write(chunk)
                except Exception as e:
                    log("update download failed: %s" % e)
                    GLib.idle_add(self._upd_fail,
                                  tr("up_dl_fail") + ": " + str(e))
                    return
                self._upd_install(dest, ver)
            threading.Thread(target=work, daemon=True).start()

        def _upd_install(self, dest, ver):
            self.toast(tr("up_installing"))

            def work():
                rc, out = -1, ""
                try:
                    if os.geteuid() == 0:
                        p = subprocess.run(["apt-get", "install", "-y", dest],
                                           capture_output=True, text=True,
                                           timeout=600)
                    else:
                        p = subprocess.run(["pkexec", "apt-get", "install",
                                            "-y", dest],
                                           capture_output=True, text=True,
                                           timeout=600)
                    rc = p.returncode
                    out = (p.stderr or p.stdout or "")[-400:]
                except Exception as e:
                    out = str(e)
                GLib.idle_add(self._upd_installed, rc == 0, out, ver)
            threading.Thread(target=work, daemon=True).start()

        def _upd_installed(self, ok, out, ver):
            if ok:
                d = Gtk.MessageDialog(transient_for=self, modal=False,
                                      message_type=Gtk.MessageType.INFO,
                                      text=tr("up_done"))
                d.add_button(tr("up_restart"), 1)
                d.add_button(tr("up_later"), Gtk.ResponseType.CLOSE)

                def do_restart():
                    try:
                        os.execv(sys.executable,
                                 [sys.executable] + list(sys.argv))
                    except Exception:
                        pass

                def on_resp(_d, r):
                    d.destroy()
                    if r == 1:
                        GLib.timeout_add(500, do_restart)
                    return False
                d.connect("response", on_resp)
                d.show_all()
            else:
                self._upd_fail(tr("up_fail") + ": " + out)

        def _upd_fail(self, msg):
            d = Gtk.MessageDialog(transient_for=self, modal=False,
                                  message_type=Gtk.MessageType.ERROR,
                                  text=tr("up_fail"))
            d.format_secondary_text(str(msg) + "\n\n" + tr("up_manual") +
                                    "\nsudo apt install ~/padlink_update.deb")
            d.run(); d.destroy()

        # ---------- Lifecycle ----------
        def on_destroy(self, _w):
            self._alive = False
            self.overlay_stop()
            self.stop_mirror()
            self._fc_stop()
            if self.reader:
                self.reader.stop()
            for t in self.timers:
                GLib.source_remove(t)


def xdotool():
    return shutil.which("xdotool") is not None


def diag_controllers():
    """DEEP DIAGNOSTIC: tells exactly why a controller is (not) working."""
    out = []
    def line(t):
        out.append(t)
    line("=" * 58)
    line("PadLink deep diagnostic %s" % APP_VERSION)
    line("=" * 58)
    line("[1] SYSTEM")
    line("    kernel: %s" % (run_cmd(["uname", "-r"])[1] or "?"))
    line("    user:   %s" % (run_cmd(["id", "-un"])[1] or "?"))
    line("    groups: %s" % (run_cmd(["id", "-nG"])[1] or "?"))

    line("")
    line("[2] USB DEVICES (looking for Xbox 360: vendor 045e)")
    rc, us, _ = run_cmd(["lsusb"], 8)
    xbox_usb = []
    if rc == 0:
        for l in us.splitlines():
            l2 = l.lower()
            if "045e" in l2 or "xbox" in l2 or "gamepad" in l2 or "controller" in l2:
                xbox_usb.append(l)
                line("    FOUND: " + l)
        if not xbox_usb:
            line("    No Xbox/gamepad USB device found.")
            line("    >>> If the pad is plugged and not here: cable/port/driver.")
    else:
        line("    lsusb unavailable")

    line("")
    line("[3] KERNEL DRIVER (xpad)")
    rc, ls, _ = run_cmd(["sh", "-c", "lsmod 2>/dev/null | grep -E 'xpad|joydev|uinput'"], 5)
    if rc == 0 and ls:
        line("    loaded:")
        for l in ls.splitlines():
            line("      " + l)
    else:
        line("    xpad / joydev / uinput NOT loaded.")
        line("    >>> run: sudo modprobe xpad && sudo modprobe joydev && sudo modprobe uinput")

    line("")
    line("[4] INPUT DEVICES (evdev)")
    try:
        import evdev as _ev
        devs = _ev.list_devices()
        if not devs:
            line("    NO event devices at all.")
        for d in devs:
            try:
                dev = _ev.InputDevice(d)
                caps = dev.capabilities(verbose=False)
                raw_abs = caps.get(_ev.ecodes.EV_ABS, [])
                abs_keys = [i[0] if isinstance(i, tuple) else i for i in raw_abs]
                key_keys = caps.get(_ev.ecodes.EV_KEY, [])
                has_axis = any(k in (_ev.ecodes.ABS_X, _ev.ecodes.ABS_Y,
                                     _ev.ecodes.ABS_RX, _ev.ecodes.ABS_RZ,
                                     _ev.ecodes.ABS_Z) for k in abs_keys)
                has_btn = any(k in (_ev.ecodes.BTN_A, _ev.ecodes.BTN_SOUTH,
                                    _ev.ecodes.BTN_JOYSTICK, _ev.ecodes.BTN_GAMEPAD,
                                    _ev.ecodes.BTN_TL, _ev.ecodes.BTN_TR) for k in key_keys)
                tag = "GAMEPAD" if (has_axis and has_btn) else "other"
                try:
                    perm = oct(os.stat(d).st_mode & 0o777)
                except Exception:
                    perm = "?"
                line("    %-16s %-8s %s  (axes=%d btns=%d) [%s]" % (
                    d, tag, (dev.name or "?")[:36], len(abs_keys), len(key_keys), perm))
                dev.close()
            except PermissionError:
                line("    %-16s NO-PERM (need: sudo chmod 666 %s  or input group)" % (d, d))
            except Exception as e:
                line("    %-16s err: %s" % (d, e))
    except Exception as e:
        line("    evdev error: %s" % e)

    line("")
    line("[5] JOYSTICK NODES (js*)")
    js = sorted(glob.glob("/dev/input/js*"))
    if js:
        for j in js:
            try:
                line("    %s  %s" % (j, oct(os.stat(j).st_mode & 0o777)))
            except Exception:
                line("    %s" % j)
    else:
        line("    none")

    line("")
    line("[6] PERMISSIONS / GROUPS")
    rc, grp, _ = run_cmd(["sh", "-c", "id -nG | tr ' ' '\n' | grep -qx input"], 4)
    line("    user in 'input' group: %s" % ("YES" if rc == 0 else "NO"))
    if rc != 0:
        line("    >>> run: sudo usermod -aG input $USER  (then log out/in)")
    line("    /dev/uinput: %s" % (os.path.exists("/dev/uinput") and "present" or "MISSING (sudo modprobe uinput)"))

    line("")
    line("[7] udev RULES")
    dst = "/etc/udev/rules.d/51-padlink-android.rules"
    if os.path.isfile(dst):
        line("    installed: yes")
        try:
            content = open(dst, encoding="utf-8", errors="replace").read()
            if "|" in content.split("#")[-1]:
                line("    *** INVALID rule (contains | in a match) - reinstall the package ***")
            else:
                line("    content OK")
        except Exception:
            line("    content unreadable")
    else:
        line("    installed: NO  (reinstall the package)")

    line("")
    line("[8] KERNEL LOG (xpad / usb errors)")
    rc, dm, _ = run_cmd(["sh", "-c", "dmesg 2>/dev/null | grep -iE 'xpad|xbox|usb.*error|controller' | tail -8"], 6)
    if rc == 0 and dm:
        for l in dm.splitlines():
            line("    " + l)
    else:
        line("    (need sudo or nothing relevant)")

    line("")
    line("[9] WHAT TO DO")
    has_any = False
    for l in out:
        if "GAMEPAD" in l and "/dev/input" in l:
            has_any = True
    if has_any:
        line("    A gamepad IS visible. If it still does not respond:")
        line("    1) press the 'smart auto-fix' button in the app")
        line("    2) or run: sudo modprobe -r xpad && sudo modprobe xpad")
        line("    3) unplug/replug the pad")
    elif xbox_usb:
        line("    USB shows the pad but no input device -> driver problem.")
        line("    >>> sudo modprobe -r xpad; sudo modprobe xpad")
        line("    >>> then unplug/replug the pad")
    else:
        line("    The pad is NOT seen at USB level.")
        line("    >>> check: cable, USB port, receiver pairing,")
        line("    >>> try another port, another pad if possible.")
    line("=" * 58)
    return "\n".join(out)


def main():
    if "--version" in sys.argv:
        print("padlink %s" % APP_VERSION)
        return 0
    if "--diag" in sys.argv:
        print(diag_controllers())
        return 0
    if "--doctor" in sys.argv:
        try:
            import evdev
        except Exception:
            evdev = None
        print("PadLink doctor %s" % APP_VERSION)
        print("pygobject OK")
        print("pycairo OK")
        print("evdev %s" % ("OK" if evdev else "MISSING"))
        print("adb:", find_adb())
        print("scrcpy:", find_scrcpy())
        print("controllers:", len(detect_controllers()))
        return 0
    if not GTK_OK:
        print("GTK unavailable: %s" % _ERR)
        return 1
    log("start %s" % APP_VERSION)
    try:
        w = PadLinkWindow()
        w.show_all()
        if "--smoke" in sys.argv:
            GLib.timeout_add(2500, Gtk.main_quit)
        Gtk.main()
        log("clean exit")
    except Exception as e:
        log("fatal: %s" % e)
        traceback.print_exc()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
