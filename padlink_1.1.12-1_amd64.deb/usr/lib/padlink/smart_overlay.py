#!/usr/bin/env python3
# ============================================================================
# PadLink SmartOverlay v3.1 - ADVANCED AUTO COLOR GRADING ENGINE (fixed).
#
# One toggle in the UI. When ON, a modern grading pipeline runs
# automatically over the mirror window (pro video/photo color tools style):
#
#   1. WHITE BALANCE    corrects the scene color cast (per-frame)
#   2. EXPOSURE         gentle auto luma target
#   3. TONAL CURVES     shadow lift / midtone S-depth / highlight rolloff
#   4. SPLIT TONING     cool shadows + warm highlights (film look)
#   5. VIBRANCE         selective saturation - dull pixels only
#   6. CLARITY          multi-scale unsharp detail at 1/3 resolution
#                       (high quality - no blocky upscaling artifacts)
#   7. VIGNETTE         subtle cinematic edge falloff
#
# v3.1 FIXES (the "everything turned white" bug):
#   * TRANSPARENCY SELF-TEST: before showing anything, the engine verifies
#     (a) an RGBA visual is available, (b) a compositor is active
#     (xprop _NET_WM_CM / xfwm4/kwin/mutter), (c) after the first
#     transparent frame it GRABS its own window and checks the alpha
#     channel. If the window would be opaque -> it is destroyed silently
#     and the UI is notified (no white screen ever again).
#   * FILMIC ALPHA CAPS: every layer's alpha is capped to a professional
#     range (no layer may exceed ~30-40% on its own), so bright/saturated
#     scenes are graded, not blown out.
#   * DETAIL MASK AT 1/3 RESOLUTION: the clarity mask is computed on a
#     bigger sample and upscaled only 3x (bilinear) -> smooth, no
#     "distortion" pattern.
#
# Ultra-light + invisible: 15Hz adaptive scene analysis (drops to ~8Hz on
# static scenes), GPU-composited alpha masks, zero added latency,
# click-through, no chip, no border.
#
# Pure ASCII source. GTK3 + cairo + numpy (scipy optional).
# ============================================================================
import math
import os
import shutil
import time

try:
    import numpy as np
    _NP = True
except Exception:
    _NP = False

try:
    from scipy import ndimage as _sci
    _SCI = True
except Exception:
    _SCI = False

Gdk = GdkPixbuf = GdkX11 = None
try:
    import gi
    gi.require_version("Gdk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    try:
        gi.require_foreign("cairo")
    except Exception:
        pass
    from gi.repository import Gdk, GdkPixbuf
    try:
        gi.require_version("GdkX11", "3.0")
        from gi.repository import GdkX11
    except Exception:
        GdkX11 = None
except Exception:
    pass

XID_PATTERN = "padlink_window"

GEO_PERIOD = 0.20     # seconds between mirror-geometry checks (xdotool)
AN_FAST = 0.066       # 15Hz scene analysis while the scene is changing
AN_IDLE = 0.13        # ~8Hz when the scene is static (adaptive, saves CPU)
_IDLE_DELTA = 0.008   # stats delta below this counts as "static"
_IDLE_FRAMES = 5      # consecutive static analyses before slowing down

STATS_DIV = 6         # sample divisor for scene statistics
DETAIL_DIV = 3        # sample divisor for the clarity mask (higher quality)


def _run(cmd, timeout=5):
    import subprocess
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception:
        return -1, "", ""


def find_mirror_xid():
    """Locate the scrcpy mirror window XID (X11 only)."""
    if not os.environ.get("DISPLAY"):
        return None
    rc, out, _ = _run(["xdotool", "search", "--name", XID_PATTERN], 4)
    if rc == 0:
        ids = [l for l in out.splitlines() if l.strip().isdigit()]
        if ids:
            return int(ids[0])
    return None


def find_mirror_geometry(xid):
    rc, out, _ = _run(["xdotool", "getwindowgeometry", "--shell", str(xid)], 4)
    geo = {}
    if rc == 0:
        for line in out.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                try:
                    geo[k.strip()] = int(v.strip())
                except Exception:
                    pass
    return geo  # X, Y, WIDTH, HEIGHT


def _grab_pixbuf(xid, w, h):
    """X11 grab of the mirror window (one expensive step)."""
    if Gdk is None or GdkX11 is None:
        return None
    try:
        disp = Gdk.Display.get_default()
        gdkwin = GdkX11.X11Window.foreign_new_for_display(disp, xid)
        if gdkwin is None:
            return None
        return Gdk.pixbuf_get_from_window(gdkwin, 0, 0, w, h)
    except Exception:
        return None


def _pixbuf_to_array(pb, tw, th):
    if not _NP or pb is None:
        return None
    try:
        small = pb.scale_simple(tw, th, GdkPixbuf.InterpType.BILINEAR)
        arr = np.frombuffer(small.get_pixels(), dtype=np.uint8)
        arr = arr.reshape(th, tw, small.get_n_channels())
        return arr[:, :, :3].astype(np.float32) / 255.0
    except Exception:
        return None


def grab_window(xid, w, h, div=DETAIL_DIV):
    """Sample the mirror window content -> numpy RGB (small). None on fail."""
    pb = _grab_pixbuf(xid, w, h)
    if pb is None:
        return None
    tw = max(64, w // div)
    th = max(40, h // div)
    return _pixbuf_to_array(pb, tw, th)


# ---------- image math (numpy core, scipy optional) ----------

def _box_blur(a, r):
    """O(1) box blur via the integral image (fast fallback)."""
    if not _NP or r <= 0:
        return a
    k = 2 * r + 1
    p = np.pad(a, r, mode="edge").astype(np.float32)
    h, w = a.shape
    S = np.zeros((h + 2 * r + 1, w + 2 * r + 1), dtype=np.float32)
    S[1:, 1:] = p
    S = np.cumsum(np.cumsum(S, axis=0), axis=1)
    return (S[k:k + h, k:k + w] - S[:h, k:k + w] -
            S[k:k + h, :w] + S[:h, :w]) / (k * k)


def _smooth(a, sigma):
    """Gaussian blur (scipy) or integral-image box approximation."""
    if not _NP or sigma <= 0:
        return a
    if _SCI:
        return _sci.gaussian_filter(a, sigma)
    return _box_blur(a, int(round(sigma)))


def _norm3(c):
    return (max(0.0, min(1.0, float(c[0]))),
            max(0.0, min(1.0, float(c[1]))),
            max(0.0, min(1.0, float(c[2]))))


def _scene_name(mean, std, sat):
    if mean < 0.28:
        return "dark"
    if mean > 0.62:
        return "bright"
    if std < 0.16:
        return "washout"
    if sat < 0.14:
        return "dull"
    return "normal"


def analyze_frame(rgb):
    """Per-frame scene statistics (normalized RGB 0..1)."""
    if not _NP or rgb is None:
        return None
    r = rgb[:, :, 0]; g = rgb[:, :, 1]; b = rgb[:, :, 2]
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    mean = float(luma.mean())
    std = float(luma.std())
    sat = float((np.maximum(np.maximum(r, g), b) -
                 np.minimum(np.minimum(r, g), b)).mean())
    avg = rgb.mean(axis=(0, 1))
    out = {
        "mean_luma": mean, "contrast": std, "saturation": sat,
        "scene": _scene_name(mean, std, sat),
        "avg": (float(avg[0]), float(avg[1]), float(avg[2])),
        "cast": (float(0.5 - avg[0]), float(0.5 - avg[1]), float(0.5 - avg[2])),
    }
    mn, mx = min(out["avg"]), max(out["avg"])
    if mx - mn < 0.03:
        out["vib_color"] = (0.45, 0.55, 1.00)
    else:
        out["vib_color"] = _norm3([v * 1.7 for v in out["avg"]])
    return out


def _auto_targets(st, user):
    """Scene-adaptive grading targets - FILMIC ranges (gentle by design:
    no single layer may blow the image out)."""
    mean, std, sat = st["mean_luma"], st["contrast"], st["saturation"]
    dark = mean < 0.30
    bright = mean > 0.60
    wash = std < 0.18
    t = {}

    # 1) exposure: gentle nudge toward a comfortable luma
    if mean < 0.42:
        exp = min(0.10, (0.46 - mean) * 0.30)
    elif mean > 0.58:
        exp = -min(0.09, (mean - 0.58) * 0.25)
    else:
        exp = 0.0
    t["exp"] = max(-0.12, min(0.12, exp + user["exposure"] * 0.25))

    # 2) white balance from the scene cast + user temperature
    wb = tuple(max(-0.30, min(0.30, st["cast"][i] * 0.9)) for i in range(3))
    temp = user["temperature"]
    wb = (wb[0] + temp * 0.30, wb[1], wb[2] - temp * 0.30)
    t["wb"] = _norm3([0.5 + c for c in wb])
    t["wb_a"] = min(0.14, sum(abs(c) for c in wb) * 0.40)

    # 3) tonal curves (capped, filmic)
    t["sh_lift"] = 0.08 + (0.14 if dark else 0.0) + (0.06 if wash else 0.0)
    t["mid_depth"] = (0.10 + 0.22 * max(0.0, min(1.0, (0.30 - std) / 0.30))
                      + user["contrast"] * 0.4)
    t["hi_roll"] = 0.08 + (0.12 if bright else 0.0) + (0.05 if wash else 0.0)

    # 4) split toning (film look)
    base = 0.30 + (0.18 if (dark or bright) else 0.0)
    t["sh_split"] = base
    t["hi_split"] = base * 0.75
    uc = user["tint"]
    t["sh_tint"] = _norm3([0.38 + uc[0] * 0.20 - wb[0] * 0.25,
                           0.46 + uc[1] * 0.20,
                           0.92 + uc[2] * 0.20 - wb[2] * 0.25])
    t["hi_tint"] = _norm3([1.00, 0.87 + uc[1] * 0.10, 0.70 + uc[2] * 0.15])

    # 5) vibrance (dull scenes get the most, capped)
    t["vib"] = (0.25 + (0.45 if sat < 0.18 else 0.22 if sat < 0.28 else 0.0)
                + user["saturation"] * 0.5)
    t["dom"] = st["vib_color"]

    # 6) clarity
    t["cla"] = (0.28 + (0.40 if std < 0.18 else 0.18 if std < 0.26 else 0.0)
                + (0.10 if dark else 0.0) + user["clarity"] * 0.5)

    # 7) vignette
    t["vig"] = min(0.10, 0.045 + (0.05 if dark else 0.0) + (0.03 if wash else 0.0))
    return t


def build_grade_masks(rgb, t, master):
    """Per-pixel grade masks from the sampled frame (1/3 resolution).

    Alpha caps per layer keep the look professional (never blown out).
    Returns (w, h, surfaces) where surfaces = dict of RGBA numpy arrays."""
    if not _NP or rgb is None:
        return None
    r = rgb[:, :, 0]; g = rgb[:, :, 1]; b = rgb[:, :, 2]
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    chroma = np.maximum(np.maximum(r, g), b) - np.minimum(np.minimum(r, g), b)
    h, w = luma.shape

    mask_sh = np.clip((0.35 - luma) / 0.35, 0, 1)          # shadows
    mask_hi = np.clip((luma - 0.72) / 0.28, 0, 1)          # highlights
    mask_mid = np.clip(1.0 - np.abs(luma - 0.5) * 2.0, 0, 1) ** 1.6
    dull = np.clip((0.28 - chroma) / 0.28, 0, 1)           # low-chroma pixels

    def rgba(rgb3, alpha, cap=1.0):
        a = np.clip(alpha, 0, cap) * 255
        arr = np.zeros((h, w, 4), dtype=np.uint8)
        arr[:, :, 0] = int(max(0, min(255, rgb3[0] * 255)))
        arr[:, :, 1] = int(max(0, min(255, rgb3[1] * 255)))
        arr[:, :, 2] = int(max(0, min(255, rgb3[2] * 255)))
        arr[:, :, 3] = a.astype(np.uint8)
        return arr

    out = {}
    out["sh_w"] = rgba((1, 1, 1), mask_sh * t["sh_lift"] * master, 0.30)
    out["mid_b"] = rgba((0, 0, 0), mask_mid * t["mid_depth"] * master, 0.30)
    out["hi_b"] = rgba((0, 0, 0), mask_hi * t["hi_roll"] * master, 0.28)
    out["sh_c"] = rgba(t["sh_tint"], mask_sh * t["sh_split"] * master * 0.42, 0.22)
    out["hi_c"] = rgba(t["hi_tint"], mask_hi * t["hi_split"] * master * 0.38, 0.18)
    out["vib"] = rgba(t["dom"], dull * t["vib"] * master * 0.40, 0.30)

    # clarity: multi-scale unsharp, auto-normalized (p98 cap 0.40)
    if t["cla"] > 0.02:
        b1 = _smooth(luma, 0.8)
        b2 = _smooth(luma, 2.2)
        d = (luma - b1 + 0.55 * (b1 - b2)) * (t["cla"] * 2.6)
        p = float(np.percentile(np.abs(d), 98))
        if p > 1e-4:
            d = d * min(1.0, 0.40 / p)
        out["det_w"] = rgba((1, 1, 1), np.clip(d, 0, 1) * 0.60 * master, 0.30)
        out["det_b"] = rgba((0, 0, 0), np.clip(-d, 0, 1) * 0.50 * master, 0.26)
    else:
        out["det_w"] = out["det_b"] = None
    return (w, h, out)


def _compose_opaque(rgb, s, surf):
    """Opaque fallback: grade a FULL frame = original + exactly the same
    layers the transparent window paints (flat fills + per-pixel masks +
    vignette). Same professional caps -> identical look without alpha."""
    h, w = rgb.shape[:2]
    out = rgb.astype(np.float32) * 255.0
    e = s.get("exp", 0.0)
    if e > 0.002:
        a = min(0.12, e)
        out = out * (1 - a) + 255.0 * a
    elif e < -0.002:
        a = min(0.11, -e)
        out = out * (1 - a)
    wa = s.get("wb_a", 0.0)
    if wa > 0.002:
        wb = np.array([s["wb"][0] * 255.0, s["wb"][1] * 255.0,
                       s["wb"][2] * 255.0], dtype=np.float32)
        out = out * (1 - wa) + wb[None, None, :] * wa
    for k in ("sh_w", "mid_b", "hi_b", "sh_c", "hi_c", "vib",
              "det_w", "det_b"):
        v = surf.get(k) if isinstance(surf, dict) else None
        if v is None:
            continue
        a = v[:, :, 3:4].astype(np.float32) / 255.0
        col = v[:, :, :3].astype(np.float32)
        out = out * (1 - a) + col * a
    vg = s.get("vig", 0.0)
    if vg > 0.004:
        yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
        d = np.hypot(xx - (w - 1) / 2.0, yy - (h - 1) / 2.0)
        dmax = math.hypot(w, h) / 2.0
        dmin = min(w, h) * 0.35
        fall = np.clip((d - dmin) / max(1e-3, dmax - dmin), 0, 1)
        out = out * (1.0 - min(0.10, vg) * fall)[:, :, None]
    return np.clip(out, 0, 255).astype(np.uint8)


def _surface_from_rgba(arr):
    import cairo
    h, w = arr.shape[:2]
    srf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    srf.flush()
    data = srf.get_data()
    # cairo ARGB32 memory is native-endian (little-endian -> BGRA on disk)
    buf = np.frombuffer(data, dtype=np.uint8).reshape(h, w, 4)
    buf[:, :, 0] = arr[:, :, 2]  # B
    buf[:, :, 1] = arr[:, :, 1]  # G
    buf[:, :, 2] = arr[:, :, 0]  # R
    buf[:, :, 3] = arr[:, :, 3]  # A
    srf.mark_dirty()
    return srf


def _compositor_active():
    """A transparent overlay needs a compositor. Check the usual signals.
    NOTE: xfwm4 (XFCE/MX default) is deliberately NOT trusted by name -
    it runs with compositing disabled all the time; real compositing is
    proven by the _NET_WM_CM root property (or kwin/mutter, which always
    composite)."""
    if os.environ.get("WAYLAND_DISPLAY"):
        return True
    if not os.environ.get("DISPLAY"):
        return False
    try:
        rc, out, _ = _run(["xprop", "-root"], 3)
        if rc == 0 and "_NET_WM_CM" in out:
            return True
    except Exception:
        pass
    try:
        rc2, ps, _ = _run(["sh", "-c",
                           "pgrep -x kwin_x11 2>/dev/null | head -1 || "
                           "pgrep -x mutter 2>/dev/null | head -1"], 3)
        if rc2 == 0 and ps.strip():
            return True
    except Exception:
        pass
    return False


class SmartOverlay(object):
    """Invisible, click-through grading layer aligned to the mirror window.

    Drive it with tick() from a fast main-loop timer (~15Hz); it self-
    throttles and slows down adaptively on static scenes. Before showing
    anything it self-tests transparency (no white screen possible)."""

    def __init__(self, title="PadLink Smart Layer"):
        self.title = title
        self.win = None
        self.xid = None
        self.geo = (0, 0, 100, 100)
        self.enabled = False
        self.auto = True
        self.broken = False
        self.tint = (0.30, 0.55, 1.00)      # user color (0..1)
        self.opacity = 0.25                  # master engine strength
        self.user_clarity = 0.0
        self.user_exposure = 0.0
        self.user_saturation = 0.0
        self.user_contrast = 0.0
        self.user_temperature = 0.0
        self.last_scene = None
        self._mirror_ok = False
        self._gdkwin = None
        self._broken_cb = None
        # shown (smoothed) vs target values
        self._s = {"exp": 0.0, "wb_a": 0.0, "sh_lift": 0.0, "mid_depth": 0.0,
                   "hi_roll": 0.0, "sh_split": 0.0, "hi_split": 0.0,
                   "vib": 0.0, "cla": 0.0, "vig": 0.0,
                   "wb": (0.5, 0.5, 0.5), "sh_tint": (0.38, 0.46, 0.92),
                   "hi_tint": (1.0, 0.87, 0.70), "dom": (0.45, 0.55, 1.00)}
        self._t = dict(self._s)
        for k in ("wb", "sh_tint", "hi_tint", "dom"):
            self._t[k] = tuple(self._s[k])
        self._surfaces = {}
        self.mask_w = self.mask_h = 0
        self._last_geo = 0.0
        self._last_an = 0.0
        self._last_tick = 0.0
        self._period = AN_FAST
        self._idle_n = 0
        self._last_stats = (0.0, 0.0, 0.0)
        self._tested = False
        self._dirty = True
        # opaque fallback (no compositor): the window redraws a graded
        # copy of the mirror over it - same look, zero alpha needed
        self.opaque = False
        self._opaque_srf = None

    # ---------- transparency self-test ----------
    def _try_enable_compositor(self):
        """XFCE (MX Linux default) often ships with compositing DISABLED,
        which is exactly what makes transparent overlays impossible.
        Enable it automatically - no root needed - then re-check."""
        try:
            rc, ps, _ = _run(["sh", "-c",
                              "pgrep -x xfwm4 2>/dev/null | head -1"], 3)
            if rc != 0 or not ps.strip():
                return False
            xfconf = shutil.which("xfconf-query")
            if xfconf is None:
                return False
            _run([xfconf, "-c", "xfwm4", "-p", "/general/use_compositing",
                  "-s", "true"], 5)
            time.sleep(1.8)
            return True
        except Exception:
            return False

    def _env_ok(self):
        """Pre-map check: RGBA visual + active compositor."""
        if Gdk is None:
            return False
        try:
            screen = self.win.get_screen()
            if screen is None or screen.get_rgba_visual() is None:
                return False
        except Exception:
            return False
        return _compositor_active()

    def _alpha_test(self):
        """Post-map check: grab OUR OWN window and verify the first
        (transparent) frame is actually transparent."""
        self._tested = True
        try:
            gdkw = self.win.get_window()
            pb = Gdk.pixbuf_get_from_window(gdkw, 0, 0, 8, 8)
            nch = pb.get_n_channels()
            if nch < 4:
                self._mark_broken()
                return
            raw = pb.get_pixels()
            arr = np.frombuffer(raw, dtype=np.uint8).reshape(8, 8, nch)
            if int(arr[:, :, 3].min()) > 32:
                self._mark_broken()
                return
        except Exception:
            pass  # cannot verify - trust the environment
        if self.win is not None and not self.broken:
            self.enabled = True
            try:
                self.win.queue_draw()
            except Exception:
                pass

    def _mark_broken(self):
        self.broken = True
        self.enabled = False
        try:
            if self.win is not None:
                self.win.destroy()
        except Exception:
            pass
        self.win = None
        cb = self._broken_cb
        if cb:
            try:
                cb()
            except Exception:
                pass

    # ---------- lifecycle ----------
    def set_broken_cb(self, cb):
        self._broken_cb = cb

    def start(self):
        if self.win is not None:
            return
        if Gdk is None:
            self._mark_broken()
            return
        try:
            import cairo
            import gi
            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk
        except Exception:
            self._mark_broken()
            return
        w = Gtk.Window.new(Gtk.WindowType.POPUP)
        w.set_title(self.title)
        w.set_decorated(False)
        w.set_app_paintable(True)
        w.set_keep_above(True)
        w.set_skip_taskbar_hint(True)
        w.set_skip_pager_hint(True)
        w.set_accept_focus(False)
        w.set_focus_on_map(False)
        screen = w.get_screen()
        visual = screen.get_rgba_visual()
        self.opaque = (visual is None or not self._env_ok())
        if self.opaque:
            # no compositor: run OPAQUE - the window will redraw a graded
            # copy of the mirror over itself (works on any desktop)
            w.set_size_request(10, 10)
            w.move(0, 0)
            w.realize()
        else:
            w.set_visual(visual)
            w.set_size_request(10, 10)
            w.move(0, 0)
            w.show_all()
            w.realize()
        # click-through: empty input shape
        try:
            gdkw = w.get_window()
            if gdkw is not None:
                try:
                    region = cairo.Region()
                    gdkw.input_shape_combine_region(region, 0, 0)
                except Exception:
                    pass
        except Exception:
            pass
        w.connect("draw", self._on_draw)
        self._Gtk = Gtk
        self.win = w
        if self.opaque:
            # hidden until geometry + first graded frame are ready
            self.enabled = False
            self._tested = True
            return
        # environment check BEFORE the first real content; when the
        # compositor is missing (MX/XFCE default) try to enable it
        # automatically, then re-check
        if not self._env_ok():
            self._try_enable_compositor()
        if not self._env_ok():
            self._mark_broken()
            return
        # first frame is a fully transparent test frame (enabled=False)
        self.enabled = False
        self._tested = False
        try:
            self.win.queue_draw()
        except Exception:
            pass

    def stop(self):
        if self.win is not None:
            try:
                self.win.destroy()
            except Exception:
                pass
        self.win = None
        self.enabled = False
        self._opaque_srf = None
        self._mirror_ok = False
        self._surfaces = {}
        self._dirty = True

    # ---------- fast main-loop hook ----------
    def tick(self):
        """Call from a ~66ms timer. Self-throttles: geometry @ ~5Hz,
        scene analysis @ 15Hz (adaptive down to ~8Hz on static scenes),
        smoothing @ 15Hz."""
        if self.win is None:
            return
        # transparency self-test happens once, before any real content
        if not self._tested:
            self._alpha_test()
            if self.win is None or not self.enabled:
                return
        if not self.enabled:
            return
        now = time.time()
        dt = min(0.25, now - self._last_tick) if self._last_tick else 0.066
        self._last_tick = now
        if now - self._last_geo > GEO_PERIOD:
            self._last_geo = now
            if not self._track_geometry():
                return
        if self.xid is not None and now - self._last_an >= self._period:
            self._last_an = now
            self._analyze()
        self._smooth(dt)
        if self._dirty:
            self._dirty = False
            try:
                self.win.queue_draw()
            except Exception:
                pass

    # ---------- tracking ----------
    def _track_geometry(self):
        xid = find_mirror_xid()
        if xid is None:
            if self._mirror_ok:
                try:
                    self.win.hide()
                except Exception:
                    pass
                self._mirror_ok = False
            self.xid = None
            return False
        if xid != self.xid:
            self._gdkwin = None
            self._last_an = 0.0
        self.xid = xid
        geo = find_mirror_geometry(xid)
        if geo and geo.get("WIDTH"):
            gx, gy = geo.get("X", 0), geo.get("Y", 0)
            gw, gh = geo.get("WIDTH", 100), geo.get("HEIGHT", 100)
            if (gx, gy, gw, gh) != self.geo:
                self.geo = (gx, gy, gw, gh)
                try:
                    self.win.move(gx, gy)
                    self.win.resize(gw, gh)
                except Exception:
                    pass
        if not self._mirror_ok:
            if self.opaque and self._opaque_srf is None:
                return True
            try:
                self.win.show_all()
            except Exception:
                pass
            self._mirror_ok = True
            self._dirty = True
        return True

    # ---------- scene engine ----------
    def _analyze(self):
        gw, gh = self.geo[2], self.geo[3]
        pb = _grab_pixbuf(self.xid, gw, gh)
        if pb is None:
            return
        # statistics on the small sample
        tw = max(64, min(160, gw // STATS_DIV))
        th = max(40, min(320, gh // STATS_DIV))
        stats_rgb = _pixbuf_to_array(pb, tw, th)
        st = analyze_frame(stats_rgb) if stats_rgb is not None else None
        if st is None:
            return
        self.last_scene = st
        # adaptive analysis rate (invisible efficiency)
        lm, ls, lsat = self._last_stats
        if (abs(st["mean_luma"] - lm) + abs(st["contrast"] - ls) +
                abs(st["saturation"] - lsat)) < _IDLE_DELTA:
            self._idle_n += 1
        else:
            self._idle_n = 0
        self._period = AN_IDLE if self._idle_n >= _IDLE_FRAMES else AN_FAST
        self._last_stats = (st["mean_luma"], st["contrast"], st["saturation"])

        if not self.auto:
            return
        self._set_targets(st)
        # clarity mask at HIGHER resolution (quality, no blocky upscale)
        dw = max(96, min(320, gw // DETAIL_DIV))
        dh = max(64, min(560, gh // DETAIL_DIV))
        det_rgb = _pixbuf_to_array(pb, dw, dh)
        if det_rgb is not None:
            master = self._master()
            built = build_grade_masks(det_rgb, self._t, master)
            if built:
                w, h, surf = built
                self.mask_w, self.mask_h = w, h
                try:
                    self._surfaces = {
                        k: (_surface_from_rgba(v) if v is not None else None)
                        for k, v in surf.items()}
                except Exception:
                    self._surfaces = {}
                if self.opaque:
                    try:
                        self._opaque_srf = _surface_from_rgba(
                            _compose_opaque(det_rgb, self._s, surf))
                        if self._mirror_ok:
                            try:
                                self.win.show_all()
                                self.win.queue_draw()
                            except Exception:
                                pass
                    except Exception:
                        self._opaque_srf = None
        else:
            self._surfaces = {}
        self._dirty = True

    def _set_targets(self, st):
        self._t.update(_auto_targets(st, self._user_dict()))

    def _user_dict(self):
        return {"tint": self.tint, "exposure": self.user_exposure,
                "clarity": self.user_clarity, "saturation": self.user_saturation,
                "contrast": self.user_contrast,
                "temperature": self.user_temperature}

    def _master(self):
        """Master engine strength from the opacity setting."""
        return 0.25 + 0.75 * max(0.0, min(1.0, self.opacity / 0.25))

    def _smooth(self, dt):
        """Exponential ease shown values toward targets (fast, no flicker)."""
        k1 = 1.0 - math.exp(-dt / 0.12)
        k2 = 1.0 - math.exp(-dt / 0.20)
        s, t = self._s, self._t
        for key in ("exp", "wb_a", "sh_lift", "mid_depth", "hi_roll",
                    "sh_split", "hi_split", "vib", "cla", "vig"):
            d = t[key] - s[key]
            if abs(d) > 0.003:
                s[key] += d * k1
                self._dirty = True
        for key in ("wb", "sh_tint", "hi_tint", "dom"):
            c, g = s[key], t[key]
            d = sum(abs(g[j] - c[j]) for j in range(3))
            if d > 0.008:
                s[key] = tuple(c[j] + (g[j] - c[j]) * k2 for j in range(3))
                self._dirty = True

    # ---------- drawing (invisible: only colors) ----------
    def _on_draw(self, wdg, cr):
        import cairo
        W, H = wdg.get_allocation().width, wdg.get_allocation().height
        if W <= 0 or H <= 0:
            return
        # opaque fallback: paint the full graded frame (no alpha)
        if self.opaque:
            cr.set_operator(cairo.OPERATOR_SOURCE)
            if self._opaque_srf is not None and self.enabled:
                cr.save()
                cr.scale(W / float(self.mask_w or 1),
                         H / float(self.mask_h or 1))
                cr.set_source_surface(self._opaque_srf, 0, 0)
                cr.paint()
                cr.restore()
            else:
                cr.set_source_rgba(0, 0, 0, 1)
                cr.paint()
            return
        # transparent base (also the self-test frame)
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        if not self.enabled:
            return
        cr.set_operator(cairo.OPERATOR_OVER)
        s = self._s
        # 1) exposure
        if s["exp"] > 0.002:
            cr.set_source_rgba(1, 1, 1, min(0.12, s["exp"]))
            cr.paint()
        elif s["exp"] < -0.002:
            cr.set_source_rgba(0, 0, 0, min(0.11, -s["exp"]))
            cr.paint()
        # 2) white balance
        if s["wb_a"] > 0.002:
            cr.set_source_rgba(s["wb"][0], s["wb"][1], s["wb"][2], s["wb_a"])
            cr.paint()
        # 3) per-pixel grade masks (curves + split toning + vibrance + clarity)
        if self.mask_w > 0 and self._surfaces:
            cr.save()
            cr.scale(W / float(self.mask_w), H / float(self.mask_h))
            for k in ("sh_w", "mid_b", "hi_b", "sh_c", "hi_c",
                      "vib", "det_w", "det_b"):
                srf = self._surfaces.get(k)
                if srf is not None:
                    cr.set_source_surface(srf, 0, 0)
                    cr.paint()
            cr.restore()
        # 4) subtle cinematic vignette
        if s["vig"] > 0.004:
            cx, cy = W / 2.0, H / 2.0
            gr = cairo.RadialGradient(cx, cy, min(W, H) * 0.35, cx, cy,
                                      math.hypot(W, H) * 0.5)
            gr.add_color_stop_rgba(0, 0, 0, 0, 0)
            gr.add_color_stop_rgba(1, 0, 0, 0, min(0.10, s["vig"]))
            cr.set_source(gr)
            cr.paint()

    # ---------- public API ----------
    def set_enabled(self, on):
        self.enabled = on
        if self.win is not None:
            try:
                if on:
                    self.win.show_all()
                else:
                    self.win.hide()
            except Exception:
                pass
        self._dirty = True

    def set_params(self, auto=None, opacity=None, tint=None, clarity=None,
                   exposure=None, saturation=None, contrast=None,
                   temperature=None):
        if auto is not None:
            self.auto = bool(auto)
        if opacity is not None:
            self.opacity = max(0.0, min(1.0, float(opacity)))
        if tint is not None:
            self.tint = _norm3([float(c) for c in tint])
        if clarity is not None:
            self.user_clarity = max(0.0, min(1.0, float(clarity)))
        if exposure is not None:
            self.user_exposure = max(-0.5, min(0.5, float(exposure)))
        if saturation is not None:
            self.user_saturation = max(0.0, min(1.0, float(saturation)))
        if contrast is not None:
            self.user_contrast = max(0.0, min(1.0, float(contrast)))
        if temperature is not None:
            self.user_temperature = max(-0.5, min(0.5, float(temperature)))
        self._dirty = True
        if self.win is not None:
            try:
                self.win.queue_draw()
            except Exception:
                pass
