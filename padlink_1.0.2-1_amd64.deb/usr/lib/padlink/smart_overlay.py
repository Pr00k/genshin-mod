#!/usr/bin/env python3
# ============================================================================
# PadLink SmartOverlay - a transparent AI color/clarity layer over the
# standalone mirror window.
#
# Pipeline:
#   mirror window XID -> sample (small) -> numpy stats (AI analysis) ->
#   adaptive exposure + local-contrast clarity mask + adaptive/manual tint ->
#   drawn on an always-on-top, click-through RGBA window aligned to the mirror.
#
# Pure ASCII source. GTK3 + cairo + numpy/scipy (optional, graceful fallback).
# ============================================================================
import math
import os
import threading
import time

try:
    import numpy as np
    _NP = True
except Exception:
    _NP = False

try:
    from scipy import ndimage as _sci
    _SCI = True
except Exception:
    _SCI = False

Gdk = GdkPixbuf = GdkX11 = None
try:
    import gi
    gi.require_version("Gdk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    try:
        gi.require_foreign("cairo")
    except Exception:
        pass
    from gi.repository import Gdk, GdkPixbuf
    try:
        gi.require_version("GdkX11", "3.0")
        from gi.repository import GdkX11
    except Exception:
        GdkX11 = None
except Exception:
    pass

XID_PATTERN = "padlink_window"


def _run(cmd, timeout=5):
    import subprocess
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception:
        return -1, "", ""


def find_mirror_xid():
    """Locate the scrcpy mirror window XID (X11 only)."""
    if not os.environ.get("DISPLAY"):
        return None
    rc, out, _ = _run(["xdotool", "search", "--name", XID_PATTERN], 4)
    if rc == 0:
        ids = [l for l in out.splitlines() if l.strip().isdigit()]
        if ids:
            return int(ids[0])
    return None


def find_mirror_geometry(xid):
    rc, out, _ = _run(["xdotool", "getwindowgeometry", "--shell", str(xid)], 4)
    geo = {}
    if rc == 0:
        for line in out.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                try:
                    geo[k.strip()] = int(v.strip())
                except Exception:
                    pass
    return geo  # X, Y, WIDTH, HEIGHT


def grab_window(xid, w, h):
    """Sample the mirror window content -> numpy RGB (small). Returns None on fail."""
    if Gdk is None or GdkX11 is None:
        return None
    try:
        disp = Gdk.Display.get_default()
        gdkwin = GdkX11.X11Window.foreign_new_for_display(disp, xid)
        if gdkwin is None:
            return None
        pb = Gdk.pixbuf_get_from_window(gdkwin, 0, 0, w, h)
        if pb is None:
            return None
        tw = max(48, min(160, w // 8))
        th = max(27, min(100, h // 8))
        small = pb.scale_simple(tw, th, GdkPixbuf.InterpType.BILINEAR)
        raw = small.get_pixels()
        if not _NP:
            return None
        arr = np.frombuffer(raw, dtype=np.uint8)
        nch = small.get_n_channels()
        arr = arr.reshape(th, tw, nch)
        return arr[:, :, :3].astype(np.float32) / 255.0
    except Exception:
        return None


def analyze_frame(rgb):
    """AI analysis of a frame (normalized RGB 0..1).

    Returns dict with:
      mean_luma, contrast (std), saturation,
      is_dark, is_washout, is_dull,
      exposure (white+ / black-), clarity, tint_rgb, tint_alpha
    """
    if not _NP or rgb is None:
        return None
    r = rgb[:, :, 0]; g = rgb[:, :, 1]; b = rgb[:, :, 2]
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    mean = float(luma.mean())
    std = float(luma.std())
    sat = float((np.maximum(np.maximum(r, g), b) - np.minimum(np.minimum(r, g), b)).mean())

    out = {"mean_luma": mean, "contrast": std, "saturation": sat,
           "is_dark": mean < 0.28, "is_washout": std < 0.16,
           "is_dull": sat < 0.12}

    # exposure: nudge toward a comfortable ~0.45 mean
    white = black = 0.0
    if mean < 0.40:
        white = min(0.10, (0.45 - mean) * 0.35)
    elif mean > 0.62:
        black = min(0.08, (mean - 0.62) * 0.25)
    out["exposure"] = white - black  # positive = brighten, negative = darken

    # clarity: boost when washed out (low contrast), plus optional user level
    auto_clarity = 0.55 if (out["is_washout"] and not out["is_dark"]) else 0.0
    out["clarity"] = auto_clarity

    # adaptive tint: cool for dark scenes, warm for bright, neutral mid
    if mean < 0.28:
        tint = (0.45, 0.55, 1.00)   # cool blue -> visibility on dark
        alpha = 0.10
    elif mean > 0.62:
        tint = (1.00, 0.82, 0.65)   # warm -> comfortable on bright
        alpha = 0.08
    else:
        tint = (0.30, 0.55, 1.00)   # subtle cool neutral
        alpha = 0.05
    out["tint_rgb"] = tint
    out["tint_alpha"] = alpha
    return out


def build_clarity_masks(rgb, clarity, smooth=2.0):
    """Local-contrast masks from the frame: (white_surface_rgba, black_surface_rgba)
    as numpy arrays with alpha in 0..255, size of the sampled frame."""
    if not _NP or rgb is None or clarity <= 0.01:
        return None
    r = rgb[:, :, 0]; g = rgb[:, :, 1]; b = rgb[:, :, 2]
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    hl = np.clip((luma - 0.5) / 0.5, 0, 1) * clarity
    sh = np.clip((0.5 - luma) / 0.5, 0, 1) * clarity
    if _SCI and smooth > 0:
        hl = _sci.gaussian_filter(hl, smooth)
        sh = _sci.gaussian_filter(sh, smooth)
    h, w = luma.shape
    white = np.zeros((h, w, 4), dtype=np.uint8)
    black = np.zeros((h, w, 4), dtype=np.uint8)
    white[:, :, 0] = white[:, :, 1] = white[:, :, 2] = 255
    white[:, :, 3] = np.clip(hl * 0.55 * 255, 0, 255).astype(np.uint8)
    black[:, :, 3] = np.clip(sh * 0.45 * 255, 0, 255).astype(np.uint8)
    return white, black


def _surface_from_rgba(arr):
    import cairo
    h, w = arr.shape[:2]
    srf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    srf.flush()
    data = srf.get_data()
    # cairo ARGB32 memory is native endian BGRA byte order in practice (little-endian)
    buf = np.frombuffer(data, dtype=np.uint8).reshape(h, w, 4)
    buf[:, :, 0] = arr[:, :, 2]  # B
    buf[:, :, 1] = arr[:, :, 1]  # G
    buf[:, :, 2] = arr[:, :, 0]  # R
    buf[:, :, 3] = arr[:, :, 3]  # A
    srf.mark_dirty()
    return srf


class SmartOverlay(object):
    """Always-on-top, click-through RGBA layer aligned to the mirror window."""

    def __init__(self, title="PadLink Smart Layer"):
        self.title = title
        self.win = None
        self.xid = None
        self.geo = (0, 0, 100, 100)
        self.enabled = True
        self.auto = True
        self.tint = (0.30, 0.55, 1.0)
        self.tint_alpha = 0.08
        self.exposure = 0.0
        self.clarity = 0.0
        self.opacity = 0.12            # master opacity (user)
        # manual (non-auto) levels, used when auto is off
        self.manual_exposure = 0.0
        self.manual_clarity = 0.0
        self.manual_tint = (0.30, 0.55, 1.0)
        self.masks = None              # (white_arr, black_arr)
        self.mask_w = self.mask_h = 0
        self._last_sample = 0.0
        self._gdkwin = None
        self._surfaces = (None, None)
        self._mirror_ok = False

    # ---------- lifecycle ----------
    def start(self):
        if self.win is not None:
            return
        if Gdk is None:
            return
        try:
            import cairo
            import gi
            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk
        except Exception:
            return
        w = Gtk.Window.new(Gtk.WindowType.POPUP)
        w.set_title(self.title)
        w.set_decorated(False)
        w.set_app_paintable(True)
        w.set_keep_above(True)
        w.set_skip_taskbar_hint(True)
        w.set_skip_pager_hint(True)
        w.set_accept_focus(False)
        w.set_focus_on_map(False)
        screen = w.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            w.set_visual(visual)
        w.set_size_request(10, 10)
        w.move(0, 0)
        w.show_all()
        w.realize()
        # click-through: empty input shape
        try:
            gdkw = w.get_window()
            if gdkw is not None:
                try:
                    region = cairo.Region()
                    gdkw.input_shape_combine_region(region, 0, 0)
                except Exception:
                    pass
        except Exception:
            pass
        w.connect("draw", self._on_draw)
        self._Gtk = Gtk
        self.win = w

    def stop(self):
        if self.win is not None:
            try:
                self.win.destroy()
            except Exception:
                pass
        self.win = None
        self._mirror_ok = False
        self._surfaces = (None, None)

    # ---------- tracking ----------
    def tick(self):
        """Called periodically: track mirror window + refresh sample/surfaces."""
        if self.win is None or not self.enabled:
            return
        xid = find_mirror_xid()
        if xid is None:
            if self._mirror_ok:
                self.win.hide()
                self._mirror_ok = False
            return
        geo = find_mirror_geometry(xid)
        if not geo or not geo.get("WIDTH"):
            return
        gx, gy = geo.get("X", 0), geo.get("Y", 0)
        gw, gh = geo.get("WIDTH", 100), geo.get("HEIGHT", 100)
        if (gx, gy, gw, gh) != self.geo:
            self.geo = (gx, gy, gw, gh)
            self.win.move(gx, gy)
            try:
                self.win.set_size_request(gw, gh)
            except Exception:
                pass
            self.win.resize(gw, gh)
        if not self._mirror_ok:
            self.win.show_all()
            self._mirror_ok = True
        self._gdkwin = None
        # periodic AI analysis (cheap, every ~2.5s)
        now = time.time()
        if now - self._last_sample > 2.5:
            self._last_sample = now
            self._sample_and_analyze(xid, gw, gh)

    def _sample_and_analyze(self, xid, gw, gh):
        rgb = grab_window(xid, gw, gh)
        stats = analyze_frame(rgb) if rgb is not None else None
        if self.auto:
            if stats is None:
                return
            self.exposure = stats["exposure"]
            self.clarity = stats["clarity"]
            self.tint = stats["tint_rgb"]
            self.tint_alpha = stats["tint_alpha"]
            eff_clarity = stats["clarity"]
        else:
            # manual levels
            self.exposure = self.manual_exposure
            self.clarity = self.manual_clarity
            self.tint = self.manual_tint
            self.tint_alpha = 0.10
            eff_clarity = self.manual_clarity
        # build clarity masks at sampled resolution
        if eff_clarity > 0.01 and rgb is not None:
            m = build_clarity_masks(rgb, eff_clarity)
            if m:
                self.masks = m
                self.mask_w, self.mask_h = m[0].shape[1], m[0].shape[0]
                try:
                    self._surfaces = (_surface_from_rgba(m[0]), _surface_from_rgba(m[1]))
                except Exception:
                    self._surfaces = (None, None)
            else:
                self.masks = None
                self._surfaces = (None, None)
        else:
            self.masks = None
            self._surfaces = (None, None)
        try:
            self.win.queue_draw()
        except Exception:
            pass

    # ---------- drawing ----------
    def _on_draw(self, wdg, cr):
        import cairo
        W, H = wdg.get_allocation().width, wdg.get_allocation().height
        if W <= 0 or H <= 0:
            return
        # transparent base
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        if not self.enabled:
            return
        cr.set_operator(cairo.OPERATOR_OVER)
        # 1) exposure layer
        e = self.exposure
        if e > 0.001:
            cr.set_source_rgba(1, 1, 1, min(0.14, e) * self.opacity * 4)
            cr.paint()
        elif e < -0.001:
            cr.set_source_rgba(0, 0, 0, min(0.12, -e) * self.opacity * 4)
            cr.paint()
        # 2) clarity masks (local contrast)
        ws, bs = self._surfaces
        if ws is not None and self.mask_w > 0:
            cr.save()
            cr.scale(W / float(self.mask_w), H / float(self.mask_h))
            cr.set_source_surface(ws, 0, 0)
            cr.paint()
            if bs is not None:
                cr.set_source_surface(bs, 0, 0)
                cr.paint()
            cr.restore()
        # 3) tint layer
        tr, tg, tb = self.tint
        a = self.tint_alpha * (self.opacity * 6.0)
        if a > 0.001:
            cr.set_source_rgba(tr, tg, tb, min(0.5, a))
            cr.paint()

    def set_enabled(self, on):
        self.enabled = on
        if self.win is not None:
            try:
                if on:
                    self.win.show_all()
                else:
                    self.win.hide()
            except Exception:
                pass

    def set_params(self, auto=None, opacity=None, tint=None,
                   clarity=None, exposure=None):
        if auto is not None:
            self.auto = auto
        if opacity is not None:
            self.opacity = float(opacity)
        if tint is not None:
            self.tint = tuple(tint)
            self.manual_tint = tuple(tint)
        if clarity is not None:
            self.manual_clarity = float(clarity)
            if not self.auto:
                self.clarity = float(clarity)
        if exposure is not None:
            self.manual_exposure = float(exposure)
            if not self.auto:
                self.exposure = float(exposure)
        if self.win is not None:
            try:
                self.win.queue_draw()
            except Exception:
                pass
