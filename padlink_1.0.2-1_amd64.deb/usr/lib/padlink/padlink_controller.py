#!/usr/bin/env python3
# ============================================================================
# PadLinkController - uses the USER'S OWN artwork as the controller base with
# live effects (glows, stick motion, trigger levels) at positions measured
# from that exact artwork.
#
# Pure ASCII source. Cairo rendering (vector + image).
#
# Pipeline: ControllerState (normalized) -> components -> draw(base art) +
# overlay(glows/sticks/triggers)
# ============================================================================
import math
import os

try:
    import cairo
except Exception:
    cairo = None

Gdk = None
Pango = None
PangoCairo = None
try:
    import gi
    gi.require_version("Gdk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    try:
        gi.require_foreign("cairo")
    except Exception:
        pass
    from gi.repository import GdkPixbuf, Gdk
    try:
        gi.require_version("Pango", "1.0")
        gi.require_version("PangoCairo", "1.0")
        from gi.repository import Pango, PangoCairo
    except Exception:
        Pango = PangoCairo = None
except Exception:
    GdkPixbuf = None
    Gdk = None

ART_CANDIDATES = [
    "/usr/share/padlink/controller_front.png",
    "/home/user/controller_front.png",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "controller_front.png"),
]
SHOULDER_CANDIDATES = [
    "/usr/share/padlink/shoulder_topview.png",
    "/home/user/shoulder_topview.png",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "shoulder_topview.png"),
]


def find_shoulder():
    for c in SHOULDER_CANDIDATES:
        if c and os.path.isfile(c):
            return c
    return None

DEADZONE = 0.10
EASE = 14.0
STICK_EASE = 12.0


def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, v))


def norm_axis(x, y, dead=DEADZONE):
    x = max(-1.0, min(1.0, x))
    y = max(-1.0, min(1.0, y))
    length = math.hypot(x, y)
    if length < dead or length == 0.0:
        return 0.0, 0.0
    s = (length - dead) / (1.0 - dead)
    return clamp((x / length) * s, -1.0, 1.0), clamp((y / length) * s, -1.0, 1.0)


class ControllerState(object):
    def __init__(self):
        self.A = self.B = self.X = self.Y = False
        self.LB = self.RB = False
        self.LT = self.RT = 0.0
        self.LX = self.LY = self.RX = self.RY = 0.0
        self.DU = self.DD = self.DL = self.DR = False
        self.Xbox = self.View = self.Menu = self.Share = False
        self.LS = self.RS = False  # stick click (push)


class Component(object):
    def __init__(self, cid, fx, fy):
        self.id = cid
        self.fx = fx
        self.fy = fy
        self.press = 0.0
        self.value = 0.0
        self.sx = 0.0
        self.sy = 0.0
        self.hover = False
        self.disabled = False
        self.dirty = True

    def update(self, dt):
        raise NotImplementedError


class DigitalButton(Component):
    def __init__(self, cid, fx, fy, label="", color=None, radius=0.03):
        super(DigitalButton, self).__init__(cid, fx, fy)
        self.radius = radius
        self.label = label
        self.color = color

    def set_target(self, on):
        t = 1.0 if on else 0.0
        if abs(t - self.value) > 1e-9:
            self.value = t
            self.dirty = True

    def update(self, dt):
        if abs(self.press - self.value) > 0.0005:
            self.press += (self.value - self.press) * min(1.0, dt * EASE)
            self.dirty = True
            return True
        self.press = self.value
        return False


class AnalogTrigger(Component):
    def __init__(self, cid, fx, fy, w, h, label="", angle=0.0):
        super(AnalogTrigger, self).__init__(cid, fx, fy)
        self.w = w
        self.h = h
        self.label = label
        self.angle = angle

    def set_target(self, v):
        v = clamp(float(v), 0.0, 1.0)
        if abs(v - self.value) > 1e-4:
            self.value = v
            self.dirty = True

    def update(self, dt):
        if abs(self.press - self.value) > 0.0005:
            self.press += (self.value - self.press) * min(1.0, dt * EASE)
            self.dirty = True
            return True
        self.press = self.value
        return False


class AnalogStick(Component):
    def __init__(self, cid, fx, fy, r):
        super(AnalogStick, self).__init__(cid, fx, fy)
        self.r = r
        self.px = 0.0
        self.py = 0.0

    def set_target(self, x, y):
        nx, ny = norm_axis(x, y)
        if abs(nx - self.sx) > 1e-4 or abs(ny - self.sy) > 1e-4:
            self.sx = nx
            self.sy = ny
            self.dirty = True

    def update(self, dt):
        moved = False
        if abs(self.px - self.sx) > 0.0005:
            self.px += (self.sx - self.px) * min(1.0, dt * STICK_EASE)
            self.dirty = True
            moved = True
        if abs(self.py - self.sy) > 0.0005:
            self.py += (self.sy - self.py) * min(1.0, dt * STICK_EASE)
            self.dirty = True
            moved = True
        return moved


def find_art():
    for c in ART_CANDIDATES:
        if c and os.path.isfile(c):
            return c
    return None


def rr_path(cr, x, y, w, h, r):
    r = min(r, w / 2.0, h / 2.0)
    cr.new_path()
    cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi)
    cr.arc(x + w - r, y + r, r, 1.5 * math.pi, 2 * math.pi)
    cr.arc(x + w - r, y + h - r, r, 0, 0.5 * math.pi)
    cr.arc(x + r, y + h - r, r, 0.5 * math.pi, math.pi)
    cr.close_path()


def circ(cr, cx, cy, r):
    cr.new_path()
    cr.arc(cx, cy, r, 0, 2 * math.pi)
    cr.close_path()


def text_center(cr, cx, cy, text, size, bold=False):
    cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL,
                        cairo.FONT_WEIGHT_BOLD if bold else cairo.FONT_WEIGHT_NORMAL)
    cr.set_font_size(size)
    ext = cr.text_extents(text)
    cr.move_to(cx - ext.width / 2 - ext.x_bearing, cy - ext.height / 2 - ext.y_bearing)
    cr.show_text(text)


def pango_text(cr, cx, cy, text, size_px, bold=True, color=(0.05, 0.05, 0.07),
               bg=None):
    """Draw text with proper shaping (needed for Arabic) using Noto Sans
    Arabic. If bg is a color, a small rounded light badge is drawn behind."""
    if PangoCairo is None:
        return
    try:
        cr.save()
        layout = PangoCairo.create_layout(cr)
        fd = Pango.FontDescription()
        fd.set_family("Noto Sans Arabic")
        fd.set_size(max(1, int(size_px * Pango.SCALE)))
        fd.set_weight(Pango.Weight.BOLD if bold else Pango.Weight.NORMAL)
        layout.set_font_description(fd)
        layout.set_text(text, -1)
        w, h = layout.get_pixel_size()
        if bg is not None:
            pad = max(2, int(size_px * 0.20))
            cr.set_source_rgba(bg[0], bg[1], bg[2], 0.85)
            rr_path(cr, cx - w / 2.0 - pad, cy - h / 2.0 - pad,
                    w + 2 * pad, h + 2 * pad, max(3, pad))
            cr.fill()
        cr.translate(cx - w / 2.0, cy - h / 2.0)
        cr.set_source_rgb(*color)
        PangoCairo.show_layout(cr, layout)
        cr.restore()
    except Exception:
        try:
            cr.restore()
        except Exception:
            pass


class PadLinkController(object):
    """Renders the user's artwork as base + live effects overlay.
    Positions (fx, fy) are normalized to the artwork; measured from it."""

    # Measured from the artwork (normalized to art width/height):
    # body bbox is ~(0.004..0.996, 0.008..0.992); controls inside it.
    def __init__(self):
        self.state = ControllerState()
        self.ls_press = False
        self.rs_press = False
        self.t = 0.0
        self.art_pixbuf = None
        self.art_path = None
        ap = find_art()
        if ap and GdkPixbuf is not None:
            try:
                self.art_pixbuf = GdkPixbuf.Pixbuf.new_from_file(ap)
                self.art_path = ap
            except Exception:
                self.art_pixbuf = None
        self.shoulder_pixbuf = None
        sp = find_shoulder()
        if sp and GdkPixbuf is not None:
            try:
                self.shoulder_pixbuf = GdkPixbuf.Pixbuf.new_from_file(sp)
            except Exception:
                self.shoulder_pixbuf = None

        # ---- shoulder controls (top strip of the art) ----
        # Measured from the shoulder artwork: triggers on the upper-left/right
        # dark shapes, bumpers on the lower-left/right dark shapes.
        self.lt = AnalogTrigger("controller-lt", 0.062, 0.224, 0.049, 0.017, "LT", -30)
        self.rt = AnalogTrigger("controller-rt", 0.932, 0.224, 0.049, 0.017, "RT", 30)
        self.lb = DigitalButton("controller-lb", 0.058, 0.541, "LB", radius=0.027)
        self.rb = DigitalButton("controller-rb", 0.937, 0.541, "RB", radius=0.027)

        # ---- front controls (EXACT positions measured from the extracted
        # front artwork, 1229x669, by locating the real dark shapes) ----
        self.lstick = AnalogStick("controller-left-stick", 0.275, 0.348, 0.059)
        self.rstick = AnalogStick("controller-right-stick", 0.582, 0.571, 0.060)
        # D-pad cross centered at (0.368, 0.577); arms measured from the art
        self.dpad_up = DigitalButton("controller-dpad-up", 0.368, 0.516, radius=0.012)
        self.dpad_dn = DigitalButton("controller-dpad-down", 0.368, 0.638, radius=0.012)
        self.dpad_lt = DigitalButton("controller-dpad-left", 0.335, 0.577, radius=0.012)
        self.dpad_rt = DigitalButton("controller-dpad-right", 0.400, 0.577, radius=0.012)
        # Face buttons - diamond found in the art: Y top, X left, B right, A bottom
        self.btn_a = DigitalButton("controller-a", 0.689, 0.444, "A", (0.10, 0.62, 0.20), radius=0.0273)
        self.btn_b = DigitalButton("controller-b", 0.737, 0.353, "B", (0.78, 0.20, 0.18), radius=0.0273)
        self.btn_x = DigitalButton("controller-x", 0.641, 0.353, "X", (0.20, 0.45, 0.88), radius=0.0273)
        self.btn_y = DigitalButton("controller-y", 0.689, 0.259, "Y", (0.90, 0.78, 0.15), radius=0.0273)
        # Center controls (measured)
        self.guide = DigitalButton("controller-xbox", 0.484, 0.205, radius=0.0301)
        self.view = DigitalButton("controller-view", 0.422, 0.341, radius=0.0203)
        self.menu = DigitalButton("controller-menu", 0.538, 0.341, radius=0.0203)
        self.share = DigitalButton("controller-share", 0.483, 0.453, radius=0.0170)


        self.components = [
            self.lt, self.rt, self.lb, self.rb,
            self.lstick, self.rstick,
            self.dpad_up, self.dpad_dn, self.dpad_lt, self.dpad_rt,
            self.btn_a, self.btn_b, self.btn_x, self.btn_y,
            self.guide, self.view, self.menu, self.share,
        ]

    def set_state(self, st):
        self.state = st
        self.lt.set_target(st.LT); self.rt.set_target(st.RT)
        self.lb.set_target(st.LB); self.rb.set_target(st.RB)
        self.lstick.set_target(st.LX, st.LY)
        self.rstick.set_target(st.RX, st.RY)
        self.ls_press = bool(getattr(st, "LS", False))
        self.rs_press = bool(getattr(st, "RS", False))
        self.dpad_up.set_target(st.DU); self.dpad_dn.set_target(st.DD)
        self.dpad_lt.set_target(st.DL); self.dpad_rt.set_target(st.DR)
        self.btn_a.set_target(st.A); self.btn_b.set_target(st.B)
        self.btn_x.set_target(st.X); self.btn_y.set_target(st.Y)
        self.guide.set_target(st.Xbox)
        self.view.set_target(st.View); self.menu.set_target(st.Menu)
        self.share.set_target(st.Share)

    def update(self, dt):
        self.t += dt
        animating = False
        for c in self.components:
            if c.update(dt):
                animating = True
        return animating

    def clear_dirty(self):
        for c in self.components:
            c.dirty = False

    def auto_calibrate(self):
        """SMART CALIBRATION: re-measures the user's artwork with image
        analysis and corrects every control's position AND size so each
        effect lands exactly on the real button/shape. Returns a report
        list of strings (Arabic)."""
        report = []
        try:
            import numpy as np
            from scipy import ndimage
        except Exception:
            report.append("المعايرة الذكية تحتاج python3-numpy و python3-scipy")
            return report
        pb = self.art_pixbuf
        if pb is None:
            report.append("لا توجد صورة اليد للمعايرة")
            return report
        W, H = pb.get_width(), pb.get_height()
        try:
            raw = np.frombuffer(pb.get_pixels(), dtype=np.uint8)
            data = raw.reshape(H, W, pb.get_n_channels())
            if data.shape[2] == 3:
                a = np.full((H, W, 1), 255, np.uint8)
                data = np.concatenate([data, a], axis=2)
        except Exception:
            report.append("تعذر قراءة صورة اليد")
            return report
        rgb = data[:, :, :3].astype(int)
        alpha = data[:, :, 3]
        dark = (rgb[:, :, 0] < 110) & (rgb[:, :, 1] < 110) & \
               (rgb[:, :, 2] < 110) & (alpha > 120)
        lab, n = ndimage.label(dark)
        comps = []
        for i in range(1, n + 1):
            ys, xs = np.where(lab == i)
            if len(xs) < 250:
                continue
            comps.append((xs.min(), xs.max(), ys.min(), ys.max(),
                          (xs.min() + xs.max()) / 2.0,
                          (ys.min() + ys.max()) / 2.0, len(xs)))
        fixed = 0

        def set_comp(ctrl, x, y, r):
            ctrl.fx = x / float(W)
            ctrl.fy = y / float(H)
            ctrl.radius = r / float(W)
            ctrl.dirty = True

        # --- ABXY: 4 similar-sized rings forming a diamond ---
        rings = [c for c in comps if 55 <= (c[1] - c[0]) <= 95 and
                 55 <= (c[3] - c[2]) <= 95 and 700 <= c[6] <= 1800]
        rings.sort(key=lambda c: c[6])
        # pick 4 with most similar areas
        best = None
        if len(rings) >= 4:
            for i in range(len(rings) - 3):
                quad = rings[i:i + 4]
                spread = quad[-1][6] - quad[0][6]
                cx = sorted(q[4] for q in quad)
                cy = sorted(q[5] for q in quad)
                xs, ys = cx[1] + cx[2], cy[1] + cy[2]
                sym = abs((cx[3] - cx[0]) - (cy[3] - cy[0]))
                if best is None or (spread + sym) < best[0]:
                    best = (spread + sym, quad)
        if best:
            quad = best[1]
            # find the two sharing x (vertical pair) = Y top / A bottom
            qs = sorted(quad, key=lambda q: q[5])
            y_top, y_bot = qs[0], qs[-1]
            left = [q for q in quad if q is not y_top and q is not y_bot]
            left.sort(key=lambda q: q[4])
            x_l, x_r = left[0], left[1]
            set_comp(self.btn_y, y_top[4], y_top[5], (y_top[1] - y_top[0]) / 2.0)
            set_comp(self.btn_a, y_bot[4], y_bot[5], (y_bot[1] - y_bot[0]) / 2.0)
            set_comp(self.btn_x, x_l[4], x_l[5], (x_l[1] - x_l[0]) / 2.0)
            set_comp(self.btn_b, x_r[4], x_r[5], (x_r[1] - x_r[0]) / 2.0)
            fixed += 4

        # --- Sticks: the two largest big circular components ---
        big = sorted([c for c in comps if 100 <= (c[1] - c[0]) <= 150 and
                      100 <= (c[3] - c[2]) <= 150], key=lambda c: -c[6])
        if len(big) >= 2:
            left_s = big[0] if big[0][4] < big[1][4] else big[1]
            right_s = big[1] if big[0][4] < big[1][4] else big[0]
            for st, c in ((self.lstick, left_s), (self.rstick, right_s)):
                st.fx = c[4] / float(W)
                st.fy = c[5] / float(H)
                # cap radius = st.r*w*0.5 ; inner circle ~0.63 of the outer ring
                st.r = (c[1] - c[0]) / float(W) * 0.63
                st.dirty = True
            fixed += 2

        # --- D-pad: big cross in the lower-left area ---
        dp = [c for c in comps if 140 <= (c[1] - c[0]) <= 190 and
              140 <= (c[3] - c[2]) <= 190 and c[4] < W * 0.55 and
              c[5] > H * 0.45]
        if dp:
            c = sorted(dp, key=lambda q: -q[6])[0]
            cx, cy = c[4], c[5]
            arm = (c[1] - c[0]) / 4.0
            self.dpad_up.fx = self.dpad_dn.fx = self.dpad_lt.fx = self.dpad_rt.fx = cx / float(W)
            self.dpad_up.fy = (cy - arm) / float(H)
            self.dpad_dn.fy = (cy + arm) / float(H)
            self.dpad_lt.fx = (cx - arm) / float(W)
            self.dpad_rt.fx = (cx + arm) / float(W)
            self.dpad_lt.fy = self.dpad_rt.fy = cy / float(H)
            for b in (self.dpad_up, self.dpad_dn, self.dpad_lt, self.dpad_rt):
                b.dirty = True
            fixed += 1

        # --- Guide: big ring in the upper-center ---
        g = [c for c in comps if 60 <= (c[1] - c[0]) <= 95 and
             60 <= (c[3] - c[2]) <= 95 and c[4] > W * 0.35 and c[4] < W * 0.65 and
             c[5] < H * 0.35]
        if g:
            c = sorted(g, key=lambda q: -q[6])[0]
            set_comp(self.guide, c[4], c[5], (c[1] - c[0]) / 2.0)
            fixed += 1

        # --- View / Menu: two similar small rings flanking below the guide ---
        small = [c for c in comps if 40 <= (c[1] - c[0]) <= 60 and
                 40 <= (c[3] - c[2]) <= 60 and 400 <= c[6] <= 1400 and
                 c[5] > H * 0.25 and c[5] < H * 0.45]
        if len(small) >= 2:
            small.sort(key=lambda q: q[4])
            s_l, s_r = small[0], small[-1]
            if abs(s_l[5] - s_r[5]) < 30 and s_r[4] - s_l[4] > 80:
                set_comp(self.view, s_l[4], s_l[5], (s_l[1] - s_l[0]) / 2.0)
                set_comp(self.menu, s_r[4], s_r[5], (s_r[1] - s_r[0]) / 2.0)
                fixed += 2
                # Share: a smaller shape between/below them
                sh = [c for c in comps if 30 <= (c[1] - c[0]) <= 60 and
                      c[4] > s_l[4] and c[4] < s_r[4] and c[5] > s_l[5] and
                      c is not s_l and c is not s_r]
                if sh:
                    c = sorted(sh, key=lambda q: -q[6])[0]
                    set_comp(self.share, c[4], c[5], (c[1] - c[0]) / 2.0)
                    fixed += 1

        report.append("معايرة الواجهة: تم ضبط %d عنصرًا من الصورة مباشرة" % fixed)
        # --- shoulder strip (triggers/bumpers) ---
        spb = self.shoulder_pixbuf
        if spb is not None:
            SW, SH = spb.get_width(), spb.get_height()
            try:
                sraw = np.frombuffer(spb.get_pixels(), dtype=np.uint8)
                sdata = sraw.reshape(SH, SW, spb.get_n_channels())
                if sdata.shape[2] == 3:
                    a = np.full((SH, SW, 1), 255, np.uint8)
                    sdata = np.concatenate([sdata, a], axis=2)
                srgb = sdata[:, :, :3].astype(int)
                sal = sdata[:, :, 3]
                sdark = (srgb[:, :, 0] < 120) & (srgb[:, :, 1] < 120) & \
                        (srgb[:, :, 2] < 120) & (sal > 120)
                slab, sn = ndimage.label(sdark)
                sc = []
                for i in range(1, sn + 1):
                    ys, xs = np.where(slab == i)
                    if len(xs) < 150:
                        continue
                    sc.append(((xs.min() + xs.max()) / 2.0,
                               (ys.min() + ys.max()) / 2.0,
                               xs.max() - xs.min() + 1, ys.max() - ys.min() + 1))
                # split by side (outer quarter) and band (upper=trigger,
                # lower=bumper), then pick the largest shape in each cell
                def pick(x0, x1, y0, y1):
                    best = None
                    for q in sc:
                        if x0 <= q[0] < x1 and y0 <= q[1] < y1:
                            if best is None or q[2] * q[3] > best[2] * best[3]:
                                best = q
                    return best
                ltq = pick(0, SW * 0.40, 0, SH * 0.40)
                lbq = pick(0, SW * 0.40, SH * 0.40, SH)
                rtq = pick(SW * 0.60, SW, 0, SH * 0.40)
                rbq = pick(SW * 0.60, SW, SH * 0.40, SH)
                for q, tr in ((ltq, self.lt), (rtq, self.rt)):
                    if q:
                        tr.fx = q[0] / float(SW); tr.fy = q[1] / float(SH)
                        tr.w = q[2] / float(SW); tr.h = q[3] / float(SW)
                        tr.dirty = True
                for q, b in ((lbq, self.lb), (rbq, self.rb)):
                    if q:
                        b.fx = q[0] / float(SW); b.fy = q[1] / float(SH)
                        b.radius = max(q[2], q[3]) / 2.0 / float(SW)
                        b.dirty = True
                report.append("معايرة الشفتات: زنادان وزرا كتف من الصورة")
            except Exception:
                pass
        self.clear_dirty()
        return report

    def draw(self, cr, width, height):
        """Compose: SHOULDER ART (top) + FRONT ART (below) + live effects.
        Both are the user's own artwork; effects overlay at measured spots."""
        if self.art_pixbuf is None:
            self._draw_fallback(cr, width, height)
            return

        def blit(pb, ox, oy, dw, dh):
            # Paint the artwork WITH its own alpha only - no background fill.
            # Transparent areas let whatever is behind the drawing area show.
            cr.save()
            cr.translate(ox, oy)
            cr.scale(dw / pb.get_width(), dh / pb.get_height())
            try:
                srf = cairo.ImageSurface(cairo.FORMAT_ARGB32,
                                         pb.get_width(), pb.get_height())
                ctx = cairo.Context(srf)
                Gdk.cairo_set_source_pixbuf(ctx, pb, 0, 0)
                ctx.paint()
                cr.set_source_surface(srf, 0, 0)
                cr.paint()
            except Exception:
                pass
            cr.restore()

        # Layout: shoulder art on top (40% height), front art below (60%).
        spb = self.shoulder_pixbuf
        total_h = height
        sh_h = int(total_h * 0.32) if spb is not None else 0
        fr_h = total_h - sh_h
        margin = 10

        # Front art region (below)
        fw = width - 2 * margin
        fh = fr_h - margin
        iw = self.art_pixbuf.get_width()
        ih = self.art_pixbuf.get_height()
        fscale = min(fw / iw, fh / ih)
        fdw, fdh = iw * fscale, ih * fscale
        fox = (width - fdw) / 2.0
        foy = sh_h + (fh - fdh) / 2.0
        blit(self.art_pixbuf, fox, foy, fdw, fdh)

        # Effects on FRONT art (coords in front art space)
        def PF(fx, fy):
            return fox + fx * fdw, foy + fy * fdh

        self._draw_front_effects(cr, PF, fdw)

        # Shoulder art region (top)
        if spb is not None:
            sw = spb.get_width()
            shh = spb.get_height()
            sscale = min((width - 2 * margin) / sw, sh_h / shh)
            sdw, sdh = sw * sscale, shh * sscale
            sox = (width - sdw) / 2.0
            soy = (sh_h - sdh) / 2.0
            blit(spb, sox, soy, sdw, sdh)
            # Effects on shoulder art
            def PS(fx, fy):
                return sox + fx * sdw, soy + fy * sdh
            self._draw_shoulder_effects(cr, PS, sdw)

    def _draw_front_effects(self, cr, P, w):
        def glow(x, y, r, on, col=(0.1, 1.0, 0.25), alpha=0.65):
            if not on:
                return
            cr.save()
            cr.set_source_rgba(col[0], col[1], col[2], alpha)
            circ(cr, x, y, r); cr.fill()
            cr.set_source_rgba(1, 1, 1, 0.9)
            cr.set_line_width(2)
            circ(cr, x, y, r); cr.stroke()
            cr.restore()

        # Sticks
        for st in (self.lstick, self.rstick):
            x, y = P(st.fx, st.fy)
            nx = x + st.px * st.r * w * 0.8
            ny = y + st.py * st.r * w * 0.8
            if math.hypot(st.px, st.py) > 0.05:
                glow(nx, ny, st.r * w * 0.5, True, (0.12, 1.0, 0.32), 0.4)
            cr.save()
            cr.set_source_rgb(0.45, 0.45, 0.5)
            circ(cr, nx, ny, st.r * w * 0.5); cr.fill_preserve()
            cr.set_source_rgb(0.12, 0.12, 0.15); cr.set_line_width(2); cr.stroke()
            cr.set_source_rgba(1, 1, 1, 0.3)
            circ(cr, nx - st.r * w * 0.12, ny - st.r * w * 0.15, st.r * w * 0.14); cr.fill()
            # stick click: orange ring around the cap + soft outer glow
            clicked = (st is self.lstick and self.ls_press) or \
                      (st is self.rstick and self.rs_press)
            if clicked:
                cr.set_source_rgba(1.0, 0.55, 0.1, 0.55)
                circ(cr, nx, ny, st.r * w * 0.5); cr.set_line_width(3); cr.stroke()
                cr.set_source_rgba(1.0, 0.55, 0.1, 0.25)
                circ(cr, nx, ny, st.r * w * 0.62); cr.set_line_width(4); cr.stroke()
            cr.restore()

        # D-pad (positions are the arm midpoints measured from the art)
        for b in (self.dpad_up, self.dpad_dn, self.dpad_lt, self.dpad_rt):
            if b.press > 0.05:
                x, y = P(b.fx, b.fy)
                glow(x, y, b.radius * w, True, (0.15, 1.0, 0.35), 0.55 * b.press)

        # Face buttons
        for b in (self.btn_a, self.btn_b, self.btn_x, self.btn_y):
            if b.press > 0.05:
                x, y = P(b.fx, b.fy)
                glow(x, y, b.radius * w, True, b.color, 0.5 * b.press)

        # Guide pulse
        gx, gy = P(self.guide.fx, self.guide.fy)
        if self.guide.press > 0.05:
            glow(gx, gy, self.guide.radius * w, True, (0.15, 1.0, 0.35), 0.8)
        else:
            pulse = 0.15 + 0.3 * (math.sin(self.t * 3.0) + 1) / 2
            cr.save()
            cr.set_source_rgba(0.1, 1.0, 0.3, pulse)
            circ(cr, gx, gy, self.guide.radius * w); cr.fill()
            cr.restore()

        # View/Menu/Share
        for b in (self.view, self.menu, self.share):
            if b.press > 0.05:
                x, y = P(b.fx, b.fy)
                glow(x, y, b.radius * w, True, (0.15, 1.0, 0.35), 0.6)

        # No labels/descriptions are drawn: the artwork is shown exactly as
        # it is, with only the live effects on the controls themselves.

    def _draw_shoulder_effects(self, cr, P, w):
        # Triggers: green fill + sliding thumb along the art groove
        for tr, sx in ((self.lt, -1), (self.rt, 1)):
            x, y = P(tr.fx, tr.fy)
            tw = tr.w * w
            th = tr.h * w
            if tr.press > 0.02:
                cr.save()
                cr.set_source_rgba(0.12, 1.0, 0.32, 0.4 * tr.press)
                rr_path(cr, x - tw / 2, y - th / 2, tw * clamp(tr.press, 0, 1), th, 5)
                cr.fill()
                cr.restore()
            tx = x + sx * ((tw / 2 - th / 2) * (2 * tr.press - 1))
            ty = y
            cr.save()
            cr.set_source_rgb(0.42, 0.42, 0.47)
            circ(cr, tx, ty, th / 2 * 0.9); cr.fill_preserve()
            cr.set_source_rgb(0.15, 0.15, 0.18); cr.set_line_width(2); cr.stroke()
            cr.set_source_rgba(1, 1, 1, 0.3)
            circ(cr, tx - th * 0.08, ty - th * 0.1, th * 0.12); cr.fill()
            cr.restore()
        # Bumpers glow
        for b in (self.lb, self.rb):
            if b.press > 0.05:
                x, y = P(b.fx, b.fy)
                cr.save()
                cr.set_source_rgba(0.15, 1.0, 0.35, 0.5 * b.press)
                circ(cr, x, y, b.radius * w); cr.fill()
                cr.restore()
        # No labels/descriptions are drawn here either.

    def _draw_fallback(self, cr, width, height):
        cr.set_source_rgb(0.15, 0.15, 0.18)
        cr.rectangle(0, 0, width, height)
        cr.fill()
        cr.set_source_rgb(0.7, 0.7, 0.75)
        text_center(cr, width / 2, height / 2, "Controller art not found", 20)
        text_center(cr, width / 2, height / 2 + 30, "Expected: controller.png", 14)


def render(state, width, height, path=None):
    if cairo is None:
        return None
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(width), int(height))
    cr = cairo.Context(surf)
    # No background: the artwork is a transparent shape.
    cc = PadLinkController()
    cc.set_state(state)
    cc.update(1.0)
    cc.draw(cr, width, height)
    if path:
        surf.write_to_png(path)
    return surf


def idle_state():
    return ControllerState()


def example_state():
    st = ControllerState()
    st.A = True
    st.Y = True
    st.LB = True
    st.LT = 0.72
    st.RT = 0.34
    st.LX = -0.42
    st.LY = 0.18
    st.RY = -0.65
    st.DL = True
    st.Xbox = True
    return st


if __name__ == "__main__":
    render(idle_state(), 1600, 980, "/home/user/controller_from_art.png")
    render(example_state(), 1600, 980, "/home/user/controller_from_art_live.png")
    print("rendered")
