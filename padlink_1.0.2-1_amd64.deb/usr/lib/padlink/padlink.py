#!/usr/bin/env python3
# ============================================================================
# PadLink 1.0.0 - Android mirror + universal gamepad + headless app control.
# Pure ASCII source; all Arabic text in ui_ar.json.
#
# Pages:
#   1) Devices   : phone (USB/WiFi) + any gamepad status, doctor, wifi, tips
#   2) Screen    : standalone mirror window (never disappears) + controls
#   3) Controller: the USER'S OWN ARTWORK (extracted shape, no background)
#                  + live glow/stick/trigger effects over it
#   4) Apps      : launch/stop/open apps and control the phone WITHOUT
#                  showing its screen (screen stays free or off)
#
# Stack: PyGObject(GTK3) + evdev + adb (bundled) + scrcpy (bundled)
#        + cairo overlays. Controller forwarding via UHID/AOAv2.
# ============================================================================
import glob, json, math, os, shutil, subprocess, sys, threading, time
import traceback
from datetime import datetime

APP_VERSION = "1.0.2"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
BIN_DIR = os.path.join(APP_DIR, "bin")
CONFIG_DIR = os.path.expanduser("~/.config/padlink")
CONFIG_FILE = os.path.join(CONFIG_DIR, "config.json")
SCREENSHOT_DIR = os.path.expanduser("~/Pictures")
VIDEO_DIR = os.path.expanduser("~/Videos")
LOCALE_CANDIDATES = [
    os.environ.get("PADLINK_LOCALE", ""),
    "/usr/share/padlink/ui_ar.json",
    os.path.join(APP_DIR, "ui_ar.json"),
    os.path.normpath(os.path.join(APP_DIR, "..", "..", "share", "padlink", "ui_ar.json")),
]
EMBED_TITLE = "padlink_window"
K_HOME, K_BACK, K_APP, K_VOLUP, K_VOLDOWN, K_POWER = 3, 4, 187, 24, 25, 26

# Controller artwork module (same directory). Renders the user's own photos
# as a transparent shape with live effects; no vector re-drawing.
try:
    if APP_DIR not in sys.path:
        sys.path.insert(0, APP_DIR)
    import padlink_controller as _pc
except Exception:
    _pc = None

# Smart AI color/clarity layer over the standalone mirror window.
try:
    if APP_DIR not in sys.path:
        sys.path.insert(0, APP_DIR)
    import smart_overlay as _so
except Exception:
    _so = None


def log(msg):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        with open(os.path.join(CONFIG_DIR, "app.log"), "a", encoding="utf-8") as fh:
            fh.write("[%s] %s\n" % (datetime.now().isoformat(timespec="seconds"), msg))
    except Exception:
        pass


def load_locale():
    for p in LOCALE_CANDIDATES:
        if p and os.path.isfile(p):
            try:
                return json.load(open(p, encoding="utf-8"))
            except Exception:
                continue
    return {}

T = load_locale()


def tr(k, fb=""):
    v = T.get(k)
    return v if v is not None else (fb if fb else k)


def run_cmd(cmd, timeout=10):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception as e:
        return -1, "", str(e)


def _ensure_exec(p):
    try:
        if os.path.isfile(p) and not os.access(p, os.X_OK):
            os.chmod(p, 0o755)
        return os.path.isfile(p) and os.access(p, os.X_OK)
    except Exception:
        return False


def find_adb():
    for c in (os.path.join(BIN_DIR, "adb"), "/usr/lib/padlink/bin/adb"):
        if _ensure_exec(c):
            return c
    return shutil.which("adb")


def adb_cmd(args):
    return [find_adb() or "adb"] + args


def find_scrcpy():
    for c in (os.path.join(BIN_DIR, "scrcpy"), "/usr/lib/padlink/bin/scrcpy"):
        if _ensure_exec(c):
            return c
    return shutil.which("scrcpy")


def is_wayland():
    return bool(os.environ.get("WAYLAND_DISPLAY"))


def detect_phones():
    """Detect connected Android phones via USB. Restarts adb server once
    if the first query finds nothing (common USB enumeration glitch)."""
    if find_adb() is None:
        return "adb_missing", []
    rc, out, _ = run_cmd(adb_cmd(["devices"]), 8)
    if rc != 0:
        return "none", []
    devs, unauth = [], False
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 2:
            if p[1] == "device":
                devs.append(p[0])
            elif p[1] == "unauthorized":
                unauth = True
            elif p[1] == "offline":
                # device present but stuck offline: try restarting adb
                run_cmd(adb_cmd(["kill-server"]), 8)
                run_cmd(adb_cmd(["start-server"]), 8)
                time.sleep(0.5)
    if devs:
        return "ok", devs
    if unauth:
        return "unauthorized", []
    # one retry with a fresh server
    run_cmd(adb_cmd(["kill-server"]), 8)
    run_cmd(adb_cmd(["start-server"]), 8)
    rc, out, _ = run_cmd(adb_cmd(["devices"]), 8)
    devs, unauth = [], False
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 2:
            if p[1] == "device":
                devs.append(p[0])
            elif p[1] == "unauthorized":
                unauth = True
    if devs:
        return "ok", devs
    if unauth:
        return "unauthorized", []
    return "none", []



def get_phone_size(serial):
    rc, out, _ = run_cmd(adb_cmd(["-s", serial, "shell", "wm", "size"]), 6)
    for line in out.splitlines():
        if "size" in line.lower() and "x" in line:
            part = line.split(":", 1)[-1].strip().lower()
            try:
                w, h = part.split("x")
                return int(w), int(h)
            except Exception:
                continue
    return 1080, 2400


def detect_controllers():
    """Detect ANY gamepad the kernel exposes (wired or Bluetooth).
    Uses a broad heuristic: an input device with analog axes and at least
    one of the common gamepad buttons, or a joystick js* node."""
    ctrls = []
    try:
        import evdev
    except Exception:
        return ctrls
    _NON_PAD = ("keyboard", "kbd", "mouse", "touchpad", "trackpoint",
                "thinkpad", "power button", "video bus", "lid switch",
                "rfkill", "dvd", "wmi", "hotkey", "sleep button")
    for path in evdev.list_devices():
        if "event" not in os.path.basename(path):
            continue
        try:
            dev = evdev.InputDevice(path)
            name = (dev.name or "").lower()
            if any(n in name for n in _NON_PAD):
                dev.close()
                continue
            caps = dev.capabilities(verbose=False)
            raw_abs = caps.get(evdev.ecodes.EV_ABS, [])
            abs_keys = [i[0] if isinstance(i, tuple) else i for i in raw_abs]
            key_keys = caps.get(evdev.ecodes.EV_KEY, [])
            # axes: sticks/triggers OR a d-pad hat (some pads report only hat)
            has_axis = any(k in (evdev.ecodes.ABS_X, evdev.ecodes.ABS_Y,
                                 evdev.ecodes.ABS_RX, evdev.ecodes.ABS_RZ,
                                 evdev.ecodes.ABS_Z, evdev.ecodes.ABS_HAT0X,
                                 evdev.ecodes.ABS_HAT0Y, evdev.ecodes.ABS_BRAKE,
                                 evdev.ecodes.ABS_GAS) for k in abs_keys)
            has_btn = any(k in (evdev.ecodes.BTN_A, evdev.ecodes.BTN_SOUTH,
                                evdev.ecodes.BTN_JOYSTICK, evdev.ecodes.BTN_GAMEPAD,
                                evdev.ecodes.BTN_TL, evdev.ecodes.BTN_TR,
                                evdev.ecodes.BTN_START, evdev.ecodes.BTN_SELECT,
                                evdev.ecodes.BTN_DPAD_UP, evdev.ecodes.BTN_DPAD_DOWN,
                                evdev.ecodes.BTN_DPAD_LEFT, evdev.ecodes.BTN_DPAD_RIGHT)
                          for k in key_keys)
            if has_axis and has_btn:
                info = (0, 0, 0, 0)
                phys = ""
                try:
                    info, phys = dev.info, dev.phys or ""
                except Exception:
                    pass
                ctrls.append({"name": dev.name or "Gamepad", "path": path,
                              "readable": True, "vendor": info[1],
                              "product": info[2], "phys": phys,
                              "buttons": len(key_keys), "axes": len(abs_keys)})
            dev.close()
        except PermissionError:
            ctrls.append({"name": os.path.basename(path), "path": path,
                          "readable": False, "vendor": 0, "product": 0,
                          "phys": "", "buttons": 0, "axes": 0})
        except Exception:
            continue
    # Fallback: classic joystick nodes
    if not ctrls:
        for js in sorted(glob.glob("/dev/input/js*")):
            ctrls.append({"name": js, "path": js, "readable": False,
                          "vendor": 0, "product": 0, "phys": "",
                          "buttons": 0, "axes": 0})
    return ctrls



def list_packages():
    """User-installed packages: name -> label(optional)."""
    rc, out, _ = run_cmd(adb_cmd(["shell", "pm", "list", "packages", "-3"]), 15)
    pkgs = []
    for line in out.splitlines():
        line = line.strip()
        if line.startswith("package:"):
            pkgs.append(line.split(":", 1)[1])
    return sorted(pkgs)


def launch_app(pkg):
    # Preferred: launcher activity via monkey (works without knowing activity).
    rc, out, err = run_cmd(
        adb_cmd(["shell", "monkey", "-p", pkg, "-c",
                 "android.intent.category.LAUNCHER", "1"]), 20)
    return (rc == 0 and "Events injected" in (out + err)) or (rc == 0 and "No activities found" not in (out + err))


def stop_app(pkg):
    run_cmd(adb_cmd(["shell", "am", "force-stop", pkg]), 10)


def open_file(path):
    """Open a file path on the phone with the default handler."""
    p = path.replace(" ", "%20")
    run_cmd(adb_cmd(["shell", "am", "start", "-a",
                     "android.intent.action.VIEW", "-d", "file://" + p,
                     "-t", "*/*"]), 15)


def tap(x, y):
    run_cmd(adb_cmd(["shell", "input", "tap", str(x), str(y)]), 8)


def swipe(x1, y1, x2, y2, ms=200):
    run_cmd(adb_cmd(["shell", "input", "swipe", str(x1), str(y1),
                     str(x2), str(y2), str(ms)]), 8)


def input_text(text):
    safe = text.replace(" ", "%s")
    run_cmd(adb_cmd(["shell", "input", "text", safe]), 8)


def keyevent(code):
    run_cmd(adb_cmd(["shell", "input", "keyevent", str(code)]), 8)


def open_url(url):
    run_cmd(adb_cmd(["shell", "am", "start", "-a",
                     "android.intent.action.VIEW", "-d", url]), 15)


def set_volume(level):
    """Set media volume 0..100."""
    run_cmd(adb_cmd(["shell", "media", "volume", "--stream", "3",
                     "--set", str(max(0, min(100, int(level))))]), 8)


def set_brightness(level):
    """Set screen brightness 0..255 (and disable auto)."""
    run_cmd(adb_cmd(["shell", "settings", "put", "system",
                     "screen_brightness_mode", "0"]), 8)
    run_cmd(adb_cmd(["shell", "settings", "put", "system",
                     "screen_brightness", str(max(0, min(255, int(level))))]), 8)


def wake_phone():
    run_cmd(adb_cmd(["shell", "input", "keyevent", "KEYCODE_WAKEUP"]), 8)


def lock_phone():
    run_cmd(adb_cmd(["shell", "input", "keyevent", "KEYCODE_SLEEP"]), 8)


def controller_type(name):
    """PadLink targets the Xbox 360 controller. Return its label."""
    return "\u0625\u0643\u0633 \u0628\u0648\u0643\u0633 360"

def test_rumble(path, intensity=100, duration=400):
    if intensity <= 0:
        return False
    try:
        import evdev
        from evdev import ff
        dev = evdev.InputDevice(path)
        try:
            caps = dev.capabilities()
            if evdev.ecodes.FF_RUMBLE not in caps.get(evdev.ecodes.EV_FF, []):
                return False
            s = max(0, min(0xFFFF, int(intensity * 0xFFFF / 100)))
            fx = ff.FF_RUMBLE(s, s, int(duration), 0)
            dev.upload(fx)
            dev.write(evdev.ecodes.EV_FF, fx.id, 1)
            return True
        finally:
            dev.close()
    except Exception:
        return False


def default_config():
    return {"max_size": "1024", "fps": "60", "bitrate": "16M", "audio": True,
            "gamepad": "uhid", "mode": "standalone", "preset": "balanced",
            "record": False, "stay_awake": False, "turn_screen_off": False,
            "mouse_mode": "sdk", "forward_enabled": True, "vibration_enabled": True,
            "vibration": 100, "vibration_ms": 400, "deadzone": 8,
            "headless_screen_off": False, "auto_mirror": True,
            "overlay_auto": True, "overlay_clarity": 0.0, "overlay_exposure": 0.0}


def load_config():
    try:
        d = json.load(open(CONFIG_FILE, encoding="utf-8"))
        m = default_config()
        m.update(d)
        m["mode"] = "standalone"  # forced: never disappears
        return m
    except Exception:
        return default_config()


def save_config(c):
    try:
        os.makedirs(CONFIG_DIR, exist_ok=True)
        json.dump(c, open(CONFIG_FILE, "w", encoding="utf-8"), indent=2)
    except Exception:
        pass


GTK_OK, _ERR, cairo = False, "", None
try:
    import gi
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gtk, GLib, Gdk, GdkPixbuf
    GTK_OK = True
    try:
        import cairo
        gi.require_foreign("cairo")
    except Exception:
        cairo = None
except Exception as e:
    _ERR = str(e)


def clamp(v, lo=-1.0, hi=1.0):
    return max(lo, min(hi, v))


if GTK_OK:

    class GamepadReader(threading.Thread):
        def __init__(self, path, on_update):
            super().__init__(daemon=True)
            self.path, self.on_update = path, on_update
            self.buttons, self.axes, self.ranges = {}, {}, {}
            self.offsets, self.running = {}, True
            self.lock = threading.Lock()

        def run(self):
            try:
                import evdev
            except Exception:
                return
            try:
                dev = evdev.InputDevice(self.path)
            except Exception:
                return
            try:
                try:
                    for item in dev.capabilities(verbose=False).get(evdev.ecodes.EV_ABS, []):
                        code = item[0] if isinstance(item, tuple) else item
                        try:
                            ai = dev.absinfo(code)
                            self.ranges[code] = (ai.min, ai.max)
                        except Exception:
                            pass
                except Exception:
                    pass
                for ev in dev.read_loop():
                    if not self.running:
                        break
                    if ev.type == evdev.ecodes.EV_KEY:
                        with self.lock:
                            self.buttons[ev.code] = ev.value
                        GLib.idle_add(self.on_update)
                    elif ev.type == evdev.ecodes.EV_ABS:
                        with self.lock:
                            self.axes[ev.code] = ev.value
                        GLib.idle_add(self.on_update)
            except Exception:
                pass
            finally:
                try:
                    dev.close()
                except Exception:
                    pass

        def stop(self):
            self.running = False

        def state(self):
            with self.lock:
                return dict(self.buttons), dict(self.axes), dict(self.ranges)

    class PadLinkWindow(Gtk.Window):
        def __init__(self):
            super().__init__(title=tr("app_title"))
            self.set_default_size(1180, 800)
            self.config = load_config()
            self.phone_state, self.phones = "none", []
            self.ctrls, self.reader, self.packages = [], None, []
            self.proc, self.proc_tail, self.first_error = None, [], None
            self.mirror_running, self.headless_running = False, False
            self.mirror_start_ts = 0.0
            self.timers, self._alive = [], True
            self._auto_started = ""
            self._auto_blocked = False
            self._auto_mirror_run = False

            self.overlay = {"enabled": bool(self.config.get("overlay_enabled", False)),
                            "color": list(self.config.get("overlay_color", [77, 124, 255])),
                            "opacity": float(self.config.get("overlay_opacity", 0.12)),
                            "blend": self.config.get("overlay_blend", "over"),
                            "brightness": float(self.config.get("overlay_brightness", 0.0)),
                            "saturation": float(self.config.get("overlay_saturation", 1.0)),
                            "auto": bool(self.config.get("overlay_auto", True)),
                            "clarity": float(self.config.get("overlay_clarity", 0.0)),
                            "exposure": float(self.config.get("overlay_exposure", 0.0))}
            for k in ("overlay_enabled", "overlay_color", "overlay_opacity",
                      "overlay_blend", "overlay_brightness", "overlay_saturation",
                      "overlay_auto", "overlay_clarity", "overlay_exposure"):
                self.config.setdefault(k, default_config().get(k, self.overlay.get(
                    k.replace("overlay_", ""), None)))
                if k == "overlay_color" and not isinstance(self.config[k], list):
                    self.config[k] = [77, 124, 255]
            self.smart_ov = None

            if os.path.isfile("/usr/share/padlink/padlink.svg"):
                try:
                    self.set_icon_from_file("/usr/share/padlink/padlink.svg")
                except Exception:
                    pass

            hdr = Gtk.HeaderBar()
            hdr.set_show_close_button(True)
            hdr.props.title = tr("app_title")
            hdr.props.subtitle = tr("app_subtitle") + "  v" + APP_VERSION
            self.set_titlebar(hdr)
            helpb = Gtk.Button.new_from_icon_name("help-about", Gtk.IconSize.BUTTON)
            helpb.set_tooltip_text(tr("btn_help"))
            helpb.connect("clicked", lambda _b: self.show_help())
            hdr.pack_end(helpb)

            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            self.add(vbox)
            body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            sidebar = Gtk.StackSidebar()
            self.stack = Gtk.Stack()
            self.stack.set_transition_type(Gtk.StackTransitionType.CROSSFADE)
            sidebar.set_stack(self.stack)
            body.pack_start(sidebar, False, False, 0)
            sc = Gtk.ScrolledWindow()
            sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sc.add(self.stack)
            body.pack_start(sc, True, True, 0)
            vbox.pack_start(body, True, True, 0)
            self.statusbar = Gtk.Label(xalign=0.0)
            self.statusbar.set_margin_start(10)
            self.statusbar.set_margin_end(10)
            self.statusbar.set_margin_top(4)
            self.statusbar.set_margin_bottom(4)
            vbox.pack_end(self.statusbar, False, False, 0)

            self.build_devices_page()
            self.build_screen_page()
            self.build_controller_page()
            self.build_apps_page()
            self.stack.connect("notify::visible-child", self.on_page_changed)
            self.connect("destroy", self.on_destroy)
            self.connect("key-press-event", self.on_key)
            self.refresh_async()
            self.timers.append(GLib.timeout_add(4000, self.periodic_refresh))
            self.timers.append(GLib.timeout_add(1000, self.watch_mirror))

        # ---------- helpers ----------
        def toast(self, m):
            if self._alive:
                self.statusbar.set_text(m)
                GLib.timeout_add(7000, self.clear_toast)

        def clear_toast(self):
            if self._alive:
                self.statusbar.set_text("")
            return False

        def color(self, t, c):
            return '<span color="%s"><b>%s</b></span>' % (c, GLib.markup_escape_text(t))

        def on_page_changed(self, _s, _p):
            if self.stack.get_visible_child_name() == "page_controller":
                self.refresh_ctrls_ui()
                # automatic smart calibration the first time the page opens:
                # re-measures the artwork and corrects every control position
                if not getattr(self, "_calibrated", False) and self.cc is not None:
                    self._calibrated = True
                    try:
                        cal = self.cc.auto_calibrate()
                        if cal:
                            self.cc.set_state(self._ctrl_state())
                            self.drawing.queue_draw()
                            self.toast(tr("autofix_calib_auto"))
                    except Exception:
                        pass

        def on_key(self, _w, ev):
            """Keyboard shortcuts:
            Ctrl+1..4 switch pages, Ctrl+Enter start mirror, F5 refresh."""
            try:
                key = ev.keyval
                ctrl = ev.state & Gdk.ModifierType.CONTROL_MASK
                if ctrl and key == Gdk.KEY_1:
                    self.stack.set_visible_child_name("page_devices"); return True
                if ctrl and key == Gdk.KEY_2:
                    self.stack.set_visible_child_name("page_screen"); return True
                if ctrl and key == Gdk.KEY_3:
                    self.stack.set_visible_child_name("page_controller"); return True
                if ctrl and key == Gdk.KEY_4:
                    self.stack.set_visible_child_name("page_apps"); return True
                if ctrl and key == Gdk.KEY_Return:
                    self.start_mirror(); return True
                if key == Gdk.KEY_F5:
                    self.refresh_async(force=True); return True
            except Exception:
                pass
            return False

        def icon_btn(self, icon, sym, handler, tip=None):
            b = Gtk.Button()
            try:
                if icon and Gtk.IconTheme.get_default().has_icon(icon):
                    b.add(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.BUTTON))
                else:
                    b.set_label(tr(sym, ""))
            except Exception:
                b.set_label(tr(sym, ""))
            b.connect("clicked", handler)
            if tip:
                b.set_tooltip_text(tr(tip))
            return b

        # ---------- Page 1: Devices ----------
        def build_devices_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            page.set_margin_top(12); page.set_margin_bottom(12)
            page.set_margin_start(12); page.set_margin_end(12)
            cols = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=12)

            pf = Gtk.Frame(label=tr("phone_frame"))
            pb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            pb.set_margin_top(8); pb.set_margin_bottom(8); pb.set_margin_start(10); pb.set_margin_end(10)
            self.phone_status = Gtk.Label(xalign=0.0)
            self.phone_list = Gtk.Label(xalign=0.0, selectable=True, wrap=True)
            self.phone_model = Gtk.Label(xalign=0.0, wrap=True, selectable=True)
            self.phone_android = Gtk.Label(xalign=0.0)
            self.phone_batt = Gtk.Label(xalign=0.0)
            hint = Gtk.Label(xalign=0.0, wrap=True)
            hint.set_markup('<span color="#888888" size="small">%s</span>' % tr("phone_hint"))
            rb = Gtk.Button(label=tr("phone_refresh"))
            rb.connect("clicked", lambda _b: self.refresh_async(force=True))
            for w in (self.phone_status, self.phone_list, self.phone_model,
                      self.phone_android, self.phone_batt, hint, rb):
                pb.pack_start(w, False, False, 0)
            pf.add(pb)

            cf = Gtk.Frame(label=tr("ctrl_frame"))
            cb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            cb.set_margin_top(8); cb.set_margin_bottom(8); cb.set_margin_start(10); cb.set_margin_end(10)
            self.ctrl_status = Gtk.Label(xalign=0.0)
            self.ctrl_name = Gtk.Label(xalign=0.0, wrap=True, selectable=True)
            self.ctrl_detail = Gtk.Label(xalign=0.0, wrap=True, selectable=True)
            ch = Gtk.Label(xalign=0.0, wrap=True)
            ch.set_markup('<span color="#888888" size="small">%s</span>' % tr("ctrl_hint"))
            for w in (self.ctrl_status, self.ctrl_name, self.ctrl_detail, ch):
                cb.pack_start(w, False, False, 0)
            cf.add(cb)

            cols.pack_start(pf, True, True, 0)
            cols.pack_start(cf, True, True, 0)
            page.pack_start(cols, True, True, 0)

            act = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            act.set_halign(Gtk.Align.CENTER)
            start = Gtk.Button(label=tr("btn_start"))
            start.get_style_context().add_class("suggested-action")
            start.connect("clicked", lambda _b: self.start_mirror())
            doctor = self.icon_btn("applications-engineering", "sym_doctor",
                                   lambda _b: self.run_doctor(), "btn_doctor")
            diagb = Gtk.Button(label=tr("diag_btn"))
            diagb.set_tooltip_text(tr("diag_help"))
            diagb.connect("clicked", lambda _b: self.run_diag())
            tips = Gtk.Button(label=tr("btn_tips"))
            tips.connect("clicked", lambda _b: self.show_tips())
            about = Gtk.Button(label=tr("btn_about"))
            about.connect("clicked", lambda _b: self.show_about())
            for b in (start, doctor, tips, about):
                act.pack_start(b, False, False, 0)
            page.pack_start(act, False, False, 0)
            self.stack.add_titled(page, "page_devices", tr("tab_devices"))

        # ---------- Page 2: Screen ----------
        def build_screen_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            r1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
            r1.set_margin_top(4); r1.set_margin_start(4); r1.set_margin_end(4)
            self.btn_start2 = self.icon_btn("media-playback-start", "sym_start",
                                            lambda _b: self.start_mirror(), "btn_start2")
            self.btn_stop = self.icon_btn("media-playback-stop", "sym_stop",
                                          lambda _b: self.stop_mirror(manual=True), "btn_stop")
            self.btn_stop.set_sensitive(False)
            fs = self.icon_btn("view-fullscreen", "sym_fullscreen",
                               lambda _b: self.toggle_fullscreen(), "btn_fullscreen")
            zi = self.icon_btn("zoom-in", "sym_zoom_in", lambda _b: self.zoom(1), "btn_zoom_in")
            zo = self.icon_btn("zoom-out", "sym_zoom_out", lambda _b: self.zoom(-1), "btn_zoom_out")
            fit = self.icon_btn("zoom-fit-best", "sym_fit", lambda _b: self.fit(), "btn_fit")
            rot = self.icon_btn("object-rotate-right", "sym_rotate",
                                lambda _b: self.rotate_screen(), "btn_rotate")
            shot = self.icon_btn("camera-photo", "sym_shot",
                                 lambda _b: self.screenshot(), "btn_screenshot")
            self.rec = Gtk.ToggleButton()
            self.rec.set_active(bool(self.config.get("record", False)))
            if Gtk.IconTheme.get_default().has_icon("media-record"):
                self.rec.add(Gtk.Image.new_from_icon_name("media-record", Gtk.IconSize.BUTTON))
            else:
                self.rec.set_label(tr("sym_record", ""))
            self.rec.set_tooltip_text(tr("btn_record"))
            self.rec.connect("toggled", self.on_rec)
            self.aud = Gtk.ToggleButton()
            self.aud.set_active(bool(self.config.get("audio", True)))
            if Gtk.IconTheme.get_default().has_icon("audio-volume-high"):
                self.aud.add(Gtk.Image.new_from_icon_name("audio-volume-high", Gtk.IconSize.BUTTON))
            else:
                self.aud.set_label(tr("sym_audio", ""))
            self.aud.set_tooltip_text(tr("audio_on") if self.config.get("audio") else tr("audio_off"))
            self.aud.connect("toggled", self.on_aud)
            self.stay = Gtk.ToggleButton()
            self.stay.set_active(bool(self.config.get("stay_awake", False)))
            if Gtk.IconTheme.get_default().has_icon("weather-clear-night"):
                self.stay.add(Gtk.Image.new_from_icon_name("weather-clear-night", Gtk.IconSize.BUTTON))
            else:
                self.stay.set_label(tr("sym_stay"))
            self.stay.set_tooltip_text(tr("stay_awake"))
            self.stay.connect("toggled", self.on_stay)
            st = self.icon_btn("preferences-system", "sym_settings",
                               lambda _b: self.settings_popover(_b), "btn_settings")
            for w in (self.btn_start2, self.btn_stop, fs, zi, zo, fit, rot, shot, self.rec, self.aud, self.stay, st):
                r1.pack_start(w, False, False, 0)
            page.pack_start(r1, False, False, 0)

            r2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
            r2.set_margin_start(4); r2.set_margin_end(4)
            for icon, sym, h, tip in (
                ("go-up", "sym_scroll_up", lambda _b: self.scroll("up"), "btn_scroll_up"),
                ("go-down", "sym_scroll_down", lambda _b: self.scroll("down"), "btn_scroll_down"),
                ("input-mouse", "sym_focus", lambda _b: self.focus_video(), "btn_focus"),
                ("go-home", "sym_home", lambda _b: self.keyev(K_HOME), "btn_home"),
                ("go-previous", "sym_back", lambda _b: self.keyev(K_BACK), "btn_back"),
                ("view-grid", "sym_recents", lambda _b: self.keyev(K_APP), "btn_recents"),
                ("audio-volume-high", "sym_vol_up", lambda _b: self.keyev(K_VOLUP), "btn_vol_up"),
                ("audio-volume-low", "sym_vol_down", lambda _b: self.keyev(K_VOLDOWN), "btn_vol_down"),
                ("system-shutdown", "sym_power", lambda _b: self.keyev(K_POWER), "btn_power"),
            ):
                r2.pack_start(self.icon_btn(icon, sym, h, tip), False, False, 0)
            page.pack_start(r2, False, False, 0)

            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup('<span color="#888888" size="small">%s</span>' % tr("scroll_note"))
            note.set_margin_start(6)
            page.pack_start(note, False, False, 0)

            # Overlay (tint) panel - works over the standalone window via a
            # small preview note; kept as advanced option.
            ex = Gtk.Expander(label=tr("overlay_title"))
            ob = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            ob.set_margin_start(10); ob.set_margin_end(10); ob.set_margin_bottom(6)

            r0 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            self.ov_sw = Gtk.Switch(); self.ov_sw.set_active(self.overlay["enabled"])
            self.ov_sw.connect("notify::active", self.on_ov)
            b0 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            b0.pack_start(Gtk.Label(label=tr("overlay_enable")), False, False, 0)
            b0.pack_start(self.ov_sw, False, False, 0)
            r0.pack_start(b0, False, False, 0)
            self.ov_auto = Gtk.Switch(); self.ov_auto.set_active(self.overlay.get("auto", True))
            self.ov_auto.connect("notify::active", self.on_ov_auto)
            b1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            b1.pack_start(Gtk.Label(label=tr("overlay_auto")), False, False, 0)
            b1.pack_start(self.ov_auto, False, False, 0)
            r0.pack_start(b1, False, False, 0)
            ob.pack_start(r0, False, False, 0)

            r1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            self.ov_color = Gtk.ColorButton()
            rgba = Gdk.RGBA(); rgba.red = self.overlay["color"][0]/255.0
            rgba.green = self.overlay["color"][1]/255.0; rgba.blue = self.overlay["color"][2]/255.0; rgba.alpha = 1
            self.ov_color.set_rgba(rgba)
            self.ov_color.connect("color-set", self.on_ov_color)
            r1.pack_start(Gtk.Label(label=tr("overlay_color")), False, False, 0)
            r1.pack_start(self.ov_color, False, False, 0)
            ob.pack_start(r1, False, False, 0)

            r2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            r2.pack_start(Gtk.Label(label=tr("overlay_opacity")), False, False, 0)
            self.ov_op = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.ov_op.set_range(0, 100); self.ov_op.set_value(self.overlay["opacity"] * 100.0)
            self.ov_op.set_size_request(150, -1); self.ov_op.set_draw_value(True)
            self.ov_op.connect("value-changed", self.on_ov_opacity)
            r2.pack_start(self.ov_op, True, True, 0)
            ob.pack_start(r2, False, False, 0)

            r3 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            r3.pack_start(Gtk.Label(label=tr("overlay_clarity")), False, False, 0)
            self.ov_cl = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.ov_cl.set_range(0, 100); self.ov_cl.set_value(self.overlay.get("clarity", 0.0) * 100.0)
            self.ov_cl.set_size_request(150, -1); self.ov_cl.set_draw_value(True)
            self.ov_cl.connect("value-changed", self.on_ov_clarity)
            r3.pack_start(self.ov_cl, True, True, 0)
            ob.pack_start(r3, False, False, 0)

            r4 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            r4.pack_start(Gtk.Label(label=tr("overlay_exposure")), False, False, 0)
            self.ov_ex = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.ov_ex.set_range(-50, 50); self.ov_ex.set_value(self.overlay.get("exposure", 0.0) * 100.0)
            self.ov_ex.set_size_request(150, -1); self.ov_ex.set_draw_value(True)
            self.ov_ex.connect("value-changed", self.on_ov_exposure)
            r4.pack_start(self.ov_ex, True, True, 0)
            ob.pack_start(r4, False, False, 0)

            ovn = Gtk.Label(xalign=0.0, wrap=True)
            ovn.set_markup('<span color="#888888" size="small">%s</span>' % tr("ov_note"))
            ob.pack_start(ovn, False, False, 0)
            ex.add(ob)
            page.pack_start(ex, False, False, 0)

            ph = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
            ph.set_valign(Gtk.Align.CENTER); ph.set_halign(Gtk.Align.CENTER)
            self.ph_label = Gtk.Label(wrap=True)
            self.ph_label.set_markup('<span size="x-large">%s</span>' % tr("scr_placeholder"))
            self.dl_btn = Gtk.Button(label=tr("scr_download"))
            self.dl_btn.connect("clicked", lambda _b: self.bundle_note())
            self.dl_btn.set_no_show_all(True); self.dl_btn.hide()
            ph.pack_start(self.ph_label, False, False, 0)
            ph.pack_start(self.dl_btn, False, False, 0)
            self.screen_holder = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
            self.screen_holder.set_hexpand(True); self.screen_holder.set_vexpand(True)
            self.screen_holder.pack_start(ph, True, True, 0)
            page.pack_start(self.screen_holder, True, True, 0)

            self.scr_status = Gtk.Label(xalign=0.0)
            self.scr_status.set_margin_start(8); self.scr_status.set_margin_bottom(2)
            page.pack_start(self.scr_status, False, False, 0)
            self.stack.add_titled(page, "page_screen", tr("tab_screen"))
            self.update_placeholder()

        def update_placeholder(self):
            p = find_scrcpy()
            self.dl_btn.hide()
            if p is None:
                self.ph_label.set_markup('<span size="x-large">%s</span>' % tr("scr_placeholder"))
            else:
                self.ph_label.set_markup(
                    '<span size="x-large">%s</span>\n<span color="#2e7d32" size="small">%s</span>'
                    % (tr("scr_placeholder"), tr("bundled_ok")))

        def bundle_note(self):
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.WARNING,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("bundle_missing_title"))
            d.format_secondary_text(tr("bundle_missing"))
            d.run(); d.destroy()

        # ---------- Page 3: Controller (any gamepad, real artwork) ----------
        # The drawing area shows the USER'S OWN controller photos extracted
        # as a transparent shape (no background), with live glow effects,
        # stick motion, trigger fill and guide pulse on top, at positions
        # measured from that exact artwork (see padlink_controller.py).

        def controller_family(self, name):
            return "\u0625\u0643\u0633 \u0628\u0648\u0643\u0633 360"


        def build_controller_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            page.set_margin_top(8); page.set_margin_bottom(8)
            page.set_margin_start(10); page.set_margin_end(10)

            # Top bar: dropdown of ALL detected controllers + auto-detect.
            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            top.pack_start(Gtk.Label(label=tr("ctrl_select")), False, False, 0)
            self.ctrl_combo = Gtk.ComboBoxText(); self.ctrl_combo.set_size_request(400, -1)
            self.ctrl_combo.connect("changed", self.on_ctrl_changed)
            top.pack_start(self.ctrl_combo, True, True, 0)
            detect = Gtk.Button(label=tr("ctrl_autodetect"))
            detect.set_tooltip_text(tr("help_autodetect"))
            detect.connect("clicked", lambda _b: self.auto_detect())
            top.pack_start(detect, False, False, 0)
            refresh = self.icon_btn("view-refresh", "sym_refresh",
                                    lambda _b: self.refresh_ctrls_ui(), "ctrl_refresh")
            top.pack_start(refresh, False, False, 0)
            autofix = Gtk.Button(label=tr("autofix_btn"))
            autofix.set_tooltip_text(tr("autofix_help"))
            autofix.get_style_context().add_class("suggested-action")
            autofix.connect("clicked", self.auto_fix)
            top.pack_start(autofix, False, False, 0)
            vibrate = self.icon_btn("audio-volume-high", "sym_vibrate",
                                    lambda _b: self.do_vibrate(), "ctrl_vibrate")
            top.pack_start(vibrate, False, False, 0)
            page.pack_start(top, False, False, 0)

            # Family name label (updates with the chosen controller).
            self.fam_label = Gtk.Label(xalign=0.0, selectable=True)
            self.fam_label.set_markup('<span color="#888888" size="small">%s</span>' % tr("ctrl_family"))
            page.pack_start(self.fam_label, False, False, 0)

            # Switches: forward + vibration enable
            sw = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=18)
            self.fwd_sw = Gtk.Switch(); self.fwd_sw.set_active(bool(self.config.get("forward_enabled", True)))
            self.fwd_sw.connect("notify::active", lambda s, p: self.on_fwd())
            b1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            b1.pack_start(Gtk.Label(label=tr("fwd_switch")), False, False, 0)
            b1.pack_start(self.fwd_sw, False, False, 0)
            self.vib_sw = Gtk.Switch(); self.vib_sw.set_active(bool(self.config.get("vibration_enabled", True)))
            self.vib_sw.connect("notify::active", lambda s, p: self.on_vib())
            b2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            b2.pack_start(Gtk.Label(label=tr("vib_switch")), False, False, 0)
            b2.pack_start(self.vib_sw, False, False, 0)
            sw.pack_start(b1, False, False, 0); sw.pack_start(b2, False, False, 0)
            page.pack_start(sw, False, False, 0)

            frame = Gtk.Frame(label=tr("ctrl_diagram"))
            self.drawing = Gtk.DrawingArea()
            self.drawing.set_size_request(620, 440)
            self.drawing.set_hexpand(True); self.drawing.set_vexpand(True)
            self.drawing.connect("draw", self.draw_controller)
            frame.add(self.drawing)
            page.pack_start(frame, True, True, 0)
            # Artwork module: the user's own controller shape + live effects.
            self.cc = _pc.PadLinkController() if _pc is not None else None
            self._cc_last = time.time()
            self.timers.append(GLib.timeout_add(33, self.on_cc_tick))

            self.axis_lbl = Gtk.Label(xalign=0.0, selectable=True)
            page.pack_start(self.axis_lbl, False, False, 0)

            # Vibration settings
            vf = Gtk.Frame(label=tr("ctrl_vibrate"))
            vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            vb.set_margin_top(6); vb.set_margin_bottom(6); vb.set_margin_start(8); vb.set_margin_end(8)
            vr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            vr.pack_start(Gtk.Label(label=tr("ctrl_vib_intensity")), False, False, 0)
            self.vib_i = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.vib_i.set_range(0, 100); self.vib_i.set_value(float(self.config.get("vibration", 100)))
            self.vib_i.set_size_request(160, -1); self.vib_i.set_draw_value(True)
            self.vib_i.connect("value-changed", lambda s: self.cfg("vibration", int(s.get_value())))
            vr.pack_start(self.vib_i, True, True, 0)
            vr.pack_start(Gtk.Label(label=tr("ctrl_vib_duration")), False, False, 0)
            self.vib_ms = Gtk.SpinButton.new_with_range(100, 2000, 100)
            self.vib_ms.set_value(float(self.config.get("vibration_ms", 400)))
            self.vib_ms.connect("value-changed", lambda s: self.cfg("vibration_ms", int(s.get_value())))
            vr.pack_start(self.vib_ms, False, False, 0)
            t = Gtk.Button(label=tr("ctrl_vibrate"))
            t.connect("clicked", lambda _b: self.do_vibrate())
            vr.pack_start(t, False, False, 0)
            vb.pack_start(vr, False, False, 0)
            vf.add(vb)
            page.pack_start(vf, False, False, 0)

            # Deadzone + calibration
            dff = Gtk.Frame(label=tr("ctrl_deadzone"))
            db = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            db.set_margin_top(6); db.set_margin_bottom(6); db.set_margin_start(8); db.set_margin_end(8)
            dr = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            dr.pack_start(Gtk.Label(label=tr("ctrl_deadzone")), False, False, 0)
            self.dz = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.dz.set_range(0, 50); self.dz.set_value(float(self.config.get("deadzone", 8)))
            self.dz.set_size_request(160, -1); self.dz.set_draw_value(True)
            self.dz.connect("value-changed", lambda s: self.cfg("deadzone", int(s.get_value())))
            dr.pack_start(self.dz, True, True, 0)
            rc = Gtk.Button(label=tr("ctrl_recenter"))
            rc.connect("clicked", lambda _b: self.recenter())
            rs = Gtk.Button(label=tr("ctrl_reset_cal"))
            rs.connect("clicked", lambda _b: self.reset_cal())
            dr.pack_start(rc, False, False, 0); dr.pack_start(rs, False, False, 0)
            db.pack_start(dr, False, False, 0)
            dff.add(db)
            page.pack_start(dff, False, False, 0)

            n = Gtk.Label(xalign=0.0, wrap=True)
            n.set_markup('<span color="#888888" size="small">%s</span>' % tr("ctrl_fw"))
            page.pack_start(n, False, False, 0)
            self.stack.add_titled(page, "page_controller", tr("tab_controller"))
            self.refresh_ctrls_ui()

        def cfg(self, k, v):
            self.config[k] = v
            save_config(self.config)

        def auto_fix(self, _b=None):
            """SMART AUTO-CORRECTION: checks the kernel driver (xpad), udev
            rules, permissions, adb and the connected controller, then
            re-measures the artwork and corrects every control position."""
            if getattr(self, "_autofix_running", False):
                return
            self._autofix_running = True
            self.toast(tr("autofix_running"))
            threading.Thread(target=self.auto_fix_worker, daemon=True).start()

        def auto_fix_worker(self):
            report = []
            def add(txt, ok=True):
                report.append((txt, ok))
            def run_priv(cmd):
                # works both when the app runs as root and via passwordless sudo
                if os.geteuid() == 0:
                    return run_cmd(cmd, 8)
                return run_cmd(["sudo", "-n"] + cmd, 8)
            # 1) kernel drivers (expertise from xpad/xboxdrv: load/reload)
            modprobe = shutil.which("modprobe")
            for mod in ("uinput", "joydev", "xpad"):
                rc, _, _ = run_cmd(["sh", "-c", "lsmod | grep -q '^%s '" % mod], 4)
                if rc == 0:
                    add(tr("autofix_already") % mod)
                elif modprobe is None:
                    add(tr("autofix_nokmod") % mod, False)
                else:
                    rc2, _, _ = run_priv(["modprobe", mod])
                    if rc2 == 0:
                        add(tr("autofix_loaded") % mod)
                    else:
                        add(tr("autofix_need_root") % mod, False)
            # 2) if the driver is up but no controller is seen: reload xpad
            if not detect_controllers() and modprobe is not None:
                run_priv(["sh", "-c",
                          "modprobe -r xpad 2>/dev/null; modprobe xpad 2>/dev/null"])
                time.sleep(1.0)
            # 3) udev rules (always rewrite the correct rule - the old one
            #    with '|' alternation never matched any device)
            rules = "/usr/share/padlink/51-padlink-android.rules"
            dst = "/etc/udev/rules.d/51-padlink-android.rules"
            try:
                if os.path.isfile(rules):
                    run_priv(["sh", "-c",
                              "mkdir -p /etc/udev/rules.d && cp -f '%s' '%s'" % (rules, dst)])
                if os.path.isfile(dst):
                    try:
                        os.chmod(dst, 0o644)
                    except Exception:
                        run_priv(["chmod", "644", dst])
                add(tr("autofix_udev_ok"))
            except Exception:
                add(tr("autofix_udev_need_root"), False)
            rc, _, _ = run_priv(["udevadm", "control", "--reload-rules"])
            run_priv(["udevadm", "trigger"])
            if rc == 0:
                add(tr("autofix_udev_reload"))
            # immediate permissions (no replug needed)
            for ev in glob.glob("/dev/input/event*") + glob.glob("/dev/input/js*") + ["/dev/uinput"]:
                try:
                    if os.access(ev, os.R_OK) and os.access(ev, os.W_OK):
                        continue
                    run_priv(["chmod", "666", ev])
                except Exception:
                    pass
            # input group membership check
            rc2, out, _ = run_cmd(["sh", "-c", "id -nG | tr ' ' '\n' | grep -qx input"], 4)
            if rc2 != 0:
                add(tr("autofix_input_group"), False)
            # 4) adb restart
            run_cmd(adb_cmd(["kill-server"]), 6)
            run_cmd(adb_cmd(["start-server"]), 6)
            add(tr("autofix_adb"))
            # 6) connected controller? re-check readability AFTER the fixes
            ctrls = detect_controllers()
            readable = [c for c in ctrls if c.get("readable")]
            if ctrls:
                add(tr("autofix_ctrl") % ctrls[0]["name"])
                if readable:
                    add(tr("autofix_readable") % readable[0]["name"])
                else:
                    add(tr("autofix_still_unreadable"), False)
            else:
                add(tr("autofix_no_ctrl"), False)
            # 7) smart artwork calibration (measures the real buttons)
            if self.cc is not None:
                try:
                    cal = self.cc.auto_calibrate()
                    for c in cal:
                        add(tr("autofix_calib") % c)
                    self.cc.set_state(self._ctrl_state())
                except Exception:
                    pass
            GLib.idle_add(self._apply_autofix, report)

        def _apply_autofix(self, report):
            self._autofix_running = False
            self.refresh_ctrls_ui()
            self.drawing.queue_draw()
            self.toast(tr("autofix_done"))
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("autofix_title"))
            lines = []
            for txt, ok in report:
                lines.append("\u2022 [%s] %s" % ("OK" if ok else "!", txt))
            d.format_secondary_text(tr("autofix_intro") + "\n\n" + "\n".join(lines))
            d.run(); d.destroy()

        def auto_detect(self):
            """Rescan and auto-select the first readable controller."""
            self.refresh_ctrls_ui()
            for i, c in enumerate(self.ctrls):
                if c.get("readable"):
                    self.ctrl_combo.set_active(i)
                    self.toast(tr("ctrl_autodetect_ok") + " " + c["name"])
                    return
            self.toast(tr("ctrl_no_dev"))

        def refresh_ctrls_ui(self):
            self.ctrls = detect_controllers()
            prev = self.ctrl_combo.get_active_id()
            self.ctrl_combo.handler_block_by_func(self.on_ctrl_changed)
            self.ctrl_combo.remove_all()
            if not self.ctrls:
                self.ctrl_combo.append("", tr("ctrl_no_dev")); self.ctrl_combo.set_active(0)
            else:
                for c in self.ctrls:
                    fam = self.controller_family(c["name"])
                    label = "%s  [%s]  (%s)" % (c["name"], os.path.basename(c["path"]), fam)
                    self.ctrl_combo.append(c["path"], label)
                if prev:
                    self.ctrl_combo.set_active_id(prev)
                if not self.ctrl_combo.get_active_id():
                    # auto-select first readable
                    idx = next((i for i, c in enumerate(self.ctrls) if c.get("readable")), 0)
                    self.ctrl_combo.set_active(idx)
            self.ctrl_combo.handler_unblock_by_func(self.on_ctrl_changed)
            self.on_ctrl_changed(self.ctrl_combo)

        def on_ctrl_changed(self, combo):
            if self.reader:
                self.reader.stop(); self.reader = None
            path = combo.get_active_id()
            if not path:
                self.ctrl_name.set_text(tr("ctrl_no_dev")); self.axis_lbl.set_text("")
                self.fam_label.set_text("")
                self.drawing.queue_draw(); return
            sel = next((c for c in self.ctrls if c["path"] == path), None)
            if not sel:
                return
            self.ctrl_name.set_text("%s %s" % (tr("ctrl_name"), sel["name"]))
            fam = self.controller_family(sel["name"])
            self.fam_label.set_markup('<span color="#2e7d32"><b>%s</b></span>' % GLib.markup_escape_text(
                tr("ctrl_family") + " " + fam))
            det = []
            if sel.get("vendor"):
                det.append("Vendor=0x%04x Product=0x%04x" % (sel["vendor"], sel["product"]))
            if sel.get("buttons"):
                det.append("%s %d | %s %d" % (tr("ctrl_btns"), sel["buttons"],
                                              tr("ctrl_axes"), sel["axes"]))
            self.ctrl_detail.set_text(" | ".join(det))
            if sel["readable"] and "event" in os.path.basename(path):
                self.reader = GamepadReader(path, self.on_gp)
                self.reader.start()
                self.axis_lbl.set_text(tr("ctrl_reading"))
            else:
                self.axis_lbl.set_text(tr("ctrl_perm"))
            self.drawing.queue_draw()

        def on_fwd(self):
            self.cfg("forward_enabled", self.fwd_sw.get_active())
            self.toast(tr("fwd_on") if self.fwd_sw.get_active() else tr("fwd_off"))

        def on_vib(self):
            self.cfg("vibration_enabled", self.vib_sw.get_active())
            self.toast(tr("vib_on") if self.vib_sw.get_active() else tr("vib_off"))

        def do_vibrate(self):
            if not self.config.get("vibration_enabled", True):
                self.toast(tr("vib_disabled_note")); return
            p = self.ctrl_combo.get_active_id()
            if not p:
                return
            ok = test_rumble(p, int(self.config.get("vibration", 100)),
                             int(self.config.get("vibration_ms", 400)))
            self.toast(tr("ctrl_vib_sent").format(pct=int(self.config.get("vibration", 100)),
                                                  ms=int(self.config.get("vibration_ms", 400)))
                       if ok else tr("ctrl_vibrate_fail"))

        def recenter(self):
            if self.reader is None:
                return
            import evdev
            _, axes, rng = self.reader.state()
            self.reader.offsets = {c: self.norm(axes.get(c, 0), rng.get(c), 0.0)
                                   for c in (evdev.ecodes.ABS_X, evdev.ecodes.ABS_Y,
                                             evdev.ecodes.ABS_RX, evdev.ecodes.ABS_RY)}
            self.toast(tr("ctrl_cal_done"))

        def reset_cal(self):
            if self.reader:
                self.reader.offsets = {}
            self.toast(tr("ctrl_cal_reset"))

        def norm(self, v, rng, dz):
            if not rng:
                return 0.0
            mn, mx = rng
            half = (mx - mn) / 2.0
            if half == 0:
                return 0.0
            x = (v - (mn + mx) / 2.0) / half
            return 0.0 if abs(x) < dz else clamp(x)

        def on_gp(self):
            self.drawing.queue_draw()
            try:
                import evdev
            except Exception:
                return
            if self.reader is None:
                return
            b, a, rng = self.reader.state()
            dz = self.config.get("deadzone", 8) / 100.0
            lx = self.norm(a.get(evdev.ecodes.ABS_X, 0), rng.get(evdev.ecodes.ABS_X), dz)
            ly = self.norm(a.get(evdev.ecodes.ABS_Y, 0), rng.get(evdev.ecodes.ABS_Y), dz)
            rx = self.norm(a.get(evdev.ecodes.ABS_RX, 0), rng.get(evdev.ecodes.ABS_RX), dz)
            ry = self.norm(a.get(evdev.ecodes.ABS_RY, 0), rng.get(evdev.ecodes.ABS_RY), dz)
            lt = self.norm(a.get(evdev.ecodes.ABS_Z, 0), rng.get(evdev.ecodes.ABS_Z), 0.0)
            rt = self.norm(a.get(evdev.ecodes.ABS_RZ, 0), rng.get(evdev.ecodes.ABS_RZ), 0.0)
            self.axis_lbl.set_text(tr("axis_readout").format(lx=lx, ly=ly, rx=rx, ry=ry, lt=lt, rt=rt))

        def _ctrl_state(self):
            """Current evdev state -> ControllerState for the artwork module."""
            st = _pc.ControllerState()
            if self.reader is None:
                return st
            b, a, rng = self.reader.state()
            try:
                import evdev
                E = evdev.ecodes
            except Exception:
                E = None
            def btn(n):
                if E is None:
                    return False
                c = getattr(E, n, -1)
                return c != -1 and b.get(c, 0) == 1
            st.A = btn("BTN_SOUTH"); st.B = btn("BTN_EAST")
            st.X = btn("BTN_WEST"); st.Y = btn("BTN_NORTH")
            st.LB = btn("BTN_TL"); st.RB = btn("BTN_TR")
            st.Xbox = btn("BTN_MODE")
            st.View = btn("BTN_SELECT"); st.Menu = btn("BTN_START")
            st.Share = btn("BTN_TRIGGER_HAPPY3")
            st.LS = btn("BTN_THUMBL"); st.RS = btn("BTN_THUMBR")
            def axis01(n, dmin, dmax):
                if E is None:
                    return 0.0
                c = getattr(E, n, -1)
                if c == -1:
                    return 0.0
                r = rng.get(c)
                mn, mx = r if r else (dmin, dmax)
                v = a.get(c, mn)
                return clamp((v - mn) / max(1.0, mx - mn), 0.0, 1.0)
            st.LT = axis01("ABS_Z", 0, 255) or axis01("ABS_BRAKE", 0, 255) or (1.0 if btn("BTN_TL2") else 0.0)
            st.RT = axis01("ABS_RZ", 0, 255) or axis01("ABS_GAS", 0, 255) or (1.0 if btn("BTN_TR2") else 0.0)
            dz = self.config.get("deadzone", 8) / 100.0
            def stick(n):
                if E is None:
                    return 0.0
                c = getattr(E, n, -1)
                if c == -1:
                    return 0.0
                return self.norm(a.get(c, 0), rng.get(c), dz)
            st.LX = stick("ABS_X"); st.LY = stick("ABS_Y")
            st.RX = stick("ABS_RX"); st.RY = stick("ABS_RY")
            hx = a.get(getattr(E, "ABS_HAT0X", -1) if E else -1, 0)
            hy = a.get(getattr(E, "ABS_HAT0Y", -1) if E else -1, 0)
            has_hat = E is not None and (getattr(E, "ABS_HAT0X", -1) in rng or getattr(E, "ABS_HAT0Y", -1) in rng)
            if has_hat:
                st.DU = hy == -1; st.DD = hy == 1
                st.DL = hx == -1; st.DR = hx == 1
            else:
                st.DU = btn("BTN_DPAD_UP"); st.DD = btn("BTN_DPAD_DOWN")
                st.DL = btn("BTN_DPAD_LEFT"); st.DR = btn("BTN_DPAD_RIGHT")
            return st

        def _theme_bg(self, wdg):
            """Best-effort theme background color (no deprecated API)."""
            try:
                ctx = wdg.get_style_context()
                col = Gdk.RGBA()
                if ctx.lookup_color("theme_bg_color", col):
                    if col.alpha > 0.01:
                        return col
                # fallback: walk parents with the same safe lookup
                p = wdg.get_parent()
                while p is not None:
                    c2 = Gdk.RGBA()
                    if p.get_style_context().lookup_color("theme_bg_color", c2) and c2.alpha > 0.01:
                        return c2
                    p = p.get_parent()
            except Exception:
                pass
            return None

        def on_cc_tick(self):
            """Animation loop: guide pulse + easing of sticks/triggers/glows."""
            if not self._alive:
                return False
            if self.stack.get_visible_child_name() == "page_controller" and self.cc is not None:
                now = time.time()
                dt = min(0.1, now - getattr(self, "_cc_last", now))
                self._cc_last = now
                self.cc.update(dt)
                self.drawing.queue_draw()
            return True

        def draw_controller(self, wdg, cr):
            """Draw the USER'S controller artwork (transparent shape, no
            image background) with live effects on top."""
            if _pc is None:
                return
            al = wdg.get_allocation()
            W, H = al.width, al.height
            if W <= 0 or H <= 0:
                return
            if self.cc is None:
                self.cc = _pc.PadLinkController()
            # Clean page background (theme color only - the shape has none).
            col = self._theme_bg(wdg)
            if col is not None:
                cr.set_source_rgba(col.red, col.green, col.blue, col.alpha)
            else:
                cr.set_source_rgb(0.94, 0.94, 0.94)
            cr.paint()
            self.cc.set_state(self._ctrl_state())
            self.cc.draw(cr, W, H)

        # ---------- Page 4: Apps (headless control) ----------
        def build_apps_page(self):
            page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
            page.set_margin_top(8); page.set_margin_bottom(8)
            page.set_margin_start(10); page.set_margin_end(10)

            top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            self.app_search = Gtk.SearchEntry()
            self.app_search.set_placeholder_text(tr("apps_search"))
            self.app_search.set_size_request(220, -1)
            self.app_search.connect("search-changed", lambda e: self.filter_apps())
            top.pack_start(self.app_search, False, False, 0)
            reload = Gtk.Button(label=tr("apps_refresh"))
            reload.connect("clicked", lambda _b: self.load_apps())
            top.pack_start(reload, False, False, 0)
            launch = Gtk.Button(label=tr("apps_launch"))
            launch.get_style_context().add_class("suggested-action")
            launch.connect("clicked", lambda _b: self.launch_selected())
            top.pack_start(launch, False, False, 0)
            stopb = Gtk.Button(label=tr("apps_stop"))
            stopb.connect("clicked", lambda _b: self.stop_selected())
            top.pack_start(stopb, False, False, 0)
            openb = Gtk.Button(label=tr("apps_open_file"))
            openb.connect("clicked", lambda _b: self.open_file_dialog())
            top.pack_start(openb, False, False, 0)
            urlb = Gtk.Button(label=tr("apps_open_url"))
            urlb.connect("clicked", lambda _b: self.open_url_dialog())
            top.pack_start(urlb, False, False, 0)
            wakeb = Gtk.Button(label=tr("apps_wake"))
            wakeb.connect("clicked", lambda _b: (wake_phone(), self.toast(tr("apps_waked"))))
            top.pack_start(wakeb, False, False, 0)
            lockb = Gtk.Button(label=tr("apps_lock"))
            lockb.connect("clicked", lambda _b: (lock_phone(), self.toast(tr("apps_locked"))))
            top.pack_start(lockb, False, False, 0)
            page.pack_start(top, False, False, 0)

            info = Gtk.Label(xalign=0.0, wrap=True)
            info.set_markup('<span color="#888888" size="small">%s</span>' % tr("apps_note"))
            page.pack_start(info, False, False, 0)

            sc = Gtk.ScrolledWindow()
            sc.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
            sc.set_size_request(-1, 240)
            self.app_list = Gtk.ListBox()
            self.app_list.set_selection_mode(Gtk.SelectionMode.SINGLE)
            self.app_list.connect("row-activated", lambda lb, row: self.launch_selected())
            sc.add(self.app_list)
            page.pack_start(sc, True, True, 0)

            # Headless control panel
            hf = Gtk.Frame(label=tr("headless_title"))
            hb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            hb.set_margin_top(6); hb.set_margin_bottom(6); hb.set_margin_start(8); hb.set_margin_end(8)
            row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            self.headless_btn = Gtk.ToggleButton(label=tr("headless_start"))
            self.headless_btn.connect("toggled", self.on_headless)
            row.pack_start(self.headless_btn, False, False, 0)
            self.screenoff_sw = Gtk.Switch()
            self.screenoff_sw.set_active(bool(self.config.get("headless_screen_off", False)))
            self.screenoff_sw.connect("notify::active", lambda s, p: self.cfg("headless_screen_off", self.screenoff_sw.get_active()))
            b3 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            b3.pack_start(Gtk.Label(label=tr("headless_screen_off")), False, False, 0)
            b3.pack_start(self.screenoff_sw, False, False, 0)
            row.pack_start(b3, False, False, 0)
            hb.pack_start(row, False, False, 0)
            hn = Gtk.Label(xalign=0.0, wrap=True)
            hn.set_markup('<span color="#888888" size="small">%s</span>' % tr("headless_note"))
            hb.pack_start(hn, False, False, 0)
            hf.add(hb)
            page.pack_start(hf, False, False, 0)

            # Control pad (tap/scroll/text/nav) - works while headless OR with mirror
            cf2 = Gtk.Frame(label=tr("headless_pad"))
            cb2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
            cb2.set_margin_top(6); cb2.set_margin_bottom(6); cb2.set_margin_start(8); cb2.set_margin_end(8)
            tr1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            self.tap_x = Gtk.SpinButton.new_with_range(0, 4000, 10); self.tap_x.set_value(540)
            self.tap_y = Gtk.SpinButton.new_with_range(0, 8000, 10); self.tap_y.set_value(1200)
            tb = Gtk.Button(label=tr("pad_tap"))
            tb.connect("clicked", lambda _b: self.do_tap())
            tr1.pack_start(Gtk.Label(label="X"), False, False, 0)
            tr1.pack_start(self.tap_x, False, False, 0)
            tr1.pack_start(Gtk.Label(label="Y"), False, False, 0)
            tr1.pack_start(self.tap_y, False, False, 0)
            tr1.pack_start(tb, False, False, 0)
            cb2.pack_start(tr1, False, False, 0)
            tr2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            self.text_entry = Gtk.Entry(); self.text_entry.set_placeholder_text(tr("pad_text_hint"))
            self.text_entry.set_hexpand(True)
            tb2 = Gtk.Button(label=tr("pad_send_text"))
            tb2.connect("clicked", lambda _b: self.do_text())
            tr2.pack_start(self.text_entry, True, True, 0)
            tr2.pack_start(tb2, False, False, 0)
            cb2.pack_start(tr2, False, False, 0)
            tr3 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=4)
            for lbl, fn in (("home", lambda: self.keyev(K_HOME)),
                            ("back", lambda: self.keyev(K_BACK)),
                            ("recents", lambda: self.keyev(K_APP)),
                            ("vol+", lambda: self.keyev(K_VOLUP)),
                            ("vol-", lambda: self.keyev(K_VOLDOWN)),
                            ("power", lambda: self.keyev(K_POWER)),
                            ("scroll\u2191", lambda: self.scroll("up")),
                            ("scroll\u2193", lambda: self.scroll("down"))):
                b = Gtk.Button(label=lbl)
                b.connect("clicked", lambda _b, f=fn: f())
                tr3.pack_start(b, False, False, 0)
            cb2.pack_start(tr3, False, False, 0)
            # Volume + brightness sliders (work headless or with mirror)
            tr4 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
            tr4.pack_start(Gtk.Label(label=tr("pad_volume")), False, False, 0)
            self.vol_sl = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.vol_sl.set_range(0, 100); self.vol_sl.set_value(70)
            self.vol_sl.set_size_request(140, -1); self.vol_sl.set_draw_value(True)
            self.vol_sl.connect("value-changed", lambda s: set_volume(int(s.get_value())))
            tr4.pack_start(self.vol_sl, True, True, 0)
            tr4.pack_start(Gtk.Label(label=tr("pad_brightness")), False, False, 0)
            self.bri_sl = Gtk.Scale(orientation=Gtk.Orientation.HORIZONTAL)
            self.bri_sl.set_range(0, 255); self.bri_sl.set_value(150)
            self.bri_sl.set_size_request(140, -1); self.bri_sl.set_draw_value(True)
            self.bri_sl.connect("value-changed", lambda s: set_brightness(int(s.get_value())))
            tr4.pack_start(self.bri_sl, True, True, 0)
            cb2.pack_start(tr4, False, False, 0)
            cf2.add(cb2)
            page.pack_start(cf2, False, False, 0)

            self.stack.add_titled(page, "page_apps", tr("tab_apps"))
            self.load_apps()

        def load_apps(self):
            self.packages = list_packages()
            self.filter_apps()
            self.toast(tr("apps_loaded") + " %d" % len(self.packages))

        def filter_apps(self):
            q = self.app_search.get_text().strip().lower()
            self._clear_list()
            for p in self.packages:
                if q and q not in p.lower():
                    continue
                short = p.split(".")[-1] if "." in p else p
                row = Gtk.ListBoxRow()
                bx = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
                bx.set_margin_top(3); bx.set_margin_bottom(3); bx.set_margin_start(8); bx.set_margin_end(8)
                name_lbl = Gtk.Label(label=short, xalign=0.0, hexpand=True)
                pkg_lbl = Gtk.Label(label=p, xalign=1.0, selectable=True)
                pkg_lbl.set_markup('<span color="#888888" size="small">%s</span>' % GLib.markup_escape_text(p))
                run_b = Gtk.Button(label=tr("sym_start"))
                run_b.set_tooltip_text(tr("apps_launch"))
                run_b.connect("clicked", lambda _b, pkg=p: self.launch_pkg(pkg))
                stop_b = Gtk.Button(label=tr("sym_stop"))
                stop_b.set_tooltip_text(tr("apps_stop"))
                stop_b.connect("clicked", lambda _b, pkg=p: self.stop_pkg(pkg))
                bx.pack_start(name_lbl, True, True, 0)
                bx.pack_start(pkg_lbl, False, False, 0)
                bx.pack_start(run_b, False, False, 0)
                bx.pack_start(stop_b, False, False, 0)
                row.add(bx)
                row.set_data("pkg", p)
                self.app_list.add(row)
            self.app_list.show_all()

        def launch_pkg(self, p):
            if launch_app(p):
                self.toast(tr("apps_launched") + " " + p)
            else:
                self.toast(tr("apps_launch_fail"))

        def stop_pkg(self, p):
            stop_app(p)
            self.toast(tr("apps_stopped") + " " + p)

        def open_url_dialog(self):
            d = Gtk.Dialog(title=tr("apps_open_url"), transient_for=self,
                           modal=True, destroy_with_parent=True)
            d.set_default_size(460, 130)
            bx = d.get_content_area()
            vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            vb.set_margin_top(12); vb.set_margin_bottom(12); vb.set_margin_start(14); vb.set_margin_end(14)
            vb.pack_start(Gtk.Label(xalign=0.0, label=tr("apps_url_hint")), False, False, 0)
            ent = Gtk.Entry(); ent.set_placeholder_text("https://www.example.com")
            vb.pack_start(ent, False, False, 0)
            bx.pack_start(vb, True, True, 0)
            d.add_button(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
            ok = d.add_button(tr("apps_open"), Gtk.ResponseType.OK)
            d.show_all()
            resp = d.run()
            if resp == Gtk.ResponseType.OK and ent.get_text().strip():
                open_url(ent.get_text().strip())
                self.toast(tr("apps_opened"))
            d.destroy()

        def _clear_list(self):
            for row in list(self.app_list.get_children()):
                self.app_list.remove(row)

        def selected_pkg(self):
            row = self.app_list.get_selected_row()
            return row.get_data("pkg") if row else None

        def launch_selected(self):
            p = self.selected_pkg()
            if not p:
                self.toast(tr("apps_no_sel")); return
            if launch_app(p):
                self.toast(tr("apps_launched") + " " + p)
            else:
                self.toast(tr("apps_launch_fail"))

        def stop_selected(self):
            p = self.selected_pkg()
            if not p:
                self.toast(tr("apps_no_sel")); return
            stop_app(p)
            self.toast(tr("apps_stopped") + " " + p)

        def open_file_dialog(self):
            d = Gtk.Dialog(title=tr("apps_open_file"), transient_for=self,
                           modal=True, destroy_with_parent=True)
            d.set_default_size(420, 130)
            bx = d.get_content_area()
            vb = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            vb.set_margin_top(12); vb.set_margin_bottom(12); vb.set_margin_start(14); vb.set_margin_end(14)
            vb.pack_start(Gtk.Label(xalign=0.0, label=tr("apps_file_hint")), False, False, 0)
            ent = Gtk.Entry(); ent.set_placeholder_text("/sdcard/Download/file.mp4")
            vb.pack_start(ent, False, False, 0)
            bx.pack_start(vb, True, True, 0)
            d.add_button(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL)
            ok = d.add_button(tr("apps_open"), Gtk.ResponseType.OK)
            d.show_all()
            resp = d.run()
            if resp == Gtk.ResponseType.OK and ent.get_text().strip():
                open_file(ent.get_text().strip())
                self.toast(tr("apps_opened"))
            d.destroy()

        def on_headless(self, btn):
            if btn.get_active():
                self.start_headless()
            else:
                self.stop_headless()

        def start_headless(self):
            if not self.phones:
                self.headless_btn.set_active(False)
                self.toast(tr("scr_need_phone")); return
            self.stop_mirror()
            sc = find_scrcpy()
            if sc is None:
                self.headless_btn.set_active(False)
                self.bundle_note(); return
            args = [sc, "--no-video", "--no-audio",
                    "--keyboard=sdk", "--mouse=sdk",
                    "--window-title=" + EMBED_TITLE]
            if self.config.get("headless_screen_off"):
                args.append("--turn-screen-off")
            if not self.config.get("forward_enabled", True):
                args.append("--gamepad=disabled")
            else:
                args.append("--gamepad=" + self.config.get("gamepad", "uhid"))
            log("headless: " + " ".join(args))
            try:
                self.proc = subprocess.Popen(args, stdout=subprocess.PIPE,
                                            stderr=subprocess.STDOUT)
            except Exception as e:
                log("headless err %s" % e)
                self.headless_btn.set_active(False)
                self.toast(str(e)); return
            self.headless_running = True
            self.mirror_running = True
            self.mirror_start_ts = time.time()
            self.proc_tail = []; self.first_error = None
            self.headless_btn.set_label(tr("headless_stop"))
            self.headless_btn.get_style_context().add_class("destructive-action")
            self.toast(tr("headless_on"))
            threading.Thread(target=self.drain_proc, daemon=True).start()

        def stop_headless(self):
            if self.proc is not None:
                try:
                    self.proc.terminate(); self.proc.wait(timeout=4)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
            self.proc = None
            self.headless_running = False
            self.mirror_running = False
            self.headless_btn.set_label(tr("headless_start"))
            self.headless_btn.get_style_context().remove_class("destructive-action")
            self.toast(tr("headless_off"))

        def do_tap(self):
            if not self.phones:
                self.toast(tr("scr_need_phone")); return
            tap(int(self.tap_x.get_value()), int(self.tap_y.get_value()))
            self.toast(tr("pad_tapped"))

        def do_text(self):
            if not self.phones:
                self.toast(tr("scr_need_phone")); return
            t = self.text_entry.get_text()
            if t:
                input_text(t)
                self.toast(tr("pad_sent"))

        # ---------- Auto mirror (controller works on the phone) ----------
        def _maybe_auto_mirror(self):
            """Start the mirror automatically when phone + controller are
            both connected, so the gamepad works on the phone at once."""
            if not self.config.get("auto_mirror", True) or self._auto_blocked:
                return
            if self.mirror_running or self.headless_running:
                return
            if self.phone_state != "ok" or not self.ctrls:
                return
            serial = ",".join(self.phones)
            if self._auto_started == serial:
                return
            self._auto_started = serial
            GLib.idle_add(self._do_auto_mirror)

        def _do_auto_mirror(self):
            if self._alive and not self.mirror_running and not self.headless_running:
                self.start_mirror(auto=True)
                if self.mirror_running:
                    self.toast(tr("auto_mirror_on"))
                else:
                    self._auto_blocked = True
            return False

        # ---------- Refresh ----------
        def refresh_async(self, force=False):
            threading.Thread(target=self.refresh_worker, args=(force,), daemon=True).start()

        def refresh_worker(self, force):
            try:
                phones = detect_phones()
                ctrls = detect_controllers()
                GLib.idle_add(self.apply_refresh, phones, ctrls)
            except Exception as e:
                log("refresh: %s" % e)

        def periodic_refresh(self):
            self.refresh_async()
            if self.reader is not None:
                try:
                    if not os.path.exists(self.reader.path):
                        self.reader.stop()
                        self.reader = None
                        self.drawing.queue_draw()
                except Exception:
                    pass
            return True

        def apply_refresh(self, phones, ctrls):
            if not self._alive:
                return
            state, serials = phones
            self.phone_state, self.phones = state, serials
            if state == "ok":
                self.phone_status.set_markup(self.color(tr("phone_ok"), "#2e7d32"))
                self.phone_list.set_text(tr("phone_serial") + " " + ", ".join(serials))
            else:
                self._auto_started = ""
                self._auto_blocked = False
                if state == "unauthorized":
                    self.phone_status.set_markup(self.color(tr("phone_unauthorized"), "#e65100"))
                elif state == "adb_missing":
                    self.phone_status.set_markup(self.color(tr("phone_adb_missing"), "#c62828"))
                else:
                    self.phone_status.set_markup(self.color(tr("phone_none"), "#c62828"))
            if ctrls:
                readable = [c for c in ctrls if c.get("readable")]
                if readable:
                    self.ctrl_status.set_markup(self.color(tr("ctrl_ok"), "#2e7d32"))
                else:
                    self.ctrl_status.set_markup(self.color(tr("ctrl_perm"), "#e65100"))
                self.ctrl_name.set_text("\n".join(
                    "%s [%s] - %s" % (c["name"], os.path.basename(c["path"]),
                                      controller_type(c["name"])) for c in ctrls))
            else:
                self.ctrl_status.set_markup(self.color(tr("ctrl_none"), "#c62828"))
                self.ctrl_name.set_text("")
            self._maybe_auto_mirror()

        def build_scrcpy_args(self, sc):
            args = [sc, "--window-title=" + EMBED_TITLE, "--shortcut-mod=lalt"]
            if self.config.get("forward_enabled", True):
                args.append("--gamepad=" + self.config.get("gamepad", "uhid"))
            else:
                args.append("--gamepad=disabled")
            if self.config.get("mouse_mode", "sdk") == "uhid":
                args += ["--mouse=uhid", "--keyboard=uhid"]
            else:
                args += ["--mouse=sdk", "--keyboard=sdk"]
            preset = self.config.get("preset", "balanced")
            audio = self.config.get("audio", True)
            ms = self.config.get("max_size", "1024"); fps = self.config.get("fps", "60")
            br = self.config.get("bitrate", "16M")
            if preset == "gaming":
                audio = False; ms = "800"; fps = "60"; br = "8M"
            elif preset == "quality":
                audio = True; ms = "1920"; fps = "60"; br = "32M"
            if ms != "original":
                try:
                    args += ["--max-size", str(int(ms))]
                except ValueError:
                    pass
            try:
                args += ["--max-fps", str(int(fps))]
            except ValueError:
                pass
            args += ["--video-bit-rate", br]
            if not audio:
                args.append("--no-audio")
            if self.config.get("stay_awake"):
                args.append("--stay-awake")
            if self.config.get("turn_screen_off"):
                args.append("--turn-screen-off")
            if self.config.get("record"):
                try:
                    os.makedirs(VIDEO_DIR, exist_ok=True)
                except Exception:
                    pass
                args += ["--record", os.path.join(VIDEO_DIR, "padlink_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".mp4")]
            return args

        def start_mirror(self, auto=False):
            self._auto_mirror_run = auto
            if find_adb() is None:
                self.toast(tr("phone_adb_missing")); return
            state, _ = detect_phones()
            if state != "ok":
                self.toast(tr("scr_need_phone")); return
            sc = find_scrcpy()
            if sc is None:
                self.bundle_note(); return
            self.stop_mirror()
            args = self.build_scrcpy_args(sc)
            log("start: " + " ".join(args))
            try:
                self.proc = subprocess.Popen(args, stdout=subprocess.PIPE,
                                             stderr=subprocess.STDOUT)
            except Exception as e:
                log("start err %s" % e); self.toast(str(e)); return
            self.mirror_running = True
            self.mirror_start_ts = time.time()
            self.proc_tail = []; self.first_error = None
            self.btn_start2.set_sensitive(False); self.btn_stop.set_sensitive(True)
            self.scr_status.set_text(tr("scr_running"))
            self.overlay_start()
            # Show standalone note inside the holder.
            for ch in list(self.screen_holder.get_children()):
                self.screen_holder.remove(ch)
            note = Gtk.Label(label=tr("scr_standalone_note"), wrap=True,
                             halign=Gtk.Align.CENTER, valign=Gtk.Align.CENTER)
            self.screen_holder.pack_start(note, True, True, 0)
            self.screen_holder.show_all()
            threading.Thread(target=self.drain_proc, daemon=True).start()

        def drain_proc(self):
            if self.proc is None or self.proc.stdout is None:
                return
            try:
                for line in iter(self.proc.stdout.readline, b""):
                    t = line.decode(errors="replace").strip()
                    self.proc_tail.append(t)
                    if len(self.proc_tail) > 40:
                        self.proc_tail.pop(0)
                    if t and self.first_error is None and ("ERROR" in t.upper() or "failed" in t.lower()):
                        self.first_error = t
            except Exception:
                pass

        def watch_mirror(self):
            self.overlay_tick()
            if self._alive and self.proc is not None and self.mirror_running:
                if self.proc.poll() is not None:
                    if time.time() - self.mirror_start_ts < 6.0:
                        GLib.idle_add(self.on_early_exit)
                    else:
                        GLib.idle_add(self.on_exit)
                    return False
            return True

        def on_early_exit(self):
            self.mirror_running = False; self.headless_running = False
            self.btn_start2.set_sensitive(True); self.btn_stop.set_sensitive(False)
            self.headless_btn.set_label(tr("headless_start"))
            self.proc = None
            self.overlay_stop()
            if self._auto_mirror_run:
                self._auto_mirror_run = False
                self._auto_blocked = True
                self.toast(tr("auto_mirror_fail"))
                return
            body = tr("err_body")
            if self.first_error:
                body += "\n\n<big><b>%s</b></big>" % GLib.markup_escape_text(self.first_error)
            elif self.proc_tail:
                body += "\n\n<tt>%s</tt>" % GLib.markup_escape_text("\n".join(self.proc_tail[-5:]))
            body += "\n\n" + tr("err_tips")
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.ERROR,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("err_title"))
            d.format_secondary_markup(body)
            d.run(); d.destroy()

        def on_exit(self):
            self.mirror_running = False; self.headless_running = False
            self.btn_start2.set_sensitive(True); self.btn_stop.set_sensitive(False)
            self.headless_btn.set_label(tr("headless_start"))
            self.scr_status.set_text(tr("scr_ended"))
            self.proc = None
            self.overlay_stop()

        def stop_mirror(self, manual=False):
            if manual:
                self._auto_blocked = True
            self.overlay_stop()
            if self.proc is not None:
                try:
                    self.proc.terminate(); self.proc.wait(timeout=4)
                except Exception:
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
            self.proc = None
            self.mirror_running = False; self.headless_running = False
            self.btn_start2.set_sensitive(True); self.btn_stop.set_sensitive(False)
            self.headless_btn.set_label(tr("headless_start"))
            self.scr_status.set_text(tr("scr_stopped"))
            # restore placeholder
            for ch in list(self.screen_holder.get_children()):
                self.screen_holder.remove(ch)
            ph = Gtk.Label(wrap=True)
            ph.set_markup('<span size="x-large">%s</span>' % tr("scr_placeholder"))
            ph.set_halign(Gtk.Align.CENTER); ph.set_valign(Gtk.Align.CENTER)
            self.screen_holder.pack_start(ph, True, True, 0)
            self.screen_holder.show_all()

        # ---------- Screen controls ----------
        def target_xid(self):
            if xdotool():
                rc, out, _ = run_cmd(["xdotool", "search", "--name", EMBED_TITLE], 5)
                for line in out.splitlines():
                    try:
                        return int(line)
                    except ValueError:
                        continue
            return 0

        def wcenter(self, xid):
            rc, out, _ = run_cmd(["xdotool", "getwindowgeometry", "--shell", str(xid)], 5)
            d = {}
            for line in out.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    try:
                        d[k] = int(v)
                    except ValueError:
                        continue
            return d.get("X", 0) + d.get("WIDTH", 0) // 2, d.get("Y", 0) + d.get("HEIGHT", 0) // 2

        def zoom(self, direction):
            if not xdotool():
                self.toast(tr("no_xdotool")); return
            xid = self.target_xid()
            if not xid:
                return
            cx, cy = self.wcenter(xid)
            if not cx:
                return
            run_cmd(["xdotool", "mousemove", str(cx), str(cy)], 5)
            run_cmd(["xdotool", "keydown", "alt"], 5)
            run_cmd(["xdotool", "click", "4" if direction > 0 else "5"], 5)
            run_cmd(["xdotool", "keyup", "alt"], 5)

        def fit(self):
            if not xdotool():
                self.toast(tr("no_xdotool")); return
            xid = self.target_xid()
            if not xid:
                return
            run_cmd(["xdotool", "windowfocus", "--sync", str(xid)], 5)
            run_cmd(["xdotool", "key", "alt+g"], 5)

        def toggle_fullscreen(self):
            if self.mirror_running and xdotool():
                xid = self.target_xid()
                if xid:
                    run_cmd(["xdotool", "windowactivate", "--sync", str(xid)], 5)
                    run_cmd(["xdotool", "key", "alt+f"], 5)
                    self.toast(tr("fs_scrcpy")); return
            self.toast(tr("fs_on"))

        def focus_video(self):
            if not xdotool():
                self.toast(tr("no_xdotool")); return
            xid = self.target_xid()
            if not xid:
                self.toast(tr("focus_no_window")); return
            run_cmd(["xdotool", "windowfocus", "--sync", str(xid)], 5)
            cx, cy = self.wcenter(xid)
            if cx:
                run_cmd(["xdotool", "mousemove", str(cx), str(cy)], 5)
                run_cmd(["xdotool", "click", "1"], 5)
            self.toast(tr("focus_done"))

        def scroll(self, direction):
            if not self.phones:
                self.toast(tr("scr_need_phone")); return
            serial = self.phones[0]
            w, h = get_phone_size(serial)
            cx = w // 2
            if direction == "down":
                y1, y2 = int(h * 0.68), int(h * 0.32)
            else:
                y1, y2 = int(h * 0.32), int(h * 0.68)
            run_cmd(adb_cmd(["-s", serial, "shell", "input", "swipe",
                             str(cx), str(y1), str(cx), str(y2), "220"]), 8)
            self.toast(tr("scroll_ok_" + direction))

        def keyev(self, code):
            run_cmd(adb_cmd(["shell", "input", "keyevent", str(code)]), 8)

        def rotate_screen(self):
            run_cmd(adb_cmd(["shell", "settings", "put", "system", "accelerometer_rotation", "0"]))
            rc, out, _ = run_cmd(adb_cmd(["shell", "settings", "get", "system", "user_rotation"]), 8)
            try:
                cur = int(out.strip())
            except ValueError:
                cur = 0
            run_cmd(adb_cmd(["shell", "settings", "put", "system", "user_rotation", str((cur + 1) % 4)]))
            self.toast(tr("rotated"))

        def screenshot(self):
            try:
                os.makedirs(SCREENSHOT_DIR, exist_ok=True)
                path = os.path.join(SCREENSHOT_DIR, "padlink_" + datetime.now().strftime("%Y%m%d_%H%M%S") + ".png")
                with open(path, "wb") as f:
                    subprocess.run(adb_cmd(["exec-out", "screencap", "-p"]), stdout=f, timeout=20)
                self.toast(tr("scr_saved") + ": " + path)
            except Exception:
                self.toast(tr("scr_saved"))

        def on_rec(self, b):
            self.cfg("record", b.get_active())
            self.toast(tr("record_started") if b.get_active() else tr("record_off"))

        def on_aud(self, b):
            self.cfg("audio", b.get_active())
            try:
                self.aud.set_tooltip_text(tr("audio_on") if b.get_active() else tr("audio_off"))
            except Exception:
                pass
            self.toast(tr("audio_on") if b.get_active() else tr("audio_off"))

        def on_stay(self, b):
            self.cfg("stay_awake", b.get_active())
            self.toast(tr("stay_on") if b.get_active() else tr("stay_off"))

        # ---------- Smart color layer ----------
        def overlay_start(self):
            if _so is None or not self.overlay.get("enabled", False):
                self.smart_ov = None
                return
            try:
                if self.smart_ov is None:
                    self.smart_ov = _so.SmartOverlay()
                self.smart_ov.set_params(
                    auto=self.overlay.get("auto", True),
                    opacity=self.overlay.get("opacity", 0.12),
                    tint=[c / 255.0 for c in self.overlay.get("color", [77, 124, 255])],
                    clarity=self.overlay.get("clarity", 0.0),
                    exposure=self.overlay.get("exposure", 0.0))
                self.smart_ov.start()
            except Exception as e:
                log("overlay start err %s" % e)
                self.smart_ov = None

        def overlay_stop(self):
            if self.smart_ov is not None:
                try:
                    self.smart_ov.stop()
                except Exception:
                    pass
                self.smart_ov = None

        def overlay_tick(self):
            """Called from watch_mirror every second (inside the GTK loop)."""
            if self.smart_ov is not None and self.mirror_running and \
                    self.overlay.get("enabled", False):
                try:
                    self.smart_ov.tick()
                except Exception:
                    pass
            return True

        def overlay_apply(self):
            """Push current UI/config values into the live overlay."""
            if self.smart_ov is not None:
                try:
                    self.smart_ov.set_params(
                        auto=self.overlay.get("auto", True),
                        opacity=self.overlay.get("opacity", 0.12),
                        tint=[c / 255.0 for c in self.overlay.get("color", [77, 124, 255])],
                        clarity=self.overlay.get("clarity", 0.0),
                        exposure=self.overlay.get("exposure", 0.0))
                except Exception:
                    pass

        # ---------- Overlay ----------
        def on_ov(self, s, p):
            self.overlay["enabled"] = s.get_active()
            self.cfg("overlay_enabled", s.get_active())
            if s.get_active():
                self.overlay_start()
                self.toast(tr("ov_enabled"))
            else:
                self.overlay_stop()
                self.toast(tr("ov_disabled"))

        def on_ov_auto(self, s, p):
            self.overlay["auto"] = s.get_active()
            self.cfg("overlay_auto", s.get_active())
            self.overlay_apply()
            self.toast(tr("ov_auto_on") if s.get_active() else tr("ov_auto_off"))

        def on_ov_color(self, b):
            rgba = b.get_rgba()
            self.overlay["color"] = [int(rgba.red * 255), int(rgba.green * 255), int(rgba.blue * 255)]
            self.cfg("overlay_color", self.overlay["color"])
            self.overlay_apply()

        def on_ov_opacity(self, s):
            v = s.get_value() / 100.0
            self.overlay["opacity"] = v
            self.cfg("overlay_opacity", v)
            self.overlay_apply()

        def on_ov_clarity(self, s):
            v = s.get_value() / 100.0
            self.overlay["clarity"] = v
            self.cfg("overlay_clarity", v)
            self.overlay_apply()

        def on_ov_exposure(self, s):
            v = s.get_value() / 100.0
            self.overlay["exposure"] = v
            self.cfg("overlay_exposure", v)
            self.overlay_apply()

        # ---------- Settings ----------
        def settings_popover(self, btn):
            pop = Gtk.Popover.new(btn)
            bx = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
            bx.set_margin_top(10); bx.set_margin_bottom(10); bx.set_margin_start(12); bx.set_margin_end(12)
            bx.set_size_request(380, -1)

            def row(label, combo, tip=None):
                r = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
                r.pack_start(Gtk.Label(label=label), False, False, 0)
                r.pack_start(combo, True, True, 0)
                if tip:
                    combo.set_tooltip_text(tr(tip))
                return r

            preset = Gtk.ComboBoxText()
            for v, k in (("balanced", "preset_balanced"), ("gaming", "preset_gaming"), ("quality", "preset_quality")):
                preset.append(v, tr(k))
            preset.set_active_id(self.config.get("preset", "balanced"))
            bx.pack_start(row(tr("preset"), preset, "help_preset"), False, False, 0)

            size = Gtk.ComboBoxText()
            for v, l in (("original", tr("opt_original")), ("1920", "1920"), ("1280", "1280"), ("1024", "1024"), ("800", "800")):
                size.append(v, l)
            size.set_active_id(self.config.get("max_size", "1024"))
            bx.pack_start(row(tr("set_max_size"), size, "help_max_size"), False, False, 0)

            fps = Gtk.ComboBoxText()
            for v in ("60", "30", "15"):
                fps.append(v, v)
            fps.set_active_id(self.config.get("fps", "60"))
            bx.pack_start(row(tr("set_fps"), fps, "help_fps"), False, False, 0)

            bit = Gtk.ComboBoxText()
            for v in ("32M", "16M", "8M", "4M", "2M"):
                bit.append(v, v)
            bit.set_active_id(self.config.get("bitrate", "16M"))
            bx.pack_start(row(tr("set_bitrate"), bit, "help_bitrate"), False, False, 0)

            gp = Gtk.ComboBoxText()
            gp.append("uhid", tr("opt_uhid")); gp.append("aoa", tr("opt_aoa"))
            gp.set_active_id(self.config.get("gamepad", "uhid"))
            bx.pack_start(row(tr("set_gamepad"), gp, "help_gamepad"), False, False, 0)

            mouse = Gtk.ComboBoxText()
            mouse.append("sdk", tr("mouse_sdk")); mouse.append("uhid", tr("mouse_uhid_opt"))
            mouse.set_active_id(self.config.get("mouse_mode", "sdk"))
            bx.pack_start(row(tr("set_mouse"), mouse, "help_mouse"), False, False, 0)

            toggles = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
            aud = Gtk.Switch(); aud.set_active(bool(self.config.get("audio", True)))
            t1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t1.pack_start(Gtk.Label(label=tr("set_audio")), False, False, 0); t1.pack_start(aud, False, False, 0)
            stay = Gtk.Switch(); stay.set_active(bool(self.config.get("stay_awake", False)))
            t2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t2.pack_start(Gtk.Label(label=tr("stay_awake")), False, False, 0); t2.pack_start(stay, False, False, 0)
            off = Gtk.Switch(); off.set_active(bool(self.config.get("turn_screen_off", False)))
            t3 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t3.pack_start(Gtk.Label(label=tr("turn_screen_off_label")), False, False, 0); t3.pack_start(off, False, False, 0)
            for t in (t1, t2, t3):
                toggles.pack_start(t, True, True, 0)
            bx.pack_start(toggles, False, False, 0)
            am = Gtk.Switch(); am.set_active(bool(self.config.get("auto_mirror", True)))
            t4 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            t4.pack_start(Gtk.Label(label=tr("auto_mirror_switch")), False, False, 0)
            t4.pack_start(am, False, False, 0)
            t4.set_tooltip_text(tr("auto_mirror_help"))
            toggles.pack_start(t4, True, True, 0)

            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup('<span color="#888888" size="small">%s</span>' % tr("set_note"))
            bx.pack_start(note, False, False, 0)
            ap = Gtk.Button(label=tr("set_apply"))
            ap.get_style_context().add_class("suggested-action")

            def apply(_b):
                self.config.update(preset=preset.get_active_id() or "balanced",
                                   max_size=size.get_active_id() or "1024",
                                   fps=fps.get_active_id() or "60",
                                   bitrate=bit.get_active_id() or "16M",
                                   gamepad=gp.get_active_id() or "uhid",
                                   mouse_mode=mouse.get_active_id() or "sdk",
                                   audio=aud.get_active(), stay_awake=stay.get_active(),
                                   turn_screen_off=off.get_active(),
                                   auto_mirror=am.get_active())
                save_config(self.config)
                pop.popdown()
                self.toast(tr("set_saved"))

            ap.connect("clicked", apply)
            bx.pack_start(ap, False, False, 0)
            pop.add(bx)
            pop.show_all()

        # ---------- Tips / Doctor / Help ----------
        def show_tips(self):
            tips = [tr("tip_adv_%d" % i) for i in range(1, 9)]
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("tips_title"))
            d.format_secondary_text(tr("tips_intro") + "\n\n" + "\n".join("\u2022 " + t for t in tips))
            d.run(); d.destroy()

        def run_doctor(self):
            lines = ["PadLink doctor (%s)" % APP_VERSION, "=" * 42]
            try:
                import gi as _g
                lines.append("%-18s OK   python3-gi" % "pygobject")
            except Exception:
                lines.append("%-18s FAIL python3-gi" % "pygobject")
            try:
                import cairo as _c
                lines.append("%-18s OK   python3-cairo" % "pycairo")
            except Exception:
                lines.append("%-18s FAIL python3-cairo" % "pycairo")
            try:
                import evdev as _e
                lines.append("%-18s OK   python3-evdev" % "evdev")
            except Exception:
                lines.append("%-18s FAIL python3-evdev" % "evdev")
            adb = find_adb()
            lines.append("%-18s %s %s" % ("adb", "OK " if adb else "FAIL", adb or "missing"))
            sp = find_scrcpy()
            lines.append("%-18s %s %s" % ("scrcpy", "OK " if sp else "FAIL", sp or "missing"))
            ctrl = len(detect_controllers())
            lines.append("%-18s %s %d controller(s)" % ("gamepad", "OK " if ctrl else "FAIL", ctrl))
            report = "\n".join(lines)
            try:
                os.makedirs(CONFIG_DIR, exist_ok=True)
                open(os.path.join(CONFIG_DIR, "doctor.log"), "w", encoding="utf-8").write(report + "\n")
            except Exception:
                pass
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("doctor_title"))
            d.format_secondary_markup("<tt>%s</tt>" % GLib.markup_escape_text(report))
            d.run(); d.destroy()

        def run_diag(self):
            if getattr(self, "_diag_running", False):
                return
            self._diag_running = True
            self.toast(tr("diag_running"))
            threading.Thread(target=self._diag_worker, daemon=True).start()

        def _diag_worker(self):
            report = ""
            try:
                report = diag_controllers()
                try:
                    os.makedirs(CONFIG_DIR, exist_ok=True)
                    open(os.path.join(CONFIG_DIR, "diag.log"), "w", encoding="utf-8").write(report + "\n")
                except Exception:
                    pass
            except Exception as e:
                report = "diag error: %s" % e
            GLib.idle_add(self._diag_show, report)

        def _diag_show(self, report):
            self._diag_running = False
            self.toast(tr("diag_done"))
            d = Gtk.Dialog(title=tr("diag_title"), transient_for=self, modal=True,
                           destroy_with_parent=True)
            d.set_default_size(760, 560)
            bx = d.get_content_area()
            sw = Gtk.ScrolledWindow()
            sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            lb = Gtk.Label(xalign=0.0, valign=Gtk.Align.START, selectable=True, wrap=False)
            lb.set_markup("<tt>%s</tt>" % GLib.markup_escape_text(report))
            sw.add(lb)
            bx.pack_start(sw, True, True, 0)
            note = Gtk.Label(xalign=0.0, wrap=True)
            note.set_markup('<span color="#888888" size="small">%s</span>' % tr("diag_note"))
            bx.pack_start(note, False, False, 0)
            d.add_button(Gtk.STOCK_CLOSE, Gtk.ResponseType.CLOSE)
            d.show_all()
            d.run(); d.destroy()

        def show_about(self):
            sp = find_scrcpy()
            spv = ""
            if sp:
                rc, out, _ = run_cmd([sp, "--version"], 6)
                for line in out.splitlines():
                    if line.startswith("scrcpy "):
                        spv = line.split()[1]
                        break
            d = Gtk.MessageDialog(transient_for=self, modal=True,
                                  message_type=Gtk.MessageType.INFO,
                                  buttons=Gtk.ButtonsType.CLOSE, text=tr("about_title"))
            d.format_secondary_markup(
                "<b>PadLink %s</b>\n%s\n\n"
                "scrcpy: %s\nadb: %s\n\n"
                "<span color=\"#888888\" size=\"small\">%s</span>"
                % (APP_VERSION, tr("about_body"),
                   spv or tr("about_unknown"), os.path.basename(find_adb() or "adb"),
                   tr("about_footer")))
            d.run(); d.destroy()

        def show_help(self):
            items = [
                ("grp_mirror", [("btn_start2", "help_start"), ("btn_stop", "help_stop")]),
                ("grp_view", [("btn_fullscreen", "help_fullscreen"), ("btn_zoom_in", "help_zoom_in"),
                              ("btn_zoom_out", "help_zoom_out"), ("btn_fit", "help_fit"),
                              ("btn_rotate", "help_rotate"), ("btn_screenshot", "help_shot"),
                              ("btn_record", "help_record")]),
                ("grp_nav", [("btn_scroll_up", "help_scroll_up"), ("btn_scroll_down", "help_scroll_down"),
                             ("btn_focus", "help_focus"), ("btn_home", "help_home"),
                             ("btn_back", "help_back"), ("btn_recents", "help_recents"),
                             ("btn_vol_up", "help_vol_up"), ("btn_vol_down", "help_vol_down"),
                             ("btn_power", "help_power")]),
                ("grp_overlay", [("overlay_title", "help_overlay")]),
                ("grp_ctrl", [("fwd_switch", "help_forward"), ("vib_switch", "help_vib_enable"),
                              ("ctrl_deadzone", "help_deadzone"), ("ctrl_recenter", "help_recenter"),
                              ("ctrl_reset_cal", "help_reset_cal")]),
                ("grp_apps", [("tab_apps", "help_apps"), ("headless_title", "help_headless"),
                              ("apps_open_file", "help_open_file")]),
                ("grp_util", [("btn_doctor", "help_doctor"), ("btn_settings", "help_settings"),
                              ("btn_tips", "help_tips")]),
            ]
            d = Gtk.Dialog(title=tr("help_title"), transient_for=self, modal=True,
                           destroy_with_parent=True)
            d.set_default_size(700, 560)
            tv = Gtk.TextView(); tv.set_editable(False); tv.set_cursor_visible(False)
            tv.set_wrap_mode(Gtk.WrapMode.WORD)
            sw = Gtk.ScrolledWindow(); sw.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
            sw.add(tv)
            d.get_content_area().pack_start(sw, True, True, 0)
            d.add_button(tr("help_close"), Gtk.ResponseType.CLOSE)
            d.show_all()
            buf = tv.get_buffer()
            buf.insert(buf.get_end_iter(), tr("help_intro") + "\n\n")
            for gid, gname in items:
                buf.insert(buf.get_end_iter(), "=== " + tr(gid) + " ===\n")
                for key, hk in gname:
                    desc = tr(hk, "")
                    if desc:
                        buf.insert(buf.get_end_iter(), "\u2022 %s\n    %s\n" % (tr(key, key), desc))
                buf.insert(buf.get_end_iter(), "\n")
            d.run(); d.destroy()

        # ---------- Lifecycle ----------
        def on_destroy(self, _w):
            self._alive = False
            self.overlay_stop()
            self.stop_mirror()
            if self.reader:
                self.reader.stop()
            for t in self.timers:
                GLib.source_remove(t)


def xdotool():
    return shutil.which("xdotool") is not None


def diag_controllers():
    """DEEP DIAGNOSTIC: tells exactly why a controller is (not) working."""
    out = []
    def line(t):
        out.append(t)
    line("=" * 58)
    line("PadLink deep diagnostic %s" % APP_VERSION)
    line("=" * 58)
    line("[1] SYSTEM")
    line("    kernel: %s" % (run_cmd(["uname", "-r"])[1] or "?"))
    line("    user:   %s" % (run_cmd(["id", "-un"])[1] or "?"))
    line("    groups: %s" % (run_cmd(["id", "-nG"])[1] or "?"))

    line("")
    line("[2] USB DEVICES (looking for Xbox 360: vendor 045e)")
    rc, us, _ = run_cmd(["lsusb"], 8)
    xbox_usb = []
    if rc == 0:
        for l in us.splitlines():
            l2 = l.lower()
            if "045e" in l2 or "xbox" in l2 or "gamepad" in l2 or "controller" in l2:
                xbox_usb.append(l)
                line("    FOUND: " + l)
        if not xbox_usb:
            line("    No Xbox/gamepad USB device found.")
            line("    >>> If the pad is plugged and not here: cable/port/driver.")
    else:
        line("    lsusb unavailable")

    line("")
    line("[3] KERNEL DRIVER (xpad)")
    rc, ls, _ = run_cmd(["sh", "-c", "lsmod 2>/dev/null | grep -E 'xpad|joydev|uinput'"], 5)
    if rc == 0 and ls:
        line("    loaded:")
        for l in ls.splitlines():
            line("      " + l)
    else:
        line("    xpad / joydev / uinput NOT loaded.")
        line("    >>> run: sudo modprobe xpad && sudo modprobe joydev && sudo modprobe uinput")

    line("")
    line("[4] INPUT DEVICES (evdev)")
    try:
        import evdev as _ev
        devs = _ev.list_devices()
        if not devs:
            line("    NO event devices at all.")
        for d in devs:
            try:
                dev = _ev.InputDevice(d)
                caps = dev.capabilities(verbose=False)
                raw_abs = caps.get(_ev.ecodes.EV_ABS, [])
                abs_keys = [i[0] if isinstance(i, tuple) else i for i in raw_abs]
                key_keys = caps.get(_ev.ecodes.EV_KEY, [])
                has_axis = any(k in (_ev.ecodes.ABS_X, _ev.ecodes.ABS_Y,
                                     _ev.ecodes.ABS_RX, _ev.ecodes.ABS_RZ,
                                     _ev.ecodes.ABS_Z) for k in abs_keys)
                has_btn = any(k in (_ev.ecodes.BTN_A, _ev.ecodes.BTN_SOUTH,
                                    _ev.ecodes.BTN_JOYSTICK, _ev.ecodes.BTN_GAMEPAD,
                                    _ev.ecodes.BTN_TL, _ev.ecodes.BTN_TR) for k in key_keys)
                tag = "GAMEPAD" if (has_axis and has_btn) else "other"
                try:
                    perm = oct(os.stat(d).st_mode & 0o777)
                except Exception:
                    perm = "?"
                line("    %-16s %-8s %s  (axes=%d btns=%d) [%s]" % (
                    d, tag, (dev.name or "?")[:36], len(abs_keys), len(key_keys), perm))
                dev.close()
            except PermissionError:
                line("    %-16s NO-PERM (need: sudo chmod 666 %s  or input group)" % (d, d))
            except Exception as e:
                line("    %-16s err: %s" % (d, e))
    except Exception as e:
        line("    evdev error: %s" % e)

    line("")
    line("[5] JOYSTICK NODES (js*)")
    js = sorted(glob.glob("/dev/input/js*"))
    if js:
        for j in js:
            try:
                line("    %s  %s" % (j, oct(os.stat(j).st_mode & 0o777)))
            except Exception:
                line("    %s" % j)
    else:
        line("    none")

    line("")
    line("[6] PERMISSIONS / GROUPS")
    rc, grp, _ = run_cmd(["sh", "-c", "id -nG | tr ' ' '\n' | grep -qx input"], 4)
    line("    user in 'input' group: %s" % ("YES" if rc == 0 else "NO"))
    if rc != 0:
        line("    >>> run: sudo usermod -aG input $USER  (then log out/in)")
    line("    /dev/uinput: %s" % (os.path.exists("/dev/uinput") and "present" or "MISSING (sudo modprobe uinput)"))

    line("")
    line("[7] udev RULES")
    dst = "/etc/udev/rules.d/51-padlink-android.rules"
    if os.path.isfile(dst):
        line("    installed: yes")
        try:
            content = open(dst, encoding="utf-8", errors="replace").read()
            if "|" in content.split("#")[-1]:
                line("    *** INVALID rule (contains | in a match) - reinstall the package ***")
            else:
                line("    content OK")
        except Exception:
            line("    content unreadable")
    else:
        line("    installed: NO  (reinstall the package)")

    line("")
    line("[8] KERNEL LOG (xpad / usb errors)")
    rc, dm, _ = run_cmd(["sh", "-c", "dmesg 2>/dev/null | grep -iE 'xpad|xbox|usb.*error|controller' | tail -8"], 6)
    if rc == 0 and dm:
        for l in dm.splitlines():
            line("    " + l)
    else:
        line("    (need sudo or nothing relevant)")

    line("")
    line("[9] WHAT TO DO")
    has_any = False
    for l in out:
        if "GAMEPAD" in l and "/dev/input" in l:
            has_any = True
    if has_any:
        line("    A gamepad IS visible. If it still does not respond:")
        line("    1) press the 'smart auto-fix' button in the app")
        line("    2) or run: sudo modprobe -r xpad && sudo modprobe xpad")
        line("    3) unplug/replug the pad")
    elif xbox_usb:
        line("    USB shows the pad but no input device -> driver problem.")
        line("    >>> sudo modprobe -r xpad; sudo modprobe xpad")
        line("    >>> then unplug/replug the pad")
    else:
        line("    The pad is NOT seen at USB level.")
        line("    >>> check: cable, USB port, receiver pairing,")
        line("    >>> try another port, another pad if possible.")
    line("=" * 58)
    return "\n".join(out)


def main():
    if "--version" in sys.argv:
        print("padlink %s" % APP_VERSION)
        return 0
    if "--diag" in sys.argv:
        print(diag_controllers())
        return 0
    if "--doctor" in sys.argv:
        try:
            import evdev
        except Exception:
            evdev = None
        print("PadLink doctor %s" % APP_VERSION)
        print("pygobject OK")
        print("pycairo OK")
        print("evdev %s" % ("OK" if evdev else "MISSING"))
        print("adb:", find_adb())
        print("scrcpy:", find_scrcpy())
        print("controllers:", len(detect_controllers()))
        return 0
    if not GTK_OK:
        print("GTK unavailable: %s" % _ERR)
        return 1
    log("start %s" % APP_VERSION)
    try:
        w = PadLinkWindow()
        w.show_all()
        if "--smoke" in sys.argv:
            GLib.timeout_add(2500, Gtk.main_quit)
        Gtk.main()
        log("clean exit")
    except Exception as e:
        log("fatal: %s" % e)
        traceback.print_exc()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
