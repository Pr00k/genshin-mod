#!/usr/bin/env python3
# ============================================================================
# PadLink SmartOverlay v2.0 - the SMART POPUP LAYER over the mirror window.
#
# What it is:
#   A transparent, click-through, always-on-top window that floats exactly
#   over the scrcpy mirror window and re-lights the scene in real time:
#
#     * SMART AUTO COLORS - live scene analysis (dark / bright / washed /
#       dull) -> automatic white balance from the scene cast, a mood tint
#       that matches the lighting, and smart vibrance for desaturated
#       scenes. The user's color + color temperature blend on top.
#     * ADVANCED CLARITY  - multi-scale unsharp detail boost (fine texture
#       + large structure) rendered as local light/shadow masks,
#       auto-normalized per frame, plus a global midtone contrast curve
#       for a deep, punchy look on washed-out scenes.
#     * ULTRA-FAST LOOP   - geometry tracking @ ~4Hz, scene analysis @ 10Hz,
#       parameter smoothing @ 15Hz. Pure-numpy sub-millisecond math, scipy
#       optional. No visible lag or flicker even at a 240fps mirror.
#     * LIVE AI CHIP      - tiny corner chip: mode + real analysis rate.
#
# Pure ASCII source. GTK3 + cairo + numpy (scipy optional, graceful fallback).
# ============================================================================
import math
import os
import time

try:
    import numpy as np
    _NP = True
except Exception:
    _NP = False

try:
    from scipy import ndimage as _sci
    _SCI = True
except Exception:
    _SCI = False

Gdk = GdkPixbuf = GdkX11 = None
try:
    import gi
    gi.require_version("Gdk", "3.0")
    gi.require_version("GdkPixbuf", "2.0")
    try:
        gi.require_foreign("cairo")
    except Exception:
        pass
    from gi.repository import Gdk, GdkPixbuf
    try:
        gi.require_version("GdkX11", "3.0")
        from gi.repository import GdkX11
    except Exception:
        GdkX11 = None
except Exception:
    pass

XID_PATTERN = "padlink_window"

GEO_PERIOD = 0.25     # seconds between mirror-geometry checks (xdotool)
AN_PERIOD = 0.10      # seconds between scene analyses (grab + numpy)
STATS_PERIOD = 1.0    # seconds between UI status updates

_BIG_WINDOW_PX = 2_400_000  # above this, avoid the heavier OVERLAY blend


def _run(cmd, timeout=5):
    import subprocess
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout.strip(), r.stderr.strip()
    except Exception:
        return -1, "", ""


def find_mirror_xid():
    """Locate the scrcpy mirror window XID (X11 only)."""
    if not os.environ.get("DISPLAY"):
        return None
    rc, out, _ = _run(["xdotool", "search", "--name", XID_PATTERN], 4)
    if rc == 0:
        ids = [l for l in out.splitlines() if l.strip().isdigit()]
        if ids:
            return int(ids[0])
    return None


def find_mirror_geometry(xid):
    rc, out, _ = _run(["xdotool", "getwindowgeometry", "--shell", str(xid)], 4)
    geo = {}
    if rc == 0:
        for line in out.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                try:
                    geo[k.strip()] = int(v.strip())
                except Exception:
                    pass
    return geo  # X, Y, WIDTH, HEIGHT


def grab_window(xid, w, h):
    """Sample the mirror window content -> numpy RGB (small). None on fail."""
    if Gdk is None or GdkX11 is None or not _NP:
        return None
    try:
        disp = Gdk.Display.get_default()
        gdkwin = GdkX11.X11Window.foreign_new_for_display(disp, xid)
        if gdkwin is None:
            return None
        pb = Gdk.pixbuf_get_from_window(gdkwin, 0, 0, w, h)
        if pb is None:
            return None
        tw = max(72, min(144, w // 4))
        th = max(48, min(288, h // 4))
        small = pb.scale_simple(tw, th, GdkPixbuf.InterpType.BILINEAR)
        raw = small.get_pixels()
        arr = np.frombuffer(raw, dtype=np.uint8)
        nch = small.get_n_channels()
        arr = arr.reshape(th, tw, nch)
        return arr[:, :, :3].astype(np.float32) / 255.0
    except Exception:
        return None


# ---------- image math (numpy core, scipy optional) ----------

def _box_blur(a, r):
    """Separable-free O(1) box blur via the integral image (fallback)."""
    if not _NP or r <= 0:
        return a
    k = 2 * r + 1
    p = np.pad(a, r, mode="edge").astype(np.float32)
    h, w = a.shape
    S = np.zeros((h + 2 * r + 1, w + 2 * r + 1), dtype=np.float32)
    S[1:, 1:] = p
    S = np.cumsum(np.cumsum(S, axis=0), axis=1)
    return (S[k:k + h, k:k + w] - S[:h, k:k + w] -
            S[k:k + h, :w] + S[:h, :w]) / (k * k)


def _smooth(a, sigma):
    """Gaussian blur (scipy) or integral-image box approximation."""
    if not _NP or sigma <= 0:
        return a
    if _SCI:
        return _sci.gaussian_filter(a, sigma)
    return _box_blur(a, int(round(sigma)))


def _scene_name(mean, std, sat):
    if mean < 0.28:
        return "dark"
    if mean > 0.62:
        return "bright"
    if std < 0.16:
        return "washout"
    if sat < 0.14:
        return "dull"
    return "normal"


def analyze_frame(rgb):
    """AI analysis of a frame (normalized RGB 0..1).

    Returns dict with:
      mean_luma, contrast (std), saturation, scene,
      avg (channel means), cast (0.5-avg per channel),
      exposure, auto_clarity, auto_contrast, auto_vibrance,
      tint_auto, tint_alpha, vib_color
    """
    if not _NP or rgb is None:
        return None
    r = rgb[:, :, 0]; g = rgb[:, :, 1]; b = rgb[:, :, 2]
    luma = 0.299 * r + 0.587 * g + 0.114 * b
    mean = float(luma.mean())
    std = float(luma.std())
    sat = float((np.maximum(np.maximum(r, g), b) -
                 np.minimum(np.minimum(r, g), b)).mean())
    avg = rgb.mean(axis=(0, 1))

    out = {
        "mean_luma": mean, "contrast": std, "saturation": sat,
        "scene": _scene_name(mean, std, sat),
        "avg": (float(avg[0]), float(avg[1]), float(avg[2])),
    }

    # exposure: nudge toward a comfortable ~0.45 mean
    if mean < 0.42:
        out["exposure"] = min(0.14, (0.46 - mean) * 0.40)
    elif mean > 0.60:
        out["exposure"] = -min(0.12, (mean - 0.60) * 0.30)
    else:
        out["exposure"] = 0.0

    # auto clarity: strong on washed-out, baseline on all scenes
    if std < 0.16 and mean >= 0.28:
        auto_clarity = 0.75
    elif std < 0.22:
        auto_clarity = 0.55
    else:
        auto_clarity = 0.30
    if mean < 0.30:
        auto_clarity = max(auto_clarity, 0.45)
    out["auto_clarity"] = auto_clarity

    # auto midtone contrast (depth on dull scenes)
    out["auto_contrast"] = (0.60 if std < 0.18
                            else 0.35 if std < 0.25 else 0.15)

    # auto vibrance (dull scenes get the scene's own color pushed back in)
    out["auto_vibrance"] = (0.90 if sat < 0.16
                            else 0.50 if sat < 0.25 else 0.15)

    # mood tint: cool for dark, warm for bright, subtle cool mid
    if mean < 0.28:
        mood = (0.45, 0.55, 1.00); mood_alpha = 0.10
    elif mean > 0.62:
        mood = (1.00, 0.82, 0.65); mood_alpha = 0.08
    else:
        mood = (0.30, 0.55, 1.00); mood_alpha = 0.05

    # white balance from the scene cast (the true "smart auto color")
    wb = tuple(max(-0.30, min(0.30, (0.5 - out["avg"][i]) * 0.8)) for i in range(3))
    w = min(0.50, (abs(wb[0]) + abs(wb[1]) + abs(wb[2])) * 1.6)
    tint = tuple(mood[i] * (1.0 - w) + (0.5 + wb[i]) * w for i in range(3))
    out["mood"] = mood
    out["wb"] = wb
    out["tint_auto"] = tuple(max(0.0, min(1.0, t)) for t in tint)
    out["tint_alpha"] = mood_alpha * (1.0 - 0.5 * w) + 0.04

    # vibrance color: the scene's own average hue, pushed toward saturation
    mn, mx = min(out["avg"]), max(out["avg"])
    if mx - mn < 0.03:
        out["vib_color"] = (0.45, 0.55, 1.00)
    else:
        out["vib_color"] = tuple(max(0.0, min(1.0, v * 1.7)) for v in out["avg"])
    return out


def build_detail_masks(rgb, strength):
    """ADVANCED CLARITY: multi-scale unsharp detail boost.

    fine   = luma - blur(luma, 0.8)      -> texture
    struct = blur(0.8) - blur(2.2)       -> large shapes/edges
    detail = fine + 0.55*struct, scaled by strength, then auto-normalized
    (98th percentile cap) so it never over-amplifies noise.
    Returns (white_rgba, black_rgba) numpy arrays at the sampled size."""
    if not _NP or rgb is None or strength <= 0.02:
        return None
    luma = 0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]
    b1 = _smooth(luma, 0.8)
    b2 = _smooth(luma, 2.2)
    d = (luma - b1 + 0.55 * (b1 - b2)) * (strength * 2.6)
    p = float(np.percentile(np.abs(d), 98))
    if p > 1e-4:
        d = d * min(1.0, 0.50 / p)
    h, w = luma.shape
    white = np.zeros((h, w, 4), dtype=np.uint8)
    black = np.zeros((h, w, 4), dtype=np.uint8)
    white[:, :, 0] = white[:, :, 1] = white[:, :, 2] = 255
    white[:, :, 3] = (np.clip(d, 0, 1) * 255 * 0.90).astype(np.uint8)
    black[:, :, 3] = (np.clip(-d, 0, 1) * 255 * 0.80).astype(np.uint8)
    return white, black


def build_midtone_mask(rgb, contrast):
    """Global midtone-contrast curve: darkens midtones (where eyes live)
    for depth without crushing shadows/highlights. Returns black RGBA."""
    if not _NP or rgb is None or contrast <= 0.02:
        return None
    luma = 0.299 * rgb[:, :, 0] + 0.587 * rgb[:, :, 1] + 0.114 * rgb[:, :, 2]
    mid = np.clip(1.0 - np.abs(luma - 0.5) * 2.0, 0.0, 1.0)
    a = (mid ** 1.6) * (contrast * 0.40)
    h, w = luma.shape
    arr = np.zeros((h, w, 4), dtype=np.uint8)
    arr[:, :, 3] = (np.clip(a, 0, 1) * 255).astype(np.uint8)
    return arr


def _surface_from_rgba(arr):
    import cairo
    h, w = arr.shape[:2]
    srf = cairo.ImageSurface(cairo.FORMAT_ARGB32, w, h)
    srf.flush()
    data = srf.get_data()
    # cairo ARGB32 memory is native-endian (little-endian -> BGRA on disk)
    buf = np.frombuffer(data, dtype=np.uint8).reshape(h, w, 4)
    buf[:, :, 0] = arr[:, :, 2]  # B
    buf[:, :, 1] = arr[:, :, 1]  # G
    buf[:, :, 2] = arr[:, :, 0]  # R
    buf[:, :, 3] = arr[:, :, 3]  # A
    srf.mark_dirty()
    return srf


def _shift_temperature(tint, temp):
    r = max(0.0, min(1.0, tint[0] + temp * 0.12))
    b = max(0.0, min(1.0, tint[2] - temp * 0.12))
    return (r, tint[1], b)


class SmartOverlay(object):
    """Always-on-top, click-through RGBA layer aligned to the mirror window.

    Drive it with tick() from a fast main-loop timer (~15Hz); it self-
    throttles the expensive parts (geometry 4Hz, scene analysis 10Hz)."""

    def __init__(self, title="PadLink Smart Layer"):
        self.title = title
        self.win = None
        self.xid = None
        self.geo = (0, 0, 100, 100)
        self.enabled = True
        self.auto = True
        self.tint = (0.30, 0.55, 1.00)      # user color (0..1)
        self.opacity = 0.12                  # master strength (user)
        self.user_clarity = 0.0
        self.user_exposure = 0.0
        self.user_saturation = 0.0
        self.user_contrast = 0.0
        self.user_temperature = 0.0
        self.analyze_period = AN_PERIOD
        self._stats_cb = None
        self.last_scene = None
        self._mirror_ok = False
        self._gdkwin = None
        self._surfaces = (None, None, None)  # white detail, black detail, midtone
        self.mask_w = self.mask_h = 0
        # smoothing state (shown) vs target (analysis output)
        self._s = {"exp": 0.0, "cla": 0.0, "mid": 0.0, "ta": 0.0, "vib": 0.0,
                   "tint": (0.30, 0.55, 1.00), "vibc": (0.45, 0.55, 1.00)}
        self._t = dict(self._s)
        for k in ("tint", "vibc"):
            self._t[k] = tuple(self._s[k])
        self._last_geo = 0.0
        self._last_an = 0.0
        self._last_stats = 0.0
        self._last_tick = 0.0
        self._an_count = 0
        self._hz_t0 = 0.0
        self._last_hz = 0.0
        self._dirty = True

    # ---------- lifecycle ----------
    def start(self):
        if self.win is not None:
            return
        if Gdk is None:
            return
        try:
            import cairo
            import gi
            gi.require_version("Gtk", "3.0")
            from gi.repository import Gtk
        except Exception:
            return
        w = Gtk.Window.new(Gtk.WindowType.POPUP)
        w.set_title(self.title)
        w.set_decorated(False)
        w.set_app_paintable(True)
        w.set_keep_above(True)
        w.set_skip_taskbar_hint(True)
        w.set_skip_pager_hint(True)
        w.set_accept_focus(False)
        w.set_focus_on_map(False)
        screen = w.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            w.set_visual(visual)
        w.set_size_request(10, 10)
        w.move(0, 0)
        w.show_all()
        w.realize()
        # click-through: empty input shape
        try:
            gdkw = w.get_window()
            if gdkw is not None:
                try:
                    region = cairo.Region()
                    gdkw.input_shape_combine_region(region, 0, 0)
                except Exception:
                    pass
        except Exception:
            pass
        w.connect("draw", self._on_draw)
        self._Gtk = Gtk
        self.win = w

    def stop(self):
        if self.win is not None:
            try:
                self.win.destroy()
            except Exception:
                pass
        self.win = None
        self._mirror_ok = False
        self._surfaces = (None, None, None)
        self._dirty = True

    # ---------- fast main-loop hook ----------
    def tick(self):
        """Call from a ~66ms timer. Self-throttles:
        geometry @ ~4Hz, scene analysis @ 10Hz, smoothing @ 15Hz."""
        if self.win is None or not self.enabled:
            return
        now = time.time()
        dt = min(0.25, now - self._last_tick) if self._last_tick else 0.066
        self._last_tick = now
        if now - self._last_geo > GEO_PERIOD:
            self._last_geo = now
            if not self._track_geometry():
                return
        if self.xid is not None and now - self._last_an >= self.analyze_period:
            self._last_an = now
            self._analyze()
        self._smooth(dt)
        if self._dirty:
            self._dirty = False
            try:
                self.win.queue_draw()
            except Exception:
                pass

    # ---------- tracking ----------
    def _track_geometry(self):
        xid = find_mirror_xid()
        if xid is None:
            if self._mirror_ok:
                try:
                    self.win.hide()
                except Exception:
                    pass
                self._mirror_ok = False
            self.xid = None
            return False
        if xid != self.xid:
            self._gdkwin = None
            self._last_an = 0.0
        self.xid = xid
        geo = find_mirror_geometry(xid)
        if geo and geo.get("WIDTH"):
            gx, gy = geo.get("X", 0), geo.get("Y", 0)
            gw, gh = geo.get("WIDTH", 100), geo.get("HEIGHT", 100)
            if (gx, gy, gw, gh) != self.geo:
                self.geo = (gx, gy, gw, gh)
                try:
                    self.win.move(gx, gy)
                    self.win.resize(gw, gh)
                except Exception:
                    pass
        if not self._mirror_ok:
            try:
                self.win.show_all()
            except Exception:
                pass
            self._mirror_ok = True
            self._dirty = True
        return True

    # ---------- scene engine ----------
    def _analyze(self):
        gw, gh = self.geo[2], self.geo[3]
        rgb = grab_window(self.xid, gw, gh)
        st = analyze_frame(rgb) if rgb is not None else None
        if st is None:
            return
        self.last_scene = st
        # real analysis rate (for the chip)
        now = time.time()
        self._an_count += 1
        if self._hz_t0 == 0:
            self._hz_t0 = now
        if now - self._hz_t0 >= 1.0:
            self._last_hz = self._an_count / (now - self._hz_t0)
            self._an_count = 0
            self._hz_t0 = now
        if self.auto:
            self._set_auto_targets(st)
        else:
            self._set_manual_targets(st)
        # rebuild the clarity/contrast masks at the sampled resolution
        if rgb is not None:
            d = build_detail_masks(rgb, self._t["cla"])
            m = build_midtone_mask(rgb, self._t["mid"])
            ws = bs = ms = None
            if d:
                ws, bs = d
            if m:
                ms = m
            if ws is not None or ms is not None:
                base = ws if ws is not None else ms
                self._surfaces = (ws, bs, ms)
                self.mask_w, self.mask_h = base.shape[1], base.shape[0]
            else:
                self._surfaces = (None, None, None)
        else:
            self._surfaces = (None, None, None)
        # UI status (1Hz)
        if self._stats_cb and now - self._last_stats > STATS_PERIOD:
            self._last_stats = now
            try:
                self._stats_cb({
                    "scene": st["scene"],
                    "mean_luma": st["mean_luma"],
                    "contrast": st["contrast"],
                    "saturation": st["saturation"],
                    "hz": self._last_hz or (1.0 / self.analyze_period),
                })
            except Exception:
                pass
        self._dirty = True

    def _set_auto_targets(self, st):
        # exposure: auto scene correction + user bias
        exp = st["exposure"] + self.user_exposure * 0.25
        self._t["exp"] = max(-0.22, min(0.22, exp))
        # clarity: auto scene level + user boost
        cla = st["auto_clarity"] + self.user_clarity * 0.6
        self._t["cla"] = min(1.6, cla)
        # midtone depth: auto + user
        mid = st["auto_contrast"] + self.user_contrast * 0.7
        self._t["mid"] = min(1.2, mid)
        # vibrance: auto (dull scenes) + user
        vib = st["auto_vibrance"] + self.user_saturation * 0.7
        self._t["vib"] = min(1.2, vib)
        self._t["vibc"] = st["vib_color"]
        # smart tint: mood + white balance, 20% user color, temperature
        tint = tuple(st["tint_auto"][i] * 0.8 + self.tint[i] * 0.2 for i in range(3))
        self._t["tint"] = _shift_temperature(tint, self.user_temperature)
        self._t["ta"] = st["tint_alpha"]

    def _set_manual_targets(self, st):
        self._t["exp"] = max(-0.22, min(0.22, self.user_exposure * 0.40))
        self._t["cla"] = max(0.0, min(1.6, self.user_clarity * 1.2))
        self._t["mid"] = max(0.0, min(1.2, self.user_contrast))
        self._t["vib"] = max(0.0, min(1.2, self.user_saturation))
        self._t["vibc"] = st["vib_color"]
        self._t["tint"] = _shift_temperature(self.tint, self.user_temperature)
        self._t["ta"] = 0.12

    def _smooth(self, dt):
        """Exponential ease shown values toward targets (no flicker)."""
        k1 = 1.0 - math.exp(-dt / 0.18)
        k2 = 1.0 - math.exp(-dt / 0.30)
        s, t = self._s, self._t
        for key in ("exp", "cla", "mid", "ta", "vib"):
            d = t[key] - s[key]
            if abs(d) > 0.004:
                s[key] += d * k1
                self._dirty = True
        for key in ("tint", "vibc"):
            c, g = s[key], t[key]
            d = sum(abs(g[j] - c[j]) for j in range(3))
            if d > 0.01:
                s[key] = tuple(c[j] + (g[j] - c[j]) * k2 for j in range(3))
                self._dirty = True

    # ---------- drawing ----------
    def _on_draw(self, wdg, cr):
        import cairo
        W, H = wdg.get_allocation().width, wdg.get_allocation().height
        if W <= 0 or H <= 0:
            return
        # transparent base
        cr.set_operator(cairo.OPERATOR_SOURCE)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        if not self.enabled:
            return
        cr.set_operator(cairo.OPERATOR_OVER)
        s = self._s
        # 1) exposure layer
        e = s["exp"]
        gain = 0.5 + 1.5 * self.opacity
        if e > 0.002:
            cr.set_source_rgba(1, 1, 1, min(0.22, e) * gain)
            cr.paint()
        elif e < -0.002:
            cr.set_source_rgba(0, 0, 0, min(0.20, -e) * gain)
            cr.paint()
        # 2) advanced clarity masks (local detail + midtone depth)
        ws, bs, ms = self._surfaces
        if (ws is not None or ms is not None) and self.mask_w > 0:
            cr.save()
            cr.scale(W / float(self.mask_w), H / float(self.mask_h))
            if ws is not None:
                cr.set_source_surface(ws, 0, 0)
                cr.paint()
            if bs is not None:
                cr.set_source_surface(bs, 0, 0)
                cr.paint()
            if ms is not None:
                cr.set_source_surface(ms, 0, 0)
                cr.paint()
            cr.restore()
        # 3) smart color layer (OVERLAY blend for vibrance when affordable)
        tr, tg, tb = s["tint"]
        a = s["ta"] * (0.5 + 1.6 * self.opacity)
        v = s["vib"]
        if a > 0.002 or v > 0.05:
            use_overlay = (v > 0.08 and W * H <= _BIG_WINDOW_PX and
                           hasattr(cairo, "OPERATOR_OVERLAY"))
            if use_overlay:
                cr.set_operator(cairo.OPERATOR_OVERLAY)
                vr, vg, vb = s["vibc"]
                m = 0.35 + 0.40 * min(1.0, v)
                mr = tr * (1.0 - m) + vr * m
                mg = tg * (1.0 - m) + vg * m
                mb = tb * (1.0 - m) + vb * m
                alpha = min(0.40, a + v * 0.16 * (0.5 + 1.2 * self.opacity))
            else:
                mr, mg, mb = tr, tg, tb
                alpha = min(0.40, a)
            cr.set_source_rgba(mr, mg, mb, alpha)
            cr.paint()
            cr.set_operator(cairo.OPERATOR_OVER)
        # 4) subtle accent border in the current smart color
        cr.set_line_width(1.5)
        cr.set_source_rgba(tr, tg, tb, 0.25)
        cr.rectangle(0.75, 0.75, W - 1.5, H - 1.5)
        cr.stroke()
        # 5) live AI chip
        self._draw_chip(cr, W)

    def _draw_chip(self, cr, W):
        try:
            import cairo
            hz = int(round(self._last_hz)) if self._last_hz else \
                int(round(1.0 / self.analyze_period))
            txt = "AI %s %dHz" % ("AUTO" if self.auto else "MAN", max(1, hz))
            cr.select_font_face("Monospace", cairo.FONT_SLANT_NORMAL,
                                cairo.FONT_WEIGHT_BOLD)
            cr.set_font_size(10)
            ext = cr.text_extents(txt)
            pad = 6.0
            ch = 17.0
            cw = ext.width + pad * 2 + 10.0
            x, y = 6.0, 6.0
            # rounded background
            r = 5.0
            cr.new_sub_path()
            cr.arc(x + cw - r, y + r, r, -math.pi / 2, 0)
            cr.arc(x + cw - r, y + ch - r, r, 0, math.pi / 2)
            cr.arc(x + r, y + ch - r, r, math.pi / 2, math.pi)
            cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
            cr.close_path()
            cr.set_source_rgba(0, 0, 0, 0.38)
            cr.fill()
            # smart-color dot
            tr, tg, tb = self._s["tint"]
            cr.set_source_rgba(tr, tg, tb, 0.95)
            cr.arc(x + 8, y + ch / 2, 3, 0, 2 * math.pi)
            cr.fill()
            # text
            cr.set_source_rgba(1, 1, 1, 0.85)
            cr.move_to(x + pad + 9, y + ch / 2 - ext.y_center)
            cr.show_text(txt)
        except Exception:
            pass

    # ---------- public API ----------
    def set_enabled(self, on):
        self.enabled = on
        if self.win is not None:
            try:
                if on:
                    self.win.show_all()
                else:
                    self.win.hide()
            except Exception:
                pass
        self._dirty = True

    def set_stats_cb(self, cb):
        self._stats_cb = cb

    def set_params(self, auto=None, opacity=None, tint=None, clarity=None,
                   exposure=None, saturation=None, contrast=None,
                   temperature=None):
        if auto is not None:
            self.auto = bool(auto)
        if opacity is not None:
            self.opacity = max(0.0, min(1.0, float(opacity)))
        if tint is not None:
            self.tint = tuple(max(0.0, min(1.0, float(c))) for c in tint)
        if clarity is not None:
            self.user_clarity = max(0.0, min(1.0, float(clarity)))
        if exposure is not None:
            self.user_exposure = max(-0.5, min(0.5, float(exposure)))
        if saturation is not None:
            self.user_saturation = max(0.0, min(1.0, float(saturation)))
        if contrast is not None:
            self.user_contrast = max(0.0, min(1.0, float(contrast)))
        if temperature is not None:
            self.user_temperature = max(-0.5, min(0.5, float(temperature)))
        self._dirty = True
        if self.win is not None:
            try:
                self.win.queue_draw()
            except Exception:
                pass
