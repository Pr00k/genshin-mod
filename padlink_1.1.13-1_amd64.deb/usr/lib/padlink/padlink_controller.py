#!/usr/bin/env python3
# ============================================================================
# PadLinkController v2 - PRO VECTOR CONTROLLER MODEL (no photos).
#
# A parametric Xbox-360-style gamepad drawn ENTIRELY with cairo vectors and
# gradients - a pseudo-3D model on a professional dark stage with a
# spotlight: body shading + glossy highlights, recessed stick wells, 3D
# stick caps, colored face buttons, the green guide sphere, bumpers and
# triggers with live fill levels.
#
# LIVE EFFECTS (same API as v1):
#   * stick caps follow the axes (eased), glow while moved, orange ring
#     on stick click (LS/RS)
#   * LT/RT triggers with live fill level + label
#   * LB/RB bumper glow
#   * A/B/X/Y press glow + press sink
#   * D-pad directional glow
#   * guide button idle pulse + press glow
#   * view / menu / share glows
#
# Public API (unchanged): ControllerState, PadLinkController (set_state /
# update / draw / auto_calibrate), render(), idle_state(), example_state().
# Pure ASCII source.
# ============================================================================
import math

try:
    import cairo
except Exception:
    cairo = None

DEADZONE = 0.10
EASE = 14.0
STICK_EASE = 12.0

# Model space: everything is designed in a 100 x 70 unit box, then
# uniformly scaled into the drawing area (vector = perfect at any size).
MX, MY = 100.0, 70.0


def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, v))


def norm_axis(x, y, dead=DEADZONE):
    x = max(-1.0, min(1.0, x))
    y = max(-1.0, min(1.0, y))
    length = math.hypot(x, y)
    if length < dead or length == 0.0:
        return 0.0, 0.0
    # scale along the input direction; result length is always <= 1 so the
    # stick cap never leaves the circular well (even on diagonals)
    s = min(1.0, (length - dead) / (1.0 - dead))
    return (x / length) * s, (y / length) * s


class ControllerState(object):
    def __init__(self):
        self.A = self.B = self.X = self.Y = False
        self.LB = self.RB = False
        self.LT = self.RT = 0.0
        self.LX = self.LY = self.RX = self.RY = 0.0
        self.DU = self.DD = self.DL = self.DR = False
        self.Xbox = self.View = self.Menu = self.Share = False
        self.LS = self.RS = False  # stick click (push)


class Component(object):
    def __init__(self, cid, fx, fy):
        self.id = cid
        self.fx = fx
        self.fy = fy
        self.press = 0.0
        self.value = 0.0
        self.sx = 0.0
        self.sy = 0.0
        self.dirty = True

    def update(self, dt):
        raise NotImplementedError


class DigitalButton(Component):
    def __init__(self, cid, fx, fy, label="", color=None, radius=0.03):
        super(DigitalButton, self).__init__(cid, fx, fy)
        self.radius = radius
        self.label = label
        self.color = color

    def set_target(self, on):
        t = 1.0 if on else 0.0
        if abs(t - self.value) > 1e-9:
            self.value = t
            self.dirty = True

    def update(self, dt):
        if abs(self.press - self.value) > 0.0005:
            self.press += (self.value - self.press) * min(1.0, dt * EASE)
            self.dirty = True
            return True
        self.press = self.value
        return False


class AnalogTrigger(Component):
    def __init__(self, cid, fx, fy, w, h, label="", angle=0.0):
        super(AnalogTrigger, self).__init__(cid, fx, fy)
        self.w = w
        self.h = h
        self.label = label
        self.angle = angle

    def set_target(self, v):
        v = clamp(float(v), 0.0, 1.0)
        if abs(v - self.value) > 1e-4:
            self.value = v
            self.dirty = True

    def update(self, dt):
        if abs(self.press - self.value) > 0.0005:
            self.press += (self.value - self.press) * min(1.0, dt * EASE)
            self.dirty = True
            return True
        self.press = self.value
        return False


class AnalogStick(Component):
    def __init__(self, cid, fx, fy, r):
        super(AnalogStick, self).__init__(cid, fx, fy)
        self.r = r
        self.px = 0.0
        self.py = 0.0

    def set_target(self, x, y):
        nx, ny = norm_axis(x, y)
        if abs(nx - self.sx) > 1e-4 or abs(ny - self.sy) > 1e-4:
            self.sx = nx
            self.sy = ny
            self.dirty = True

    def update(self, dt):
        moved = False
        if abs(self.px - self.sx) > 0.0005:
            self.px += (self.sx - self.px) * min(1.0, dt * STICK_EASE)
            self.dirty = True
            moved = True
        if abs(self.py - self.sy) > 0.0005:
            self.py += (self.sy - self.py) * min(1.0, dt * STICK_EASE)
            self.dirty = True
            moved = True
        return moved


def circ(cr, cx, cy, r):
    cr.new_path()
    cr.arc(cx, cy, r, 0, 2 * math.pi)
    cr.close_path()


def rr_path(cr, x, y, w, h, r):
    r = min(r, w / 2.0, h / 2.0)
    cr.new_path()
    cr.arc(x + r, y + r, r, math.pi, 1.5 * math.pi)
    cr.arc(x + w - r, y + r, r, 1.5 * math.pi, 2 * math.pi)
    cr.arc(x + w - r, y + h - r, r, 0, 0.5 * math.pi)
    cr.arc(x + r, y + h - r, r, 0.5 * math.pi, math.pi)
    cr.close_path()


# ---------- font-independent vector letters ----------
# Every label is drawn as stroke paths, so the model renders identically
# on ANY system - no font lookup, no tofu boxes, no missing glyphs.
# Glyphs live on a 6 x 8 grid; segments are (x1, y1, x2, y2).
_VG = {
    "A": [(0, 8, 3, 0), (3, 0, 6, 8), (1.3, 5.1, 4.7, 5.1)],
    "B": [(0, 0, 0, 8), (0, 0, 4.0, 0), (4.0, 0, 5.0, 1.1),
          (5.0, 1.1, 5.0, 2.9), (5.0, 2.9, 4.0, 4), (4.0, 4, 0, 4),
          (0, 4, 4.6, 4), (4.6, 4, 5.7, 5.2), (5.7, 5.2, 5.7, 6.9),
          (5.7, 6.9, 4.6, 8), (4.6, 8, 0, 8)],
    "C": [(6, 1.2, 4.2, 0), (4.2, 0, 1.4, 0.7), (1.4, 0.7, 0, 3),
          (0, 3, 0, 5), (0, 5, 1.4, 7.3), (1.4, 7.3, 4.2, 8), (4.2, 8, 6, 6.8)],
    "E": [(6, 0, 0, 0), (0, 0, 0, 8), (0, 8, 6, 8), (0, 4, 4.4, 4)],
    "L": [(0, 0, 0, 8), (0, 8, 6, 8)],
    "R": [(0, 8, 0, 0), (0, 0, 4.2, 0), (4.2, 0, 5.3, 1.2),
          (5.3, 1.2, 5.3, 2.8), (5.3, 2.8, 4.2, 4), (4.2, 4, 0, 4),
          (2.3, 4, 6, 8)],
    "S": [(5.8, 1, 4.2, 0.2), (4.2, 0.2, 1.5, 0.2), (1.5, 0.2, 0.2, 1.8),
          (0.2, 1.8, 0.2, 3.1), (0.2, 3.1, 2.6, 4.6), (2.6, 4.6, 4.9, 6.1),
          (4.9, 6.1, 5.9, 7.6), (5.9, 7.6, 4.1, 8.2), (4.1, 8.2, 0.9, 8)],
    "T": [(0, 0, 6, 0), (3, 0, 3, 8)],
    "X": [(0, 0, 6, 8), (6, 0, 0, 8)],
    "Y": [(0, 0, 3, 4.2), (3, 4.2, 6, 0), (3, 4.2, 3, 8)],
}
_VG_W, _VG_H = 6.0, 8.0


def _vpath(cr, txt, x0, oy, sc):
    n = len(txt)
    sp = _VG_W * 0.32
    for i, ch in enumerate(txt):
        g = _VG.get(ch)
        if g is None:
            continue
        ox = x0 + i * (_VG_W + sp) * sc
        for (x1, y1, x2, y2) in g:
            cr.move_to(ox + x1 * sc, oy + y1 * sc)
            cr.line_to(ox + x2 * sc, oy + y2 * sc)


def _vtext(cr, cx, cy, size, txt, rgb, alpha, shadow=True):
    """Vector lettering centered at (cx, cy) with cap height `size`.
    Same signature as _text - a drop-in that can never turn into boxes."""
    txt = txt or ""
    if not txt:
        return
    n = len(txt)
    sp = _VG_W * 0.32
    total = (_VG_W * n + sp * (n - 1)) * size / _VG_H
    x0 = cx - total / 2.0
    oy = cy - size / 2.0
    sc = size / _VG_H
    cr.save()
    cr.set_line_cap(cairo.LINE_CAP_ROUND)
    cr.set_line_join(cairo.LINE_JOIN_ROUND)
    cr.set_line_width(max(0.09, size * 0.155))
    if shadow:
        cr.translate(0.05, 0.06)
        _vpath(cr, txt, x0, oy, sc)
        cr.set_source_rgba(0, 0, 0, 0.62 * alpha)
        cr.stroke()
        cr.translate(-0.10, -0.12)
    _vpath(cr, txt, x0, oy, sc)
    cr.set_source_rgba(rgb[0], rgb[1], rgb[2], alpha)
    cr.stroke()
    cr.restore()


def _text(cr, cx, cy, size, txt, rgb, alpha, shadow=True):
    """Centered bold letter with a dark shadow for readability."""
    cr.select_font_face("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
    cr.set_font_size(size)
    ext = cr.text_extents(txt)
    ox = cx - ext.width / 2 - ext.x_bearing
    oy = cy - ext.height / 2 - ext.y_bearing
    if shadow:
        cr.set_source_rgba(0, 0, 0, 0.60)
        cr.move_to(ox + 0.12, oy + 0.14)
        cr.show_text(txt)
    cr.set_source_rgba(rgb[0], rgb[1], rgb[2], alpha)
    cr.move_to(ox, oy)
    cr.show_text(txt)


def _body_path(cr):
    """Xbox-360-style body outline in model space (symmetric beziers)."""
    cr.new_path()
    cr.move_to(50, 15)
    cr.curve_to(64, 13.5, 76, 14.5, 82, 19)      # top edge -> right shoulder
    cr.curve_to(88, 23, 93, 27, 92, 33)          # shoulder -> outer right
    cr.curve_to(91, 43, 87, 55, 78, 62)          # outer right -> grip end
    cr.curve_to(72, 66.5, 66, 60, 63, 52)        # grip end -> grip inner
    cr.curve_to(58, 46.5, 54, 46, 50, 46)        # inner -> bottom center
    cr.curve_to(46, 46, 42, 46.5, 37, 52)
    cr.curve_to(34, 60, 28, 66.5, 22, 62)
    cr.curve_to(13, 55, 9, 43, 8, 33)
    cr.curve_to(7, 27, 12, 23, 18, 19)
    cr.curve_to(24, 14.5, 36, 13.5, 50, 15)      # back to top center
    cr.close_path()


def _dpad_path(cr, cx, cy, L, wdt):
    cr.new_path()
    cr.move_to(cx - wdt * 0.55, cy - L)
    cr.line_to(cx + wdt * 0.55, cy - L)
    cr.line_to(cx + wdt * 0.55, cy - wdt * 0.55)
    cr.line_to(cx + L, cy - wdt * 0.55)
    cr.line_to(cx + L, cy + wdt * 0.55)
    cr.line_to(cx + wdt * 0.55, cy + wdt * 0.55)
    cr.line_to(cx + wdt * 0.55, cy + L)
    cr.line_to(cx - wdt * 0.55, cy + L)
    cr.line_to(cx - wdt * 0.55, cy + wdt * 0.55)
    cr.line_to(cx - L, cy + wdt * 0.55)
    cr.line_to(cx - L, cy - wdt * 0.55)
    cr.line_to(cx - wdt * 0.55, cy - wdt * 0.55)
    cr.close_path()


class PadLinkController(object):
    """Pro vector controller model + live effects. No photos involved:
    every part is parametric, so calibration is exact by construction."""

    def __init__(self):
        self.state = ControllerState()
        self.ls_press = False
        self.rs_press = False
        self.t = 0.0

        # ---- positions in normalized model space (model is 100 x 70) ----
        # shoulder row (behind the body top edge)
        self.lt = AnalogTrigger("controller-lt", 0.20, 0.078, 14, 9, "LT", -30)
        self.rt = AnalogTrigger("controller-rt", 0.80, 0.078, 14, 9, "RT", 30)
        self.lb = DigitalButton("controller-lb", 0.20, 0.185, "LB", radius=0.070)
        self.rb = DigitalButton("controller-rb", 0.80, 0.185, "RB", radius=0.070)

        # front face (Xbox 360 layout, verified: no overlaps, real proportions)
        self.lstick = AnalogStick("controller-left-stick", 0.29, 0.379, 0.085)
        self.rstick = AnalogStick("controller-right-stick", 0.68, 0.629, 0.085)
        self.DCX, self.DCY = 0.38, 0.593
        self.dpad_up = DigitalButton("controller-dpad-up", 0.38, 0.593 - 0.078, radius=0.016)
        self.dpad_dn = DigitalButton("controller-dpad-down", 0.38, 0.593 + 0.078, radius=0.016)
        self.dpad_lt = DigitalButton("controller-dpad-left", 0.38 - 0.078, 0.593, radius=0.016)
        self.dpad_rt = DigitalButton("controller-dpad-right", 0.38 + 0.078, 0.593, radius=0.016)
        self.btn_a = DigitalButton("controller-a", 0.685, 0.442, "A", (0.13, 0.65, 0.22), radius=0.042)
        self.btn_b = DigitalButton("controller-b", 0.740, 0.364, "B", (0.80, 0.22, 0.19), radius=0.042)
        self.btn_x = DigitalButton("controller-x", 0.630, 0.364, "X", (0.22, 0.47, 0.88), radius=0.042)
        self.btn_y = DigitalButton("controller-y", 0.685, 0.286, "Y", (0.92, 0.79, 0.16), radius=0.042)
        self.guide = DigitalButton("controller-xbox", 0.50, 0.307, radius=0.046)
        self.view = DigitalButton("controller-view", 0.435, 0.429, radius=0.026)
        self.menu = DigitalButton("controller-menu", 0.565, 0.429, radius=0.026)
        self.share = DigitalButton("controller-share", 0.50, 0.507, radius=0.020)

        self.components = [
            self.lt, self.rt, self.lb, self.rb,
            self.lstick, self.rstick,
            self.dpad_up, self.dpad_dn, self.dpad_lt, self.dpad_rt,
            self.btn_a, self.btn_b, self.btn_x, self.btn_y,
            self.guide, self.view, self.menu, self.share,
        ]

    # ---------- state ----------
    def set_state(self, st):
        self.state = st
        self.lt.set_target(st.LT); self.rt.set_target(st.RT)
        self.lb.set_target(st.LB); self.rb.set_target(st.RB)
        self.lstick.set_target(st.LX, st.LY)
        self.rstick.set_target(st.RX, st.RY)
        self.ls_press = bool(getattr(st, "LS", False))
        self.rs_press = bool(getattr(st, "RS", False))
        self.dpad_up.set_target(st.DU); self.dpad_dn.set_target(st.DD)
        self.dpad_lt.set_target(st.DL); self.dpad_rt.set_target(st.DR)
        self.btn_a.set_target(st.A); self.btn_b.set_target(st.B)
        self.btn_x.set_target(st.X); self.btn_y.set_target(st.Y)
        self.guide.set_target(st.Xbox)
        self.view.set_target(st.View); self.menu.set_target(st.Menu)
        self.share.set_target(st.Share)

    def update(self, dt):
        self.t += dt
        animating = False
        for c in self.components:
            if c.update(dt):
                animating = True
        return animating

    def clear_dirty(self):
        for c in self.components:
            c.dirty = False

    def auto_calibrate(self):
        """The model is parametric: every control position is exact by
        construction - calibration is instant and lossless."""
        return ["مجسم متجهي احترافي (Xbox 360): المواضع معيارية 100% - لا حاجة لمعايرة صورة"]

    # ---------- drawing ----------
    def draw(self, cr, width, height):
        if cairo is None:
            return
        s = min(width / MX, height / MY) * 0.94
        ox = (width - MX * s) / 2.0
        oy = (height - MY * s) / 2.0

        self._draw_stage(cr, width, height)

        cr.save()
        cr.translate(ox, oy)
        cr.scale(s, s)
        self._draw_halo(cr)
        self._draw_shadow(cr)
        self._draw_cable(cr)
        self._draw_trigger(cr, self.lt)
        self._draw_trigger(cr, self.rt)
        self._draw_bumper(cr, self.lb)
        self._draw_bumper(cr, self.rb)
        self._draw_body(cr)
        self._draw_dpad(cr)
        self._draw_stick(cr, self.lstick, self.ls_press, "LS")
        self._draw_stick(cr, self.rstick, self.rs_press, "RS")
        for b in (self.btn_y, self.btn_x, self.btn_b, self.btn_a):
            self._draw_face(cr, b)
        self._draw_guide(cr)
        self._draw_pill(cr, self.view, "view", "SELECT")
        self._draw_pill(cr, self.menu, "menu", "START")
        self._draw_pill(cr, self.share, "dot", "")
        cr.restore()

    def _draw_stage(self, cr, W, H):
        """Dark stage, lighter than the body used to hide: the pad must
        read as a clear silhouette at a glance."""
        g = cairo.LinearGradient(0, 0, 0, H)
        g.add_color_stop_rgba(0, 0.085, 0.09, 0.105, 1)
        g.add_color_stop_rgba(1, 0.125, 0.135, 0.16, 1)
        cr.set_source(g)
        cr.rectangle(0, 0, W, H)
        cr.fill()
        cx, cy = W / 2.0, H * 0.46
        r = min(W, H) * 0.62
        sp = cairo.RadialGradient(cx, cy, 0, cx, cy, r)
        sp.add_color_stop_rgba(0, 1, 1, 1, 0.10)
        sp.add_color_stop_rgba(1, 1, 1, 1, 0)
        cr.set_source(sp)
        cr.paint()
        vg = cairo.RadialGradient(cx, cy, min(W, H) * 0.38, cx, cy, max(W, H) * 0.72)
        vg.add_color_stop_rgba(0, 0, 0, 0, 0)
        vg.add_color_stop_rgba(1, 0, 0, 0, 0.30)
        cr.set_source(vg)
        cr.paint()

    def _draw_halo(self, cr):
        """Bright halo behind the pad for clear silhouette separation."""
        g = cairo.RadialGradient(50, 36, 6, 50, 36, 46)
        g.add_color_stop_rgba(0, 0.75, 0.85, 1.0, 0.16)
        g.add_color_stop_rgba(0.7, 0.75, 0.85, 1.0, 0.05)
        g.add_color_stop_rgba(1, 0.75, 0.85, 1.0, 0)
        cr.set_source(g)
        circ(cr, 50, 36, 46)
        cr.fill()

    def _draw_shadow(self, cr):
        """Soft contact shadow under the body."""
        cr.save()
        cr.translate(50, 64.5)
        cr.scale(1.0, 0.16)
        g = cairo.RadialGradient(0, 0, 0, 0, 0, 38)
        g.add_color_stop_rgba(0, 0, 0, 0, 0.55)
        g.add_color_stop_rgba(0.75, 0, 0, 0, 0.22)
        g.add_color_stop_rgba(1, 0, 0, 0, 0)
        cr.set_source(g)
        circ(cr, 0, 0, 38)
        cr.fill()
        cr.restore()

    def _draw_cable(self, cr):
        """USB cable emerging from the top edge (drawn behind the body)."""
        cr.save()
        cr.set_line_cap(cairo.LINE_CAP_ROUND)
        cr.set_source_rgba(0.09, 0.095, 0.11, 1)
        cr.set_line_width(1.9)
        cr.move_to(50, -6)
        cr.curve_to(50, -1, 49.4, 6, 50, 16)
        cr.stroke()
        # connector nub just above the body edge
        cr.set_source_rgba(0.16, 0.17, 0.2, 1)
        rr_path(cr, 48.1, 8.5, 3.8, 7.5, 1.3)
        cr.fill_preserve()
        cr.set_source_rgba(0.4, 0.42, 0.48, 0.55)
        cr.set_line_width(0.35)
        cr.stroke()
        cr.set_source_rgba(1, 1, 1, 0.12)
        rr_path(cr, 48.5, 9.2, 1.1, 5.5, 0.5)
        cr.fill()
        cr.restore()

    def _draw_trigger(self, cr, tr):
        x, y = tr.fx * MX, tr.fy * MY
        w, h = 14.0, 9.0
        g = cairo.LinearGradient(0, y - h / 2, 0, y + h / 2)
        g.add_color_stop_rgba(0, 0.30, 0.32, 0.36, 1)
        g.add_color_stop_rgba(1, 0.18, 0.19, 0.22, 1)
        rr_path(cr, x - w / 2, y - h / 2, w, h, 3)
        cr.set_source(g)
        cr.fill_preserve()
        cr.set_source_rgba(0.5, 0.54, 0.6, 0.7)
        cr.set_line_width(0.5)
        cr.stroke()
        # live fill level
        if tr.press > 0.01:
            fh = h * clamp(tr.press, 0, 1)
            cr.save()
            rr_path(cr, x - w / 2, y - h / 2, w, h, 3)
            cr.clip()
            fg = cairo.LinearGradient(0, y - h / 2, 0, y - h / 2 + fh)
            fg.add_color_stop_rgba(0, 0.16, 0.95, 0.38, 0.92)
            fg.add_color_stop_rgba(1, 0.07, 0.45, 0.18, 0.92)
            cr.set_source(fg)
            cr.rectangle(x - w / 2, y - h / 2, w, fh)
            cr.fill()
            cr.set_source_rgba(1, 1, 1, 0.5)
            cr.set_line_width(0.4)
            cr.move_to(x - w / 2 + 1, y - h / 2 + fh)
            cr.line_to(x + w / 2 - 1, y - h / 2 + fh)
            cr.stroke()
            cr.restore()
        _vtext(cr, x, y, 2.9, tr.label, (1, 1, 1), 0.90)

    def _draw_bumper(self, cr, b):
        x, y = b.fx * MX, b.fy * MY
        w, h = 24.0, 11.0
        g = cairo.LinearGradient(0, y - h / 2, 0, y + h / 2)
        g.add_color_stop_rgba(0, 0.32, 0.34, 0.38, 1)
        g.add_color_stop_rgba(1, 0.20, 0.21, 0.24, 1)
        rr_path(cr, x - w / 2, y - h / 2, w, h, 5)
        cr.set_source(g)
        cr.fill_preserve()
        cr.set_source_rgba(0.5, 0.54, 0.6, 0.7)
        cr.set_line_width(0.5)
        cr.stroke()
        if b.press > 0.03:
            cr.save()
            rr_path(cr, x - w / 2, y - h / 2, w, h, 5)
            cr.set_source_rgba(0.18, 1.0, 0.35, 0.5 * b.press)
            cr.fill()
            cr.set_source_rgba(0.35, 1.0, 0.5, 0.85 * b.press)
            cr.set_line_width(0.7)
            cr.stroke()
            cr.restore()
        _vtext(cr, x, y, 3.1, b.label, (1, 1, 1), 0.80)

    def _draw_body(self, cr):
        _body_path(cr)
        g = cairo.LinearGradient(0, 13, 0, 66)
        g.add_color_stop_rgba(0, 0.40, 0.42, 0.465, 1)
        g.add_color_stop_rgba(0.45, 0.29, 0.305, 0.34, 1)
        g.add_color_stop_rgba(1, 0.18, 0.19, 0.215, 1)
        cr.set_source(g)
        cr.fill_preserve()
        # strong rim light + dark edge (clear silhouette)
        cr.set_source_rgba(0.9, 0.93, 1.0, 0.55)
        cr.set_line_width(1.0)
        cr.stroke()
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.7)
        cr.set_line_width(1.6)
        cr.stroke()
        # glossy top highlight (clipped to body)
        cr.save()
        _body_path(cr)
        cr.clip()
        gl = cairo.LinearGradient(0, 13, 0, 34)
        gl.add_color_stop_rgba(0, 1, 1, 1, 0.18)
        gl.add_color_stop_rgba(1, 1, 1, 1, 0)
        cr.set_source(gl)
        cr.rectangle(0, 10, MX, 30)
        cr.fill()
        # soft left specular
        sp = cairo.RadialGradient(30, 22, 2, 30, 22, 26)
        sp.add_color_stop_rgba(0, 1, 1, 1, 0.08)
        sp.add_color_stop_rgba(1, 1, 1, 1, 0)
        cr.set_source(sp)
        cr.rectangle(0, 10, MX, 60)
        cr.fill()
        # bottom inner shading
        bs = cairo.LinearGradient(0, 48, 0, 68)
        bs.add_color_stop_rgba(0, 0, 0, 0, 0)
        bs.add_color_stop_rgba(1, 0, 0, 0, 0.28)
        cr.set_source(bs)
        cr.rectangle(0, 44, MX, 26)
        cr.fill()
        # panel seam (two molded halves), passes behind the guide button
        cr.set_source_rgba(0, 0, 0, 0.18)
        cr.set_line_width(0.35)
        cr.move_to(20, 20.5)
        cr.curve_to(34, 18.2, 66, 18.2, 80, 20.5)
        cr.stroke()
        # grip texture dots (one column per wing)
        cr.set_source_rgba(0, 0, 0, 0.12)
        for gx in (12.5, 87.5):
            for gy in (41.0, 44.5, 48.0):
                circ(cr, gx, gy, 0.35)
                cr.fill()
        # grip grooves
        cr.set_source_rgba(1, 1, 1, 0.06)
        cr.set_line_width(1.1)
        cr.arc(21.5, 52, 6.2, math.pi * 0.75, math.pi * 1.55)
        cr.stroke()
        cr.arc(78.5, 52, 6.2, math.pi * 1.45, math.pi * 0.25)
        cr.stroke()
        cr.restore()

    def _draw_stick(self, cr, st, clicked, label=""):
        x, y = st.fx * MX, st.fy * MY
        R = st.r * MX
        # raised bezel: light arc on top, dark on bottom (3D ring)
        cr.set_source_rgba(0.55, 0.58, 0.65, 0.30)
        cr.set_line_width(0.8)
        cr.new_path()
        cr.arc(x, y, R + 0.5, math.pi, 2 * math.pi)
        cr.stroke()
        cr.set_source_rgba(0, 0, 0, 0.45)
        cr.set_line_width(0.8)
        cr.new_path()
        cr.arc(x, y, R + 0.5, 0, math.pi)
        cr.stroke()
        # recessed well (dark center -> lighter rim = concave)
        wg = cairo.RadialGradient(x, y, R * 0.15, x, y, R)
        wg.add_color_stop_rgba(0, 0.04, 0.043, 0.051, 1)
        wg.add_color_stop_rgba(0.72, 0.06, 0.065, 0.078, 1)
        wg.add_color_stop_rgba(1, 0.17, 0.18, 0.21, 1)
        circ(cr, x, y, R)
        cr.set_source(wg)
        cr.fill()
        cr.set_source_rgba(0.4, 0.43, 0.5, 0.5)
        cr.set_line_width(0.45)
        circ(cr, x, y, R)
        cr.stroke()
        # LS/RS label under the well
        if label:
            _vtext(cr, x, y + R + 2.6, 2.3, label, (0.82, 0.85, 0.92), 0.65)
        # 3D cap follows the axes
        cx = x + st.px * R * 0.52
        cy = y + st.py * R * 0.52
        capR = R * 0.55
        moving = math.hypot(st.px, st.py)
        if moving > 0.05:
            gg = cairo.RadialGradient(cx, cy, capR * 0.4, cx, cy, capR * 1.75)
            gg.add_color_stop_rgba(0, 0.12, 1.0, 0.32, 0.40 * moving)
            gg.add_color_stop_rgba(1, 0.12, 1.0, 0.32, 0)
            circ(cr, cx, cy, capR * 1.75)
            cr.set_source(gg)
            cr.fill()
        if clicked:
            cr.set_source_rgba(1.0, 0.55, 0.1, 0.85)
            cr.set_line_width(0.9)
            circ(cr, cx, cy, capR * 1.18)
            cr.stroke()
            cr.set_source_rgba(1.0, 0.55, 0.1, 0.30)
            cr.set_line_width(1.6)
            circ(cr, cx, cy, capR * 1.42)
            cr.stroke()
        cg = cairo.RadialGradient(cx - capR * 0.3, cy - capR * 0.35, capR * 0.1,
                                  cx, cy, capR)
        cg.add_color_stop_rgba(0, 0.52, 0.54, 0.60, 1)
        cg.add_color_stop_rgba(0.7, 0.32, 0.335, 0.38, 1)
        cg.add_color_stop_rgba(1, 0.20, 0.21, 0.24, 1)
        circ(cr, cx, cy, capR)
        cr.set_source(cg)
        cr.fill_preserve()
        cr.set_source_rgba(0.03, 0.03, 0.04, 0.8)
        cr.set_line_width(0.35)
        cr.stroke()
        # center dimple + specular
        dg = cairo.RadialGradient(cx, cy, 0, cx, cy, capR * 0.58)
        dg.add_color_stop_rgba(0, 0.10, 0.11, 0.13, 1)
        dg.add_color_stop_rgba(1, 0.21, 0.225, 0.26, 1)
        circ(cr, cx, cy, capR * 0.58)
        cr.set_source(dg)
        cr.fill()
        cr.set_source_rgba(1, 1, 1, 0.20)
        circ(cr, cx - capR * 0.30, cy - capR * 0.36, capR * 0.16)
        cr.fill()

    def _draw_dpad(self, cr):
        cx, cy = self.DCX * MX, self.DCY * MY
        L, wdt = 7.6, 5.4
        _dpad_path(cr, cx, cy, L, wdt)
        g = cairo.LinearGradient(0, cy - L, 0, cy + L)
        g.add_color_stop_rgba(0, 0.33, 0.345, 0.38, 1)
        g.add_color_stop_rgba(1, 0.20, 0.21, 0.235, 1)
        cr.set_source(g)
        cr.fill_preserve()
        cr.set_source_rgba(0.02, 0.02, 0.03, 0.7)
        cr.set_line_width(0.4)
        cr.stroke()
        cr.set_source_rgba(0.9, 0.93, 1.0, 0.30)
        cr.set_line_width(0.8)
        cr.stroke()
        # central dimple
        dg = cairo.RadialGradient(cx, cy, 0, cx, cy, 2.4)
        dg.add_color_stop_rgba(0, 0.08, 0.086, 0.1, 1)
        dg.add_color_stop_rgba(1, 0.17, 0.18, 0.21, 1)
        circ(cr, cx, cy, 2.4)
        cr.set_source(dg)
        cr.fill()
        # direction arrows (the real D-pad has raised triangles)
        a = 4.4
        ar = 1.25

        def arrow(tx, ty, ang):
            cr.save()
            cr.translate(tx, ty)
            cr.rotate(ang)
            cr.move_to(0, -ar)
            cr.line_to(ar * 0.85, ar * 0.75)
            cr.line_to(-ar * 0.85, ar * 0.75)
            cr.close_path()
            cr.fill()
            cr.restore()

        cr.set_source_rgba(0.85, 0.88, 0.94, 0.80)
        arrow(cx, cy - a, 0)                # up (away from center)
        arrow(cx, cy + a, math.pi)          # down
        arrow(cx - a, cy, -math.pi / 2)     # left
        arrow(cx + a, cy, math.pi / 2)      # right
        # per-direction glow
        arms = {
            "up": (cx, cy - L / 2 - 0.4, 4.6, L / 2 + 0.4),
            "down": (cx, cy + L / 2 + 0.4, 4.6, L / 2 + 0.4),
            "left": (cx - L / 2 - 0.4, cy, L / 2 + 0.4, 4.6),
            "right": (cx + L / 2 + 0.4, cy, L / 2 + 0.4, 4.6),
        }
        for name, b in (("up", self.dpad_up), ("down", self.dpad_dn),
                        ("left", self.dpad_lt), ("right", self.dpad_rt)):
            if b.press > 0.05:
                ax, ay, aw, ah = arms[name]
                cr.save()
                rr_path(cr, ax - aw / 2, ay - ah / 2, aw, ah, 1.4)
                cr.set_source_rgba(0.15, 1.0, 0.35, 0.55 * b.press)
                cr.fill()
                cr.set_source_rgba(0.4, 1.0, 0.55, 0.9 * b.press)
                cr.set_line_width(0.5)
                cr.stroke()
                cr.restore()

    def _draw_face(self, cr, b):
        x, y = b.fx * MX, b.fy * MY
        R = b.radius * MX
        c = b.color
        # recess
        wg = cairo.RadialGradient(x, y, R * 0.2, x, y, R)
        wg.add_color_stop_rgba(0, 0.05, 0.053, 0.062, 1)
        wg.add_color_stop_rgba(1, 0.16, 0.17, 0.2, 1)
        circ(cr, x, y, R)
        cr.set_source(wg)
        cr.fill()
        cr.set_source_rgba(0.35, 0.38, 0.44, 0.4)
        cr.set_line_width(0.35)
        circ(cr, x, y, R)
        cr.stroke()
        # press glow
        if b.press > 0.03:
            gg = cairo.RadialGradient(x, y, R * 0.4, x, y, R * 1.7)
            gg.add_color_stop_rgba(0, c[0], c[1], c[2], 0.55 * b.press)
            gg.add_color_stop_rgba(1, c[0], c[1], c[2], 0)
            circ(cr, x, y, R * 1.7)
            cr.set_source(gg)
            cr.fill()
        # 3D cap (sinks when pressed)
        sink = 1.0 - 0.10 * b.press
        capR = R * 0.78 * sink
        light = (min(1.0, c[0] + 0.42), min(1.0, c[1] + 0.42), min(1.0, c[2] + 0.42))
        dark = (c[0] * 0.45, c[1] * 0.45, c[2] * 0.45)
        cg = cairo.RadialGradient(x - capR * 0.25, y - capR * 0.3, capR * 0.1,
                                  x, y, capR)
        cg.add_color_stop_rgba(0, light[0], light[1], light[2], 1)
        cg.add_color_stop_rgba(0.62, c[0], c[1], c[2], 1)
        cg.add_color_stop_rgba(1, dark[0], dark[1], dark[2], 1)
        circ(cr, x, y, capR)
        cr.set_source(cg)
        cr.fill_preserve()
        cr.set_source_rgba(dark[0], dark[1], dark[2], 0.8)
        cr.set_line_width(0.3)
        cr.stroke()
        # letter (big + shadowed for clarity)
        _vtext(cr, x, y, R * 1.15, b.label, (1, 1, 1), 0.98)

    def _draw_guide(self, cr):
        x, y = self.guide.fx * MX, self.guide.fy * MY
        R = self.guide.radius * MX
        # metallic base ring
        rg = cairo.LinearGradient(0, y - R, 0, y + R)
        rg.add_color_stop_rgba(0, 0.34, 0.36, 0.40, 1)
        rg.add_color_stop_rgba(1, 0.12, 0.13, 0.15, 1)
        circ(cr, x, y, R)
        cr.set_source(rg)
        cr.fill_preserve()
        cr.set_source_rgba(0.02, 0.02, 0.03, 0.8)
        cr.set_line_width(0.35)
        cr.stroke()
        sR = R * 0.68
        # press glow
        if self.guide.press > 0.03:
            gg = cairo.RadialGradient(x, y, sR * 0.5, x, y, R * 1.9)
            gg.add_color_stop_rgba(0, 0.15, 1.0, 0.35, 0.7 * self.guide.press)
            gg.add_color_stop_rgba(1, 0.15, 1.0, 0.35, 0)
            circ(cr, x, y, R * 1.9)
            cr.set_source(gg)
            cr.fill()
        else:
            # idle pulse
            pulse = 0.10 + 0.26 * (math.sin(self.t * 3.0) + 1) / 2
            cr.set_source_rgba(0.15, 1.0, 0.38, pulse)
            cr.set_line_width(0.8)
            circ(cr, x, y, R * 1.08)
            cr.stroke()
        # the green sphere
        sg = cairo.RadialGradient(x - sR * 0.3, y - sR * 0.35, sR * 0.1,
                                  x, y, sR)
        sg.add_color_stop_rgba(0, 0.42, 0.98, 0.50, 1)
        sg.add_color_stop_rgba(0.55, 0.12, 0.62, 0.25, 1)
        sg.add_color_stop_rgba(1, 0.03, 0.25, 0.10, 1)
        circ(cr, x, y, sR)
        cr.set_source(sg)
        cr.fill()
        # carved X (thicker for visibility)
        d = sR * 0.50
        cr.set_source_rgba(0.02, 0.30, 0.10, 0.75)
        cr.set_line_width(0.70)
        cr.move_to(x - d, y - d); cr.line_to(x + d, y + d)
        cr.move_to(x + d, y - d); cr.line_to(x - d, y + d)
        cr.stroke()

    def _draw_pill(self, cr, b, kind, label=""):
        x, y = b.fx * MX, b.fy * MY
        if kind == "dot":
            R = b.radius * MX
            pg = cairo.RadialGradient(x, y, 0.2, x, y, R)
            pg.add_color_stop_rgba(0, 0.24, 0.25, 0.29, 1)
            pg.add_color_stop_rgba(1, 0.10, 0.11, 0.13, 1)
            circ(cr, x, y, R)
            cr.set_source(pg)
            cr.fill_preserve()
            cr.set_source_rgba(0.03, 0.03, 0.04, 0.7)
            cr.set_line_width(0.3)
            cr.stroke()
        else:
            w, h = 6.0, 3.4
            g = cairo.LinearGradient(0, y - h / 2, 0, y + h / 2)
            g.add_color_stop_rgba(0, 0.22, 0.23, 0.26, 1)
            g.add_color_stop_rgba(1, 0.10, 0.11, 0.13, 1)
            rr_path(cr, x - w / 2, y - h / 2, w, h, 1.5)
            cr.set_source(g)
            cr.fill_preserve()
            cr.set_source_rgba(0.03, 0.03, 0.04, 0.7)
            cr.set_line_width(0.3)
            cr.stroke()
            # tiny icon
            cr.set_source_rgba(0.8, 0.85, 0.92, 0.65)
            cr.set_line_width(0.4)
            if kind == "view":
                cr.rectangle(x - 1.1, y - 0.8, 1.0, 1.6)
                cr.stroke()
                cr.rectangle(x - 0.2, y - 0.8, 1.0, 1.6)
                cr.stroke()
            else:  # menu
                for i in (-0.8, 0, 0.8):
                    cr.move_to(x - 1.1, y + i)
                    cr.line_to(x + 1.1, y + i)
                cr.stroke()
        # small label under the pill (SELECT / START)
        if label:
            _vtext(cr, x, y + 3.8, 1.9, label, (0.82, 0.85, 0.92), 0.58)
        if b.press > 0.05:
            cr.save()
            cr.set_source_rgba(0.15, 1.0, 0.35, 0.55 * b.press)
            circ(cr, x, y, max(b.radius * MX, 2.6) * 1.5)
            cr.fill()
            cr.restore()


def render(state, width, height, path=None):
    if cairo is None:
        return None
    surf = cairo.ImageSurface(cairo.FORMAT_ARGB32, int(width), int(height))
    cr = cairo.Context(surf)
    cc = PadLinkController()
    cc.set_state(state)
    cc.update(1.0)
    cc.draw(cr, width, height)
    if path:
        surf.write_to_png(path)
    return surf


def idle_state():
    return ControllerState()


def example_state():
    st = ControllerState()
    st.A = True
    st.Y = True
    st.LB = True
    st.LT = 0.72
    st.RT = 0.34
    st.LX = -0.42
    st.LY = 0.18
    st.RY = -0.65
    st.DL = True
    st.Xbox = True
    return st


if __name__ == "__main__":
    render(idle_state(), 1600, 980, "/home/user/controller_model.png")
    render(example_state(), 1600, 980, "/home/user/controller_model_live.png")
    print("rendered vector model")
