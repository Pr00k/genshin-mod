# Publishing GenshinConsole

The app is one self-contained HTML file, so "hosting" here means putting two
files on a static host. No build step runs on the server, no database, no
runtime — which is why the free tiers are genuinely enough rather than a
crippled trial.

## Why publish it at all?

Three things only work from a real `https://` address. Everything else
already works offline from the file, and that is worth being precise about —
the same build, the same browser, measured on both:

|                        | `file://` | `https://` |
|------------------------|-----------|------------|
| Quest library (1,322)  | works     | works      |
| Rust/WASM search       | works     | works      |
| Commands, gifts, chat  | works     | works      |
| **On-device assistant**| **no**    | **yes**    |

1. **The on-device assistant.** It runs llama.cpp inside
   `new Worker(url, { type: 'module' })`, and a `file://` document is not
   allowed to start one — measured: the classic worker starts, the module
   worker is refused. It also needs OPFS-adjacent storage that `file://`
   denies (`navigator.storage.getDirectory()` → SecurityError there, OK over
   http). Neither is something page code can work around. The app detects
   this before downloading anything and says so, rather than appearing to
   hang.
2. **Brave remembers "Desktop site".** Opened through ZArchiver the address is
   `content://…`, which is a *one-shot* origin — it changes each time, so the
   browser has no stable origin to attach the preference to and falls back to
   mobile on every reload. This is the browser's rule and no page code
   changes it. A fixed `https://` origin fixes it permanently.
3. **A link you can send people**, instead of a file they have to install.

## Who can see the published site?

**Everyone.** Cloudflare Pages is public hosting: anyone with the address can
open it, and the address is not a secret — it leaks through history, shared
screenshots, and simply being guessed. Plan for the page being readable by
strangers, because it is.

That is fine for the player app, which contains nothing private: a quest
library, a command reference, and an interface. It is **not** automatically
fine for the console, so:

- **The console is encrypted, not hidden.** `admin.html` is one AES-256-GCM
  ciphertext with an Argon2id key. Downloading it gets a stranger an
  encrypted blob and an invitation to guess your password at 46 MiB of memory
  per attempt. The URL being unlisted is tidiness; the encryption is the
  defence.
- **`robots.txt` and `noindex` keep it out of search results.** They keep
  nobody out. A crawler directive is a request that well-behaved crawlers
  honour and nothing else does.
- **The password is the whole security boundary.** A short one is fine for a
  local file and thin for a public URL. Change it before publishing, and set
  it as an environment variable so it never enters the repository.

### If you want it genuinely unreachable

Cloudflare → **Zero Trust** → **Access** → add an application for
`your-site.pages.dev/admin.html`, policy "emails I list". Free for 50 users.
The console then never even downloads for anyone else — Cloudflare refuses
the request before your file is served. This is the one change that turns
"encrypted and public" into "not reachable", and it takes about two minutes.

### Making the whole site private

If you would rather nobody sees the app either, the same Access application
with a `/*` path covers everything. Note the trade: every player then needs
an account you have approved, which for a public server tool is usually the
wrong shape. A middle option is Cloudflare's **Bot Fight Mode** plus a rate
limit — the site stays open to people and closed to scrapers.

## What publishing does NOT change

The app does not become an online app. Once loaded from an `https://` address
it still holds every quest, every command and the whole interface locally, so
it works with the phone offline afterwards. Publishing changes where the file
is *fetched from* once, not where the app runs.

## The recommendation: Cloudflare Pages

Measured against the alternatives on the things that actually matter here:

| | Cloudflare Pages | GitHub Pages | Netlify | Vercel |
|---|---|---|---|---|
| Bandwidth | **Unlimited** | 100 GB soft | 100 GB | 100 GB |
| Custom headers | **Yes** (`_headers`) | **No** | Yes | Yes |
| HTTPS | Automatic | Automatic | Automatic | Automatic |
| DDoS protection | **Included** | Basic | Basic | Basic |
| Private repo | Yes | Paid | Yes | Yes |
| Commercial use | Yes | Yes | Yes | **Pro only** |

Two of those decide it.

**Custom headers.** GitHub Pages cannot send them at all, which means no
Content-Security-Policy, no HSTS, no frame protection — the entire `_headers`
file in this folder would be ignored. That rules it out for anything you care
about securing.

**Unlimited bandwidth.** This file is about 4.8 MB, most of it the background
video. At 100 GB that is roughly 20,000 loads before a cap; on Cloudflare
there is no cap to reach.

### Steps

1. Create a **private** repository and push this project.
2. Cloudflare dashboard → **Workers & Pages** → **Create** → **Pages** →
   **Connect to Git**.
3. Build settings:
   - Build command: `bun install && bun run scripts/build.ts`
   - Output directory: `dist`
   - Environment variables: `ADMIN_USER` and `ADMIN_PASS`
4. Deploy. Copy `deploy/_headers` into `dist/` — the build already does this.

**Set `ADMIN_USER` and `ADMIN_PASS` as environment variables, never in the
repository.** They are the key that decrypts the admin console; committing
them puts the console in the repository's history permanently, where deleting
the file later does not remove them.

### Even simpler, no Git

Cloudflare Pages → **Upload assets** → drag the `dist` folder in. Live in
about thirty seconds. The cost is that every update is another manual upload.

## What publishing does NOT change

Said plainly, because a hosted copy is not a different program:

- **The chat still runs on a public MQTT broker.** Hosting the page does not
  give you a chat server. The traffic is encrypted, but the limit stated in
  the app still holds: everyone holding the file holds the key.
- **The game gateway is still `api.yuuki.me`.** If that goes down, commands
  stop working wherever the page is hosted. The quest library, the command
  reference and the download catalogue keep working, because they are inside
  the file.
- **The admin console is still client-side.** It is decrypted in the browser
  with your password. Publishing does not add a server-side login, and
  anybody who downloads `admin.html` can attempt to open it — which is why
  the password matters and why Argon2id is used to make guessing expensive.

## After it is live

- Confirm HTTPS works, **then** leave HSTS enabled. It is a two-year promise
  a browser will hold you to; enabling it before the certificate is right
  turns a warning into an unreachable site.
- Cloudflare → SSL/TLS → set **Full (strict)**.
- Cloudflare → Security → **Bot Fight Mode** on. Free, and it removes most
  automated scanning.
- Open the site once in Brave, choose **Desktop site**, and it stays. That
  was the whole reason for publishing.
