import { defineConfig, presetWind4, presetIcons, transformerDirectives, transformerVariantGroup } from 'unocss';

export default defineConfig({
  presets: [
    presetWind4(),
    presetIcons({
      scale: 1.1,
      cdn: 'https://esm.sh/',
      extraProperties: { display: 'inline-block', 'vertical-align': 'middle' },
    }),
  ],
  transformers: [transformerDirectives(), transformerVariantGroup()],
  theme: {
    breakpoint: { xs: '380px' },
    colors: {
      bg: 'var(--bg)',
      bg2: 'var(--bg2)',
      card: 'var(--card)',
      card2: 'var(--card2)',
      line: 'var(--line)',
      txt: 'var(--txt)',
      mut: 'var(--mut)',
      acc: 'var(--acc)',
      acc2: 'var(--acc2)',
      ok: 'var(--ok)',
      warn: 'var(--warn)',
      bad: 'var(--bad)',
    },
  },
  shortcuts: {
    /*
     * Panels are opaque on purpose.
     *
     * At bg-card/92 the video showed through every card while the inputs
     * inside them stayed solid, so a panel read as two different greys and the
     * text sat on moving footage. Opacity belongs to the backdrop layer, which
     * is tuned once, not to every surface stacked on top of it.
     */
    card: 'rounded-xl border border-line bg-card p-3 mb-2 shadow-[0_1px_16px_rgba(0,0,0,0.18)]',
    'section-title': 'text-[13.5px] font-bold leading-tight',
    label: 'block text-[11px] font-semibold text-mut mb-1',
    hint: 'block text-[10px] text-mut mt-1 leading-relaxed',
    input:
      'w-full h-9 rounded-lg border border-line bg-bg2 px-2.5 text-[13px] text-txt outline-none focus:border-acc focus:ring-1 focus:ring-acc',
    'btn-primary':
      'inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg bg-acc text-white text-[12.5px] font-bold hover:brightness-110 active:scale-98 disabled:opacity-50 transition',
    'btn-ghost':
      'inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg border border-line bg-card2 text-[12px] font-semibold hover:border-acc active:scale-98 transition',
    'btn-danger':
      'inline-flex items-center justify-center gap-1.5 h-9 px-3 rounded-lg bg-bad text-white text-[12.5px] font-bold hover:brightness-110 active:scale-98 transition',
    'icon-btn':
      'inline-grid place-items-center h-7 w-7 rounded-lg border border-line bg-card text-[13px] hover:border-acc transition',
    'pill-btn':
      'inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[10.5px] font-semibold transition border',
    'pill-on': 'bg-acc border-acc text-white',
    'pill-off': 'bg-card2 border-line text-mut hover:border-acc',
    chip: 'inline-flex items-center gap-1 rounded-full border border-line bg-card2 px-2 py-0.5 text-[10px] text-mut',
  },
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  /*
   * Generated from the source by `scripts/icons.ts`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every `i-lucide-*` string in src/ is included.
   */
  safelist: [
    'i-lucide-activity',
    'i-lucide-arrow-left',
    'i-lucide-arrow-left-right',
    'i-lucide-arrow-right',
    'i-lucide-badge-dollar-sign',
    'i-lucide-book-open',
    'i-lucide-bookmark',
    'i-lucide-bookmark-check',
    'i-lucide-check',
    'i-lucide-check-check',
    'i-lucide-chevron-down',
    'i-lucide-chevron-left',
    'i-lucide-chevron-right',
    'i-lucide-chevron-up',
    'i-lucide-chevrons-up-down',
    'i-lucide-circle-alert',
    'i-lucide-circle-check',
    'i-lucide-circle-help',
    'i-lucide-circle-slash',
    'i-lucide-circle-x',
    'i-lucide-copy',
    'i-lucide-corner-down-right',
    'i-lucide-cpu',
    'i-lucide-download',
    'i-lucide-eraser',
    'i-lucide-external-link',
    'i-lucide-eye',
    'i-lucide-eye-off',
    'i-lucide-file-json',
    'i-lucide-flame',
    'i-lucide-gamepad-2',
    'i-lucide-gem',
    'i-lucide-gift',
    'i-lucide-globe',
    'i-lucide-grid-2x2',
    'i-lucide-grip-horizontal',
    'i-lucide-history',
    'i-lucide-house',
    'i-lucide-image',
    'i-lucide-inbox',
    'i-lucide-info',
    'i-lucide-languages',
    'i-lucide-layers',
    'i-lucide-layout-dashboard',
    'i-lucide-layout-grid',
    'i-lucide-life-buoy',
    'i-lucide-lightbulb',
    'i-lucide-link',
    'i-lucide-list',
    'i-lucide-list-plus',
    'i-lucide-loader-circle',
    'i-lucide-lock',
    'i-lucide-log-in',
    'i-lucide-log-out',
    'i-lucide-mail',
    'i-lucide-message-circle',
    'i-lucide-message-square-warning',
    'i-lucide-monitor',
    'i-lucide-move-diagonal',
    'i-lucide-octagon-alert',
    'i-lucide-package',
    'i-lucide-palette',
    'i-lucide-pencil',
    'i-lucide-pencil-off',
    'i-lucide-play',
    'i-lucide-plus',
    'i-lucide-radar',
    'i-lucide-radio-tower',
    'i-lucide-rectangle-horizontal',
    'i-lucide-refresh-cw',
    'i-lucide-rotate-ccw',
    'i-lucide-scroll-text',
    'i-lucide-search',
    'i-lucide-send',
    'i-lucide-settings',
    'i-lucide-shapes',
    'i-lucide-shield-check',
    'i-lucide-smartphone',
    'i-lucide-sparkles',
    'i-lucide-square',
    'i-lucide-star',
    'i-lucide-sword',
    'i-lucide-terminal',
    'i-lucide-timer',
    'i-lucide-trash-2',
    'i-lucide-triangle-alert',
    'i-lucide-user-round',
    'i-lucide-users',
    'i-lucide-wand-sparkles',
    'i-lucide-x',
    'i-lucide-youtube',
  ],
});
