import{unsealText as f}from"./crypto.js";import{rememberSession as D,resumeSession as F,forgetSession as M}from"./session.js";var N=typeof __ADMIN_PAYLOAD__==="string"?__ADMIN_PAYLOAD__:"";var Z="gc_admin_attempts",h=5,C=60000;function P(){try{return JSON.parse(sessionStorage.getItem(Z)??"")}catch{return{n:0,until:0}}}function G(){let j={n:P().n+1,until:0};if(j.n>=h)j.until=Date.now()+C,j.n=0;try{sessionStorage.setItem(Z,JSON.stringify(j))}catch{}return j}function U(){try{sessionStorage.removeItem(Z)}catch{}}var B={en:{title:"Admin console",sub:"Encrypted build",user:"Username",pass:"Password",go:"Decrypt and open",both:"Enter both a username and a password.",wrong:"Wrong username or password.",deriving:"Deriving key…",wait:"Too many attempts. Wait {s}s.",locked:"Too many attempts. Locked for 60 seconds.",keep:"Keep me signed in on this device",keepHint:"Stores your credentials encrypted under a key the browser will not let anything read back, so a reload does not ask again. Expires after 12 hours and only ever applies to this browser on this machine. Leave it off on a shared computer.",resuming:"Resuming your session…",note:"The console itself is stored encrypted with AES-256-GCM. Your username and password derive the key that decrypts it — they are not checked against anything, so there is no lock to bypass and nothing readable in this file without them."},ar:{title:"لوحة التحكم",sub:"نسخة مشفّرة",user:"اسم المستخدم",pass:"كلمة المرور",go:"فكّ التشفير والدخول",both:"أدخل اسم المستخدم وكلمة المرور معًا.",wrong:"اسم المستخدم أو كلمة المرور غير صحيحة.",deriving:"جارٍ اشتقاق المفتاح…",wait:"محاولات كثيرة. انتظر {s} ثانية.",locked:"محاولات كثيرة. مقفل لمدة ٦٠ ثانية.",keep:"أبقني مسجَّلًا على هذا الجهاز",keepHint:"يخزّن بياناتك مشفّرة بمفتاح لا يسمح المتصفح لأي شيء بقراءته، فلا تُطلب منك مجددًا عند إعادة التحميل. تنتهي الصلاحية بعد ١٢ ساعة وتخصّ هذا المتصفح على هذا الجهاز فقط. اتركه مغلقًا على حاسوب مشترك.",resuming:"جارٍ استئناف جلستك…",note:"اللوحة نفسها مخزّنة مشفّرة بـ AES-256-GCM. اسم المستخدم وكلمة المرور يشتقّان المفتاح الذي يفكّها — لا يُقارَنان بشيء، فلا يوجد قفل يُتجاوز ولا شيء مقروء في هذا الملف بدونهما."},ru:{title:"Панель управления",sub:"Зашифрованная сборка",user:"Имя пользователя",pass:"Пароль",go:"Расшифровать и открыть",both:"Введите имя пользователя и пароль.",wrong:"Неверное имя пользователя или пароль.",deriving:"Вывод ключа…",wait:"Слишком много попыток. Подождите {s} с.",locked:"Слишком много попыток. Блокировка на 60 секунд.",keep:"Оставаться в системе на этом устройстве",keepHint:"Сохраняет учётные данные, зашифрованные ключом, который браузер никому не даёт прочитать, поэтому перезагрузка не спросит снова. Истекает через 12 часов и действует только в этом браузере на этой машине. На общем компьютере оставьте выключенным.",resuming:"Восстановление сессии…",note:"Сама панель хранится зашифрованной AES-256-GCM. Имя пользователя и пароль выводят ключ, который её расшифровывает — они ни с чем не сравниваются, так что обходить нечего, и без них в этом файле нет ничего читаемого."},ja:{title:"管理コンソール",sub:"暗号化ビルド",user:"ユーザー名",pass:"パスワード",go:"復号して開く",both:"ユーザー名とパスワードの両方を入力してください。",wrong:"ユーザー名またはパスワードが違います。",deriving:"鍵を導出しています…",wait:"試行が多すぎます。{s} 秒お待ちください。",locked:"試行が多すぎます。60秒間ロックされました。",keep:"この端末でログインを維持する",keepHint:"ブラウザが読み出しを許さない鍵で暗号化して資格情報を保存するため、再読み込みで再入力を求められません。12時間で失効し、この端末のこのブラウザにのみ適用されます。共有のパソコンではオフのままにしてください。",resuming:"セッションを再開しています…",note:"コンソール本体は AES-256-GCM で暗号化して保存されています。ユーザー名とパスワードがそれを復号する鍵を導出します。何かと照合されるわけではないので、破るべき錠はなく、それらなしでこのファイルに読めるものはありません。"},zh:{title:"管理控制台",sub:"加密构建",user:"用户名",pass:"密码",go:"解密并打开",both:"请同时输入用户名和密码。",wrong:"用户名或密码错误。",deriving:"正在派生密钥…",wait:"尝试次数过多，请等待 {s} 秒。",locked:"尝试次数过多，已锁定 60 秒。",keep:"在此设备上保持登录",keepHint:"将凭据用浏览器不允许任何程序读回的密钥加密后保存，因此刷新页面不会再次询问。12 小时后失效，且仅适用于本机的此浏览器。在共用电脑上请保持关闭。",resuming:"正在恢复会话…",note:"控制台本身以 AES-256-GCM 加密存储。你的用户名和密码派生出解密它的密钥 —— 它们不与任何值比对，因此没有可绕过的锁，没有它们这个文件里也没有任何可读内容。"}},Y=[["en","English"],["ar","العربية"],["ru","Русский"],["ja","日本語"],["zh","简体中文"]],Q=(()=>{try{return localStorage.getItem("gc_admin_lang")??"en"}catch{return"en"}})(),z=(q,j)=>{let w=B[Q]?.[q]??B.en[q]??q;if(j)for(let H in j)w=w.split(`{${H}}`).join(String(j[H]));return w},J=(q)=>document.getElementById(q);function V(q,j=!0){let w=J("msg");w.textContent=q,w.className=j?"err":"ok",w.style.display=q?"block":"none"}async function E(){let q=(J("user").value??"").trim(),j=J("pass").value??"",w=P();if(w.until>Date.now()){let I=Math.ceil((w.until-Date.now())/1000);V(z("wait",{s:I}));return}if(!q||!j){V(z("both"));return}let H=J("go");H.disabled=!0,V(z("deriving"),!1),await new Promise((I)=>setTimeout(I,30));try{let I=await R(q,j);if(!I){let X=G();H.disabled=!1,V(X.until>Date.now()?z("locked"):z("wrong"));return}if(U(),J("keep")?.checked===!0)await D({user:q,pass:j});W(I,q,j)}catch(I){H.disabled=!1,V(I instanceof Error?I.message:String(I))}}async function R(q,j){let w=JSON.parse(N);return f(q,j,w)}function W(q,j,w){window.__ADMIN_CREDS__={user:j,pass:w},document.getElementById("gate")?.remove();let H=document.createElement("script");H.textContent=q,document.body.appendChild(H),H.remove()}async function S(){let q=await F();if(!q)return!1;try{let j=await R(q.user,q.pass);if(!j)return await M(),!1;return W(j,q.user,q.pass),!0}catch{return!1}}function _(){let q=Q==="ar";document.documentElement.lang=Q,document.documentElement.dir=q?"rtl":"ltr",document.body.innerHTML=`
    <div id="gate" class="gate">
      <form class="box" id="form" autocomplete="off">
        <div class="brand">
          <span class="lock">&#128274;</span>
          <div style="flex:1;min-width:0">
            <h1>${z("title")}</h1>
            <p class="sub">${z("sub")}</p>
          </div>
          <select id="lang" class="lang">
            ${Y.map(([j,w])=>`<option value="${j}"${j===Q?" selected":""}>${w}</option>`).join("")}
          </select>
        </div>

        <label class="lbl" for="user">${z("user")}</label>
        <input id="user" class="fld" type="text" autocomplete="off"
               autocapitalize="off" spellcheck="false" />

        <label class="lbl" for="pass">${z("pass")}</label>
        <input id="pass" class="fld" type="password" autocomplete="off" />

        <label class="keep" for="keep">
          <input id="keep" type="checkbox" />
          <span>
            <span class="keep-t">${z("keep")}</span>
            <span class="keep-h">${z("keepHint")}</span>
          </span>
        </label>

        <button id="go" class="btn" type="submit">${z("go")}</button>
        <p id="msg" class="err" style="display:none"></p>

        <p class="note">${z("note")}</p>
      </form>
    </div>`,J("lang").addEventListener("change",(j)=>{Q=j.target.value;try{localStorage.setItem("gc_admin_lang",Q)}catch{}_()}),J("form").addEventListener("submit",(j)=>{j.preventDefault(),E()}),J("user").focus()}export{S as tryResume,_ as mountGate};
