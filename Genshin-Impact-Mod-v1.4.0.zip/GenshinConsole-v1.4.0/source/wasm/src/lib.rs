//! Incremental fuzzy quest search engine.
//!
//! Compiled to WebAssembly and driven from a Web Worker via Comlink so the UI
//! thread never blocks. Supports true per-character subsequence matching, so
//! typing "wtp" already surfaces "Winds of the Past" long before the words are
//! complete.

use serde::{Deserialize, Serialize};
use wasm_bindgen::prelude::*;

#[derive(Deserialize)]
struct RawQuest {
    id: u32,
    n: String,
    d: String,
    t: String,
    s: Vec<(u32, String)>,
}

struct Quest {
    id: u32,
    id_str: String,
    name: String,
    name_lc: String,
    desc_lc: String,
    kind: String,
    steps: Vec<(u32, String)>,
    step_blob_lc: String,
}

#[derive(Serialize)]
pub struct Hit {
    pub id: u32,
    pub score: i32,
    /// Byte offsets into the *original* name that matched, for highlighting.
    pub marks: Vec<u32>,
}

#[wasm_bindgen]
pub struct SearchIndex {
    quests: Vec<Quest>,
}

/// Subsequence scorer with bonuses for consecutive runs and word-boundary hits.
/// Returns `None` when the pattern is not a subsequence of the haystack.
fn fuzzy(hay: &str, hay_lc: &str, pat: &str) -> Option<(i32, Vec<u32>)> {
    if pat.is_empty() {
        return Some((0, Vec::new()));
    }
    let hay_bytes: Vec<char> = hay_lc.chars().collect();
    let orig: Vec<char> = hay.chars().collect();
    let pat_chars: Vec<char> = pat.chars().collect();

    let mut marks = Vec::with_capacity(pat_chars.len());
    let mut score: i32 = 0;
    let mut pi = 0usize;
    let mut streak = 0i32;
    let mut prev_idx: Option<usize> = None;

    for (hi, &hc) in hay_bytes.iter().enumerate() {
        if pi >= pat_chars.len() {
            break;
        }
        if hc == pat_chars[pi] {
            // Word-boundary bonus: start of string or preceded by a separator.
            let boundary = hi == 0
                || matches!(
                    orig.get(hi.wrapping_sub(1)),
                    Some(' ') | Some('-') | Some('_') | Some(':') | Some('\'')
                );
            score += 10;
            if boundary {
                score += 18;
            }
            if let Some(p) = prev_idx {
                if hi == p + 1 {
                    streak += 1;
                    score += 12 + streak * 4; // reward consecutive runs
                } else {
                    streak = 0;
                    // Small gap penalty keeps tight matches ahead of scattered ones.
                    score -= ((hi - p - 1).min(12)) as i32;
                }
            } else if hi == 0 {
                score += 30; // prefix match
            }
            marks.push(hi as u32);
            prev_idx = Some(hi);
            pi += 1;
        }
    }

    if pi == pat_chars.len() {
        // Shorter haystacks are more relevant for the same pattern.
        score -= (hay_bytes.len() as i32) / 12;
        Some((score, marks))
    } else {
        None
    }
}

#[wasm_bindgen]
impl SearchIndex {
    /// Build the index once from the packed quest JSON.
    #[wasm_bindgen(constructor)]
    pub fn new(json: &str) -> Result<SearchIndex, JsValue> {
        let raw: Vec<RawQuest> =
            serde_json::from_str(json).map_err(|e| JsValue::from_str(&e.to_string()))?;
        let quests = raw
            .into_iter()
            .map(|q| {
                let step_blob_lc = q
                    .s
                    .iter()
                    .map(|(_, d)| d.as_str())
                    .collect::<Vec<_>>()
                    .join(" \u{1}")
                    .to_lowercase();
                Quest {
                    id_str: q.id.to_string(),
                    name_lc: q.n.to_lowercase(),
                    desc_lc: q.d.to_lowercase(),
                    name: q.n,
                    kind: q.t,
                    steps: q.s,
                    step_blob_lc,
                    id: q.id,
                }
            })
            .collect();
        Ok(SearchIndex { quests })
    }

    #[wasm_bindgen(getter)]
    pub fn len(&self) -> usize {
        self.quests.len()
    }

    #[wasm_bindgen(js_name = stepCount)]
    pub fn step_count(&self) -> usize {
        self.quests.iter().map(|q| q.steps.len()).sum()
    }

    /// Incremental search. `kind` filters by quest type ("" = all).
    /// `named_only` hides the thousands of unnamed internal quests.
    pub fn search(
        &self,
        query: &str,
        kind: &str,
        named_only: bool,
        limit: usize,
    ) -> Result<JsValue, JsValue> {
        let q = query.trim().to_lowercase();
        let mut hits: Vec<Hit> = Vec::new();

        for quest in &self.quests {
            if !kind.is_empty() && quest.kind != kind {
                continue;
            }
            if named_only && quest.name.is_empty() {
                continue;
            }

            if q.is_empty() {
                hits.push(Hit {
                    id: quest.id,
                    score: 0,
                    marks: Vec::new(),
                });
                continue;
            }

            // Exact / prefix numeric identifiers rank highest.
            if quest.id_str == q {
                hits.push(Hit { id: quest.id, score: 100_000, marks: vec![] });
                continue;
            }
            if q.chars().all(|c| c.is_ascii_digit()) {
                if quest.id_str.starts_with(&q) {
                    hits.push(Hit { id: quest.id, score: 90_000, marks: vec![] });
                    continue;
                }
                if quest.steps.iter().any(|(sid, _)| sid.to_string() == q) {
                    hits.push(Hit { id: quest.id, score: 95_000, marks: vec![] });
                    continue;
                }
                if quest.steps.iter().any(|(sid, _)| sid.to_string().starts_with(&q)) {
                    hits.push(Hit { id: quest.id, score: 80_000, marks: vec![] });
                    continue;
                }
            }

            // Fuzzy subsequence over the display name.
            if let Some((s, marks)) = fuzzy(&quest.name, &quest.name_lc, &q) {
                hits.push(Hit { id: quest.id, score: 5_000 + s, marks });
                continue;
            }
            // Fall back to substring hits in description / step text.
            if quest.desc_lc.contains(&q) {
                hits.push(Hit { id: quest.id, score: 900, marks: vec![] });
                continue;
            }
            if quest.step_blob_lc.contains(&q) {
                hits.push(Hit { id: quest.id, score: 500, marks: vec![] });
            }
        }

        hits.sort_unstable_by(|a, b| b.score.cmp(&a.score).then(a.id.cmp(&b.id)));
        hits.truncate(limit);
        serde_wasm_bindgen::to_value(&hits).map_err(|e| JsValue::from_str(&e.to_string()))
    }

    /// Total matches without the display cap, for the result counter.
    #[wasm_bindgen(js_name = countMatches)]
    pub fn count_matches(&self, query: &str, kind: &str, named_only: bool) -> usize {
        let q = query.trim().to_lowercase();
        self.quests
            .iter()
            .filter(|quest| {
                if !kind.is_empty() && quest.kind != kind {
                    return false;
                }
                if named_only && quest.name.is_empty() {
                    return false;
                }
                if q.is_empty() {
                    return true;
                }
                if quest.id_str.starts_with(&q) {
                    return true;
                }
                if fuzzy(&quest.name, &quest.name_lc, &q).is_some() {
                    return true;
                }
                quest.desc_lc.contains(&q)
                    || quest.step_blob_lc.contains(&q)
                    || quest.steps.iter().any(|(sid, _)| sid.to_string().starts_with(&q))
            })
            .count()
    }
}
