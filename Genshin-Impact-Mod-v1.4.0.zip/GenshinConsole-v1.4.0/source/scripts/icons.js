var s=new Set;for await(let e of new Bun.Glob("src/**/*.{ts,tsx}").scan(".")){let o=await Bun.file(e).text();for(let a of o.matchAll(/i-lucide-[a-z0-9-]+/g))s.add(a[0])}var t=[...s].sort(),n=await Bun.file("uno.config.ts").text(),i=n.indexOf("  safelist: ["),c=n.indexOf("  ],",i)+4,r=`  /*
   * Generated from the source by \`scripts/icons.ts\`, not hand-written.
   *
   * A hand-kept list silently drifts: the console's resize control and the
   * Gift tab icons rendered as blank squares because nobody remembered to
   * add them here. Every \`i-lucide-*\` string in src/ is included.
   */
  safelist: [
`+t.map((e)=>`    '${e}',
`).join("")+"  ],";await Bun.write("uno.config.ts",n.slice(0,i)+r+n.slice(c));console.log(`✔ safelist: ${t.length} icons`);
