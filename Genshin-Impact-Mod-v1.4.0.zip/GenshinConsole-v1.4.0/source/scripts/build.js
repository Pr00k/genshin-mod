var D=((q)=>typeof require<"u"?require:typeof Proxy<"u"?new Proxy(q,{get:(z,W)=>(typeof require<"u"?require:z)[W]}):q)(function(q){if(typeof require<"u")return require.apply(this,arguments);throw Error('Dynamic require of "'+q+'" is not supported')});import{createGenerator as k}from"unocss";import I from"../uno.config.js";import V from"./solid-plugin.js";import{mkdir as S,rm as g}from"node:fs/promises";var Z=new URL("../dist/",import.meta.url).pathname,X=(process.env.APP_VERSION??await Bun.file(new URL("../VERSION",import.meta.url).pathname).text()).trim(),T="/home/user/GenshinConsole.html",_="/home/user/GenshinConsole-Admin.html",Q=(q)=>`${(q/1024).toFixed(0)} KB`;await g(Z,{recursive:!0,force:!0});await S(Z,{recursive:!0});console.log("▸ bundling worker…");var f=Buffer.from(await Bun.file("src/lib/wasm/quest_search_bg.wasm").arrayBuffer()).toString("base64"),x=await Bun.build({entrypoints:["./src/workers/search.worker.ts"],target:"browser",format:"iife",minify:!0,sourcemap:"none",define:{"process.env.NODE_ENV":'"production"',__WASM_B64__:JSON.stringify(f),__APP_VERSION__:JSON.stringify(X)}});if(!x.success){for(let q of x.logs)console.error(q);process.exit(1)}var U=await x.outputs[0].text(),Y=async(q,z)=>{let W=Bun.file(q);if(!await W.exists())return"";return`data:${z};base64,${Buffer.from(await W.arrayBuffer()).toString("base64")}`},C=await Y("data/media/backdrop.mp4","video/mp4"),w=await Y("data/media/backdrop-poster.jpg","image/jpeg"),c=await Y("data/media/logo.mp4","video/mp4"),b=await Y("data/media/logo.jpg","image/jpeg");console.log("▸ bundling app…");var H=await Bun.build({entrypoints:["./src/index.tsx"],target:"browser",format:"iife",minify:!0,splitting:!1,sourcemap:"none",plugins:[V],define:{"process.env.NODE_ENV":'"production"',__WORKER_CODE__:JSON.stringify(U),__APP_VERSION__:JSON.stringify(X),__BACKDROP_VIDEO__:JSON.stringify(C),__BACKDROP_POSTER__:JSON.stringify(w),__LOGO_VIDEO__:JSON.stringify(c),__LOGO_POSTER__:JSON.stringify(b)},loader:{".json":"json",".wasm":"dataurl"}});if(!H.success){for(let q of H.logs)console.error(q);process.exit(1)}var A=await H.outputs[0].text();console.log("▸ generating atomic CSS…");var p=await k(I),M="";for await(let q of new Bun.Glob("src/**/*.{ts,tsx}").scan("."))M+=await Bun.file(q).text();var{css:u}=await p.generate(M,{preflights:!0,minify:!0}),$=await Bun.file("src/styles/base.css").text(),O="/* @after-utilities */",J=$.indexOf(O),h=J===-1?$:$.slice(0,J),m=J===-1?"":$.slice(J+O.length),K=`${h}
${u}
${m}`,n=["default-src 'none'","script-src 'self' 'unsafe-inline' 'wasm-unsafe-eval' https:","style-src 'self' 'unsafe-inline'","img-src 'self' data: blob: https:","media-src 'self' data: blob:","font-src 'self' data:","connect-src 'self' https: wss:","worker-src 'self' blob:","frame-src https:","object-src 'none'","base-uri 'none'","form-action 'none'"].join(";"),j=`<!doctype html><html lang="en" dir="ltr" data-theme="dark"><head>
<!--
  The viewport is exactly what the official site uses, and no script ever
  rewrites it.

  An earlier build tried to detect Android's "Desktop site" and re-create it
  by forcing width=980. That was wrong in a way that only showed up on the
  second visit: the detection stored a flag, and from then on the app forced
  the wide layout even when the browser was back in normal mobile mode — so
  the app appeared permanently stuck on the desktop layout with no way out.

  The browser already does this correctly on its own: width=device-width
  means "lay out at whatever width the browser says", which is the phone
  width normally and about 980 when the user picks Desktop site. Letting the
  browser decide is both simpler and the behaviour that was actually wanted.
-->
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta http-equiv="Content-Security-Policy" content="${n}">
<meta name="color-scheme" content="dark light"><meta name="theme-color" content="#0b0d12">
<meta name="referrer" content="no-referrer">
<meta name="description" content="Offline quest library and live command console.">
<title>Genshin Private Console v${X}</title>
<meta name="version" content="${X}">
<style>${K}</style></head><body><div id="root"></div>
<script>${A}</script></body></html>`;await Bun.write(`${Z}index.html`,j);await Bun.write(T,j);console.log("▸ bundling admin…");var L=await Bun.build({entrypoints:["./src/admin/index.tsx"],target:"browser",format:"iife",minify:!0,sourcemap:"none",plugins:[V],define:{"process.env.NODE_ENV":'"production"',__WORKER_CODE__:JSON.stringify(""),__APP_VERSION__:JSON.stringify(X),__BACKDROP_VIDEO__:JSON.stringify(""),__BACKDROP_POSTER__:JSON.stringify(""),__LOGO_VIDEO__:JSON.stringify(""),__LOGO_POSTER__:JSON.stringify("")},loader:{".json":"json",".wasm":"dataurl"}});if(!L.success){for(let q of L.logs)console.error(q);process.exit(1)}var r=await L.outputs[0].text(),R=process.env.ADMIN_USER??"Prok",y=process.env.ADMIN_PASS??"";if(!y)console.error(`
  ✖ ADMIN_PASS is not set.
`),console.error("    The admin console is encrypted with it, so the build"),console.error("    cannot proceed without one. Nothing is defaulted:"),console.error(`    a password baked into the source is a published password.
`),console.error(`    ADMIN_PASS='your-password' bun run scripts/build.ts
`),process.exit(1);if(!process.env.ADMIN_USER)console.log(`  · admin user: ${R} (override with ADMIN_USER)`);var{KDF_MEMORY_KIB:l,KDF_TIME:d,KDF_LANES:o}=await import("../src/admin/crypto"),{argon2id:t}=await import("@noble/hashes/argon2.js");function i(q,z){let W=q.normalize("NFKC").trim().toLowerCase(),P=z.normalize("NFKC");return`${W.length}:${W}:${P.length}:${P}`}var E=crypto.getRandomValues(new Uint8Array(32)),B=crypto.getRandomValues(new Uint8Array(12)),a=t(new TextEncoder().encode(i(R,y)),E,{m:l,t:d,p:o,dkLen:32}),s=await crypto.subtle.importKey("raw",a,{name:"AES-GCM"},!1,["encrypt"]),e=await crypto.subtle.encrypt({name:"AES-GCM",iv:B},s,new TextEncoder().encode(r)),F=(q)=>Buffer.from(q instanceof Uint8Array?q:new Uint8Array(q)).toString("base64"),N=JSON.stringify({v:3,s:F(E),n:F(B),c:F(e)});console.log("▸ bundling admin gate…");var G=await Bun.build({entrypoints:["./src/admin/gate.ts"],target:"browser",format:"iife",minify:!0,sourcemap:"none",define:{"process.env.NODE_ENV":'"production"',__APP_VERSION__:JSON.stringify(X),__ADMIN_PAYLOAD__:JSON.stringify(N)}});if(!G.success){for(let q of G.logs)console.error(q);process.exit(1)}var qq=await G.outputs[0].text(),zq=`
:root{--bg:#0b0d12;--card:#151922;--line:#262d3b;--txt:#e8ebf2;--mut:#929cb0;--acc:#7c5cff;--bad:#ec5a5a;--ok:#2fbf71}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);font-family:'Segoe UI',system-ui,-apple-system,sans-serif;
     -webkit-user-select:none;user-select:none}
input{-webkit-user-select:text;user-select:text}
.gate{min-height:100vh;display:grid;place-items:center;padding:16px}
.box{width:100%;max-width:360px;background:var(--card);border:1px solid var(--line);border-radius:18px;padding:20px}
.brand{display:flex;gap:10px;align-items:center;margin-bottom:16px}
.lock{font-size:22px}
h1{margin:0;font-size:16px}
.sub{margin:2px 0 0;font-size:10.5px;color:var(--mut)}
.lbl{display:block;font-size:11px;font-weight:600;color:var(--mut);margin:10px 0 4px}
.fld{width:100%;height:38px;border-radius:10px;border:1px solid var(--line);background:#11141b;
     color:var(--txt);padding:0 10px;font-size:16px;outline:none}
.fld:focus{border-color:var(--acc)}
.btn{width:100%;height:40px;margin-top:16px;border:0;border-radius:10px;background:var(--acc);
     color:#fff;font-size:13px;font-weight:700;cursor:pointer}
.btn:disabled{opacity:.55}
.err{margin:10px 0 0;font-size:11.5px;color:var(--bad);background:rgba(236,90,90,.1);
     border:1px solid rgba(236,90,90,.35);border-radius:9px;padding:8px}
.ok{margin:10px 0 0;font-size:11.5px;color:var(--ok);background:rgba(47,191,113,.1);
    border:1px solid rgba(47,191,113,.35);border-radius:9px;padding:8px}
.note{margin:14px 0 0;font-size:10px;line-height:1.6;color:var(--mut);
      border-top:1px solid var(--line);padding-top:10px}
.keep{display:flex;gap:8px;align-items:flex-start;margin-top:14px;cursor:pointer}
.keep input{margin:2px 0 0;accent-color:var(--acc);flex:none}
.keep-t{display:block;font-size:11.5px;font-weight:600}
.keep-h{display:block;margin-top:2px;font-size:9.5px;line-height:1.6;color:var(--mut)}
.lang{flex:none;height:28px;border-radius:8px;border:1px solid var(--line);
      background:#11141b;color:var(--txt);font-size:11px;padding:0 4px}
[dir=rtl] .brand{flex-direction:row}`,Qq=["default-src 'none'","script-src 'self' 'unsafe-inline'","style-src 'self' 'unsafe-inline'","img-src 'self' data: blob: https:","media-src 'self' data: blob:","font-src 'self' data:","connect-src 'self' https:","frame-src https: data: blob:","object-src 'none'","base-uri 'none'","form-action 'none'"].join(";"),v=`<!doctype html><html lang="en" dir="ltr" data-theme="dark"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta http-equiv="Content-Security-Policy" content="${Qq}">
<meta name="color-scheme" content="dark"><meta name="theme-color" content="#0b0d12">
<meta name="referrer" content="no-referrer">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>Admin</title>
<style>${zq}</style>
<style id="app-css">${K}</style></head><body>
<script>${qq}</script></body></html>`;for(let q of["_headers","robots.txt"]){let z=Bun.file(new URL(`../deploy/${q}`,import.meta.url).pathname);if(await z.exists())await Bun.write(`${Z}${q}`,await z.text())}await Bun.write(`${Z}admin.html`,v);await Bun.write(_,v);await Bun.write(`${Z}index.html`,j);console.log(`✔ ${T}  (v${X})`);console.log(`✔ ${_}  (admin, ${Q(v.length)} · payload ${Q(N.length)} encrypted)`);console.log(`  html ${Q(j.length)} · app ${Q(A.length)} · worker ${Q(U.length)} · css ${Q(K.length)}`);console.log(`  backdrop ${Q(C.length)} (video) + ${Q(w.length)} (poster)`);console.log("✔ dist/  (index.html · admin.html · _headers — ready to publish)");
