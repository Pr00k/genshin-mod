// src/worker-entry.ts — Ultra-Hardened Cloudflare Pages Worker (v2.2.0 — 2026 Strongest Standard)
var KEY = "overrides";
var MAX_BYTES = 512 * 1024;

async function published(env) {
  if (!env.SITE) return {};
  try {
    const raw = await env.SITE.get(KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

var entries = (p) => Object.values(p.networks ?? {});

function metaTags(p) {
  return entries(p)
    .map((n) => (n.verifyMeta ?? "").trim())
    .filter((t) => /^<meta\s[^>]*>$/i.test(t))
    .join("\n");
}

function verifyFile(p, pathname) {
  for (const n of entries(p)) {
    const name = (n.verifyFileName ?? "").trim();
    if (!name || !/^[A-Za-z0-9._-]+$/.test(name)) continue;
    if (pathname === `/${name}`) return n.verifyFileBody ?? "";
  }
  return null;
}

var json = (body, status = 200, extra = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "x-content-type-options": "nosniff",
      "referrer-policy": "no-referrer",
      "x-frame-options": "DENY",
      ...extra
    }
  });

async function timingSafeEqualSecure512(a, b) {
  const enc = new TextEncoder();
  const [hashA512, hashB512, hashA256, hashB256] = await Promise.all([
    crypto.subtle.digest("SHA-512", enc.encode(a)),
    crypto.subtle.digest("SHA-512", enc.encode(b)),
    crypto.subtle.digest("SHA-256", enc.encode(a)),
    crypto.subtle.digest("SHA-256", enc.encode(b))
  ]);
  const viewA512 = new Uint8Array(hashA512);
  const viewB512 = new Uint8Array(hashB512);
  const viewA256 = new Uint8Array(hashA256);
  const viewB256 = new Uint8Array(hashB256);

  let diff = 0;
  for (let i = 0; i < viewA512.length; i++) {
    diff |= viewA512[i] ^ viewB512[i];
  }
  for (let j = 0; j < viewA256.length; j++) {
    diff |= viewA256[j] ^ viewB256[j];
  }
  return diff === 0;
}

async function authorised(req, env) {
  const expected = env.ADMIN_PASS;
  if (!expected) return false;
  const header = req.headers.get("authorization") ?? "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return false;
  return await timingSafeEqualSecure512(token, expected);
}

async function handleApi(req, env) {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET, PUT, OPTIONS",
        "access-control-allow-headers": "authorization, content-type",
        "access-control-allow-private-network": "true",
        "access-control-max-age": "86400",
        "x-content-type-options": "nosniff"
      }
    });
  }
  if (req.method === "GET") {
    if (!env.SITE) return json(null, 200, { "cache-control": "no-store" });
    const raw = await env.SITE.get(KEY);
    return new Response(raw ?? "null", {
      headers: {
        "content-type": "application/json; charset=utf-8",
        "cache-control": "public, max-age=60",
        "access-control-allow-origin": "*",
        "x-content-type-options": "nosniff",
        "referrer-policy": "no-referrer"
      }
    });
  }
  if (req.method === "PUT") {
    if (!env.SITE) {
      return json({ error: "no-kv", hint: "Bind a KV namespace named SITE." }, 503);
    }
    if (!env.ADMIN_PASS) {
      return json({ error: "no-secret", hint: "Set the ADMIN_PASS secret." }, 503);
    }
    if (!(await authorised(req, env))) {
      return json({ error: "unauthorised" }, 401);
    }
    const body = await req.text();
    if (body.length > MAX_BYTES) {
      return json({ error: "too-large", max: MAX_BYTES }, 413);
    }
    try {
      JSON.parse(body);
    } catch {
      return json({ error: "not-json" }, 400);
    }
    await env.SITE.put(KEY, body);
    return json({ ok: true, bytes: body.length });
  }
  return json({ error: "method-not-allowed" }, 405);
}

var worker_entry_default = {
  async fetch(req, env) {
    const url = new URL(req.url);
    if (url.pathname === "/api/site") {
      return await handleApi(req, env);
    }
    const pub = await published(env);
    const vf = verifyFile(pub, url.pathname);
    if (vf !== null) {
      return new Response(vf, {
        headers: {
          "content-type": "text/plain; charset=utf-8",
          "cache-control": "no-store",
          "x-content-type-options": "nosniff",
          "referrer-policy": "no-referrer"
        }
      });
    }
    if (url.pathname === "/ads.txt") {
      const lines = entries(pub)
        .map((n) => (n.adsTxtLine ?? "").trim())
        .filter(Boolean);
      if (lines.length) {
        return new Response(`${lines.join("\n")}\n`, {
          headers: {
            "content-type": "text/plain; charset=utf-8",
            "cache-control": "public, max-age=300",
            "x-content-type-options": "nosniff"
          }
        });
      }
    }
    const res = await env.ASSETS.fetch(req);
    const tags = metaTags(pub);
    if (!tags) return res;
    const type = res.headers.get("content-type") ?? "";
    if (!type.includes("text/html")) return res;
    return new HTMLRewriter()
      .on("head", {
        element(el) {
          el.append(tags, { html: true });
        }
      })
      .transform(res);
  }
};

export { worker_entry_default as default };
